﻿
using ApiHelper;
namespace Web.ApiInfrastructure.ApiModels
{
    using ApiHelper.Model;
    using System;

    public class RegisterApiModel : ApiModel
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public bool IsApproved { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PasswordHash { get; set; }
        public string SecurityStamp { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public Nullable<System.DateTime> LockoutEndDateUtc { get; set; }
        public bool LockoutEnabled { get; set; }
        public int AccessFailedCount { get; set; }
        public string LastName { get; set; }
        public string CompanyName { get; set; }
        public string UserName { get; set; }
    }
}