﻿namespace Web.ApiInfrastructure.ApiModels
{
    public class LoginApiModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}