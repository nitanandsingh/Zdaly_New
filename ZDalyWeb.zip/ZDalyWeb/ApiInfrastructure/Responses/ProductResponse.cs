﻿namespace Web.ApiInfrastructure.Responses
{
    using ApiHelper.Response;
    using ApiModels;

    public class ProductResponse : ApiResponse<ProductApiModel>
    {
    }
}