﻿namespace Web.ApiInfrastructure.Responses
{
    using ApiHelper.Response;
    public class CreateProductResponse : ApiResponse<int>
    {
    }
}