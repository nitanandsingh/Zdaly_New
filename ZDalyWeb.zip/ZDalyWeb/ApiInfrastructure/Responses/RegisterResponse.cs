﻿using ApiHelper.Response;

namespace Web.ApiInfrastructure.Responses
{
    public class RegisterResponse : ApiResponse
    {
    }
}