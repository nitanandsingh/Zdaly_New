﻿namespace Web.ApiInfrastructure.Responses
{
    using ApiHelper.Response;

    public class TokenResponse : ApiResponse<string>
    {
    }
}