﻿namespace Web.ApiInfrastructure.Client
{
    using System.Threading.Tasks;    
    using Responses;

    public interface IProductClient
    {
        Task<CreateProductResponse> CreateProduct(ZDalyModels.LoginModel product);
        Task<ProductResponse> GetProduct(int productId);
    }
}