﻿namespace Web.ApiInfrastructure.Client
{
    using System;
    using System.Threading.Tasks;
    using ApiHelper.Client;
    using ApiModels;    
    using Responses;
    using ZDalyWeb.Models;

    public class ProductClient : ClientBase, IProductClient
    {
        private const string ProductUri = "api/product";
        private const string ProductsUri = "api/products";
        private const string IdKey = "id";

        public ProductClient(IApiClient apiClient) : base(apiClient)
        {
        }

        public async Task<CreateProductResponse> CreateProduct(RegisterViewModel product)
        {
            var apiModel = new ProductApiModel
            {
                CreatedOn = DateTime.Now,
        //        Name = product.Name,
           //     Description = product.Description
            };
            var createProductResponse = await PostEncodedContentWithSimpleResponse<CreateProductResponse, ProductApiModel>(ProductsUri, apiModel);
            return createProductResponse;
        }

        public async Task<ProductResponse> GetProduct(int productId)
        {
            var idPair = IdKey.AsPair(productId.ToString());
            return await GetJsonDecodedContent<ProductResponse, ProductApiModel>(ProductUri, idPair);
        }

        public Task<CreateProductResponse> CreateProduct(ZDalyModels.LoginModel product)
        {
            throw new NotImplementedException();
        }
    }
}