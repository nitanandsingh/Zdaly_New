/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 var URL = window.location,
 $BODY = $('body'),
 $MENU_TOGGLE = $('#menu_toggle'),
 $SIDEBAR_MENU = $('#sidebar-menu'),
 $SIDEBAR_FOOTER = $('.sidebar-footer'),
 $LEFT_COL = $('.left_col'),
 $RIGHT_COL = $('.right_col'),
 $NAV_MENU = $('.nav_menu'),
 $FOOTER = $('footer');

// Sidebar
$(document).ready(function() {

    // TODO: This is some kind of easy fix, maybe we can improve this
    var setContentHeight = function () {
        // reset height
        $RIGHT_COL.css('min-height', $(window).height());

        var bodyHeight = $BODY.height(),
        leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
        contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

        // normalize content
        contentHeight -= $NAV_MENU.height() + $FOOTER.height();

        $RIGHT_COL.css('min-height', contentHeight);
    };

    $SIDEBAR_MENU.find('a').on('click', function(ev) {
    	var $li = $(this).parent();

    	if ($li.is('.active')) {
    		$li.removeClass('active');
    		$('ul:first', $li).slideUp(function() {
    			setContentHeight();
    		});
    	} else {
            // prevent closing menu if we are on child menu
            if (!$li.parent().is('.child_menu')) {
            	$SIDEBAR_MENU.find('li').removeClass('active');
            	$SIDEBAR_MENU.find('li ul').slideUp();
            }
            
            $li.addClass('active');

            $('ul:first', $li).slideDown(function() {
            	setContentHeight();
            });
        }
    });

    // toggle small or large menu
    $MENU_TOGGLE.on('click', function() {
    	if ($BODY.hasClass('nav-md')) {
    		$BODY.removeClass('nav-md').addClass('nav-sm');
    		$MENU_TOGGLE.addClass('active');
    		$LEFT_COL.removeClass('scroll-view').removeAttr('style');

    		if ($SIDEBAR_MENU.find('li').hasClass('active')) {
    			$SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
    		}
    	} else {
    		$BODY.removeClass('nav-sm').addClass('nav-md');
    		$MENU_TOGGLE.removeClass('active');

    		if ($SIDEBAR_MENU.find('li').hasClass('active-sm')) {
    			$SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
    		}
    	}

    	setContentHeight();
    });

    // check active menu
    $SIDEBAR_MENU.find('a[href="' + URL + '"]').parent('li').addClass('current-page');

    $SIDEBAR_MENU.find('a').filter(function () {
    	return this.href == URL;
    }).parent('li').addClass('current-page').parents('ul').slideDown(function() {
    	setContentHeight();
    }).parent().addClass('active');

    // recompute content when resizing
    $(window).smartresize(function(){  
    	setContentHeight();
    });
});
// /Sidebar

// Panel toolbox
$(document).ready(function() {
	$('.collapse-link').on('click', function() {
		var $BOX_PANEL = $(this).closest('.x_panel'),
		$ICON = $(this).find('i'),
		$BOX_CONTENT = $BOX_PANEL.find('.x_content');

        // fix for some div with hardcoded fix class
        if ($BOX_PANEL.attr('style')) {
        	$BOX_CONTENT.slideToggle(200, function(){
        		$BOX_PANEL.removeAttr('style');
        	});
        } else {
        	$BOX_CONTENT.slideToggle(200); 
        	$BOX_PANEL.css('height', 'auto');  
        }

        $ICON.toggleClass('fa-chevron-up fa-chevron-down');
    });

	$('.close-link').click(function () {
		var $BOX_PANEL = $(this).closest('.x_panel');

		$BOX_PANEL.remove();
	});
});
// /Panel toolbox

// Tooltip
$(document).ready(function() {
	$('[data-toggle="tooltip"]').tooltip();
});
// /Tooltip

// Progressbar
if ($(".progress .progress-bar")[0]) {
    $('.progress .progress-bar').progressbar(); // bootstrap 3
}
// /Progressbar

// Switchery
$(document).ready(function() {
	if ($(".js-switch")[0]) {
		var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
		elems.forEach(function (html) {
			var switchery = new Switchery(html, {
				color: '#26B99A'
			});
		});
	}
});
// /Switchery

// iCheck
$(document).ready(function() {
	if ($("input.flat")[0]) {
		$(document).ready(function () {
			$('input.flat').iCheck({
				checkboxClass: 'icheckbox_flat-green',
				radioClass: 'iradio_flat-green'
			});
		});
	}
});
// /iCheck

// Table
$('table input').on('ifChecked', function () {
	checkState = '';
	$(this).parent().parent().parent().addClass('selected');
	countChecked();
});
$('table input').on('ifUnchecked', function () {
	checkState = '';
	$(this).parent().parent().parent().removeClass('selected');
	countChecked();
});

var checkState = '';

$('.bulk_action input').on('ifChecked', function () {
	checkState = '';
	$(this).parent().parent().parent().addClass('selected');
	countChecked();
});
$('.bulk_action input').on('ifUnchecked', function () {
	checkState = '';
	$(this).parent().parent().parent().removeClass('selected');
	countChecked();
});
$('.bulk_action input#check-all').on('ifChecked', function () {
	checkState = 'all';
	countChecked();
});
$('.bulk_action input#check-all').on('ifUnchecked', function () {
	checkState = 'none';
	countChecked();
});

function countChecked() {
	if (checkState === 'all') {
		$(".bulk_action input[name='table_records']").iCheck('check');
	}
	if (checkState === 'none') {
		$(".bulk_action input[name='table_records']").iCheck('uncheck');
	}

	var checkCount = $(".bulk_action input[name='table_records']:checked").length;

	if (checkCount) {
		$('.column-title').hide();
		$('.bulk-actions').show();
		$('.action-cnt').html(checkCount + ' Records Selected');
	} else {
		$('.column-title').show();
		$('.bulk-actions').hide();
	}
}

// Accordion
$(document).ready(function() {
	$(".expand").on("click", function () {
		$(this).next().slideToggle(200);
		$expand = $(this).find(">:first-child");

		if ($expand.text() == "+") {
			$expand.text("-");
		} else {
			$expand.text("+");
		}
	});
});

// NProgress
if (typeof NProgress != 'undefined') {
	$(document).ready(function () {
		NProgress.start();
	});

	$(window).load(function () {
		NProgress.done();
	});
}

/**
 * Resize function without multiple trigger
 * 
 * Usage:
 * $(window).smartresize(function(){  
 *     // code here
 * });
 */
 (function($,sr){
    // debouncing function from John Hann
    // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
    var debounce = function (func, threshold, execAsap) {
    	var timeout;

    	return function debounced () {
    		var obj = this, args = arguments;
    		function delayed () {
    			if (!execAsap)
    				func.apply(obj, args);
    			timeout = null; 
    		}

    		if (timeout)
    			clearTimeout(timeout);
    		else if (execAsap)
    			func.apply(obj, args);

    		timeout = setTimeout(delayed, threshold || 100); 
    	};
    };

    // smartresize 
    jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');




<!-- Popup -->
//mainMega1 Height
$('.main_dropdown #mainMega1, .main_dropdown #mainMega1 .right-part, .main_dropdown #mainMega1 .slct-type-dropdown').height(function(index, height) {
	return window.innerHeight - $(this).offset().top - 100;
});

//Scripts
$(document).ready(myfunction);
//$(window).on('resize',myfunction);

window.onresize = function() {
    myfunction();
};
function myfunction() {
//alert('function calleded');
$(document).click(function(e) {  
	if(e.target.id!='openmainmega'){
		$('div.overlay').hide();
		$('html').removeClass('noscroll');
		$('div#mainMega1').hide();
	}
});
	
	jQuery('body').on('click','#menu_toggle',function(){
		if(jQuery(window).width() < 500){
			
			if(jQuery(this).hasClass('active')){
				$('div.side-overlay').show();
				$('.toggle a').addClass('post');    
			}
			else{
				$('div.side-overlay').hide();
				$('.toggle a').removeClass('post');    
			}
		}
	});
	
	jQuery("#mainMega1 .btn_close").click(function(event){
		event.stopPropagation();
		jQuery( "#mainMega1, .overlay" ).hide();
		jQuery('html').removeClass('noscroll');
	});
	jQuery(".searchcommodity").click(function(event){
		event.stopPropagation();
	});
	function open(current){
		var get_class = jQuery('.slct-type-dropdown li.active').attr('id');  
		if(typeof(get_class)=='undefined' || get_class==""){
			get_class=jQuery('ul.slct-type-dropdown li:first-child').attr('id');
		}
		
		current.addClass(get_class).siblings().removeClass(get_class);
		current.siblings().removeClass(get_class);
		current.siblings().removeClass('active');
		current.attr('id','active').addClass('active');
		current.attr('id','active').siblings().attr('id','');
		
	}



	jQuery(".hightlight").click(function(event){
		event.stopPropagation();
	});

	if ($(window).width() > 1024) {	
		
		jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
			return window.innerHeight - $(this).offset().top - 250;
		});


		/*For tabs click commodity and location*/
		jQuery("#mainMega1 ul.com-loc-tabs li").click(function(event){
			event.preventDefault();

			jQuery(this).addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery(this).find('a').attr('href');
			jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');

			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery(this).attr('id',get_id);
			jQuery(this).siblings().attr('id','');
			jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('#mainMega1 .tab-content '+get_tab_content+' ul li' ).attr('class','');
		});
		
				/*For on popup sub li click code*/
		
		jQuery("#mainMega1 .tab-content ul li").click(function(event){
			event.stopPropagation();
			jQuery(this).closest('.filter_nested').next().show();	
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery(this).addClass(get_id+" active").siblings().attr('class','');
		});


		/*Click event for All Data Blue Button*/
		jQuery(".openmainmega").click(function(event){
			event.stopPropagation();
			if (jQuery(window).width() > 1200) {
			    if(jQuery(".search").hasClass('search-fixed') || jQuery(".input-group").hasClass('search-box')){ 	
					jQuery('html').addClass('noscroll');
				}
		    }
			jQuery('.side_overlay, #mainMega1 .super_region, #mainMega1 .right-part,#mainMega1 .dismiss2-back-btn').hide();

			jQuery("#mainMega1, div.overlay, #mainMega1 .left-part, #mainMega1 .dismiss1").show();

		});
		
		/*Click on category like agri*/
		jQuery("#mainMega1 .slct-type-dropdown li").click(function(event){
			event.stopPropagation();

			jQuery(this).addClass('active').siblings().removeClass('active');
			
			jQuery( ".dismiss2" ).show();
		});
		
		jQuery("#mainMega1 .super_region ul.selct-rgn-list li").click(function(event){
			event.stopPropagation();

			jQuery('#mainMega1 .left-part').hide(); 
			jQuery('#mainMega1 .right-part').show();
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');
			jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
			jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('#mainMega1 .tab-content '+get_tab_content+' ul li' ).attr('class','');
			jQuery('#mainMega1 .btn_next').show();
			jQuery('#mainMega1 .btn_back, #mainMega1 .btn_close').hide();
			
		});
		
		
		/*Main megapopup1 btn back*/
		jQuery("#mainMega1 .btn_back").click(function(event){
			event.stopPropagation();
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');
			jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');

			jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('#mainMega1 .tab-content '+get_tab_content+' ul li').attr('class','');
			jQuery( "#mainMega1 .btn_back, #mainMega1 .btn_close" ).hide();
			jQuery( "#mainMega1 .btn_next" ).show();
		});
		
		/*Main mega popup1 btn next*/
		jQuery("#mainMega1 .btn_next").click(function(event){
			event.stopPropagation();
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
			
			var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');
			
			jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');

			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
			jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
			
			jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('#mainMega1 .tab-content '+get_tab_content+' ul li').attr('class','');
			jQuery('#mainMega1 .btn_next').hide();
			jQuery('#mainMega1 .btn_back, #mainMega1 .btn_close').show();
		});
		
		
		
		/*Search page js code Start here*/

		jQuery(document).ready(function(){
			
			jQuery('.filters_container > div').hide();
			jQuery('.mainmega-popup1 .back-btn').hide();
		});
		
		/*Left Side bar li click*/
		jQuery("ul.sidebar_menu li").click(function(event){
			event.stopPropagation();
			jQuery(this).addClass("active").siblings().removeClass("active");
			var li_index = jQuery(this).index();
			jQuery(".overlay-whbg").show();
			jQuery(".filters_container").children('div').hide(); 
			jQuery(".filters_container > div").eq(li_index).show();
			jQuery(".filters_container > div").eq(li_index).find(".tab-content > div").not(":first-child").hide();

		});
		
		
		jQuery(".mainmega-popup1 ul li").click(function(event){
			event.stopPropagation();

			jQuery(this).closest('.filter_nested').next().show();
			jQuery(this).addClass('active').siblings().removeClass('active');
		});

		 jQuery(window).click(function() {
		    jQuery('.filters_container .mainmega-popup1').hide();
		    jQuery(".overlay-whbg").hide();
		  });
		
		/*Search page js End here*/

		/* Dashboard page js code Start here*/
		/* Dashboard page Left menu click js code Start here*/
		jQuery(document).ready(function(){
			jQuery('.left-side-megapopup > div').hide();
			jQuery('.mainmega-popup1 .back-btn').hide();
			jQuery(".overlay-whbg").hide();
		});

		/*Left Side bar li click*/
		jQuery(".category_location ul li a.leftmenuclick").click(function(event){
			event.stopPropagation();
			jQuery(".right_col .overlay-whbg").show();
			jQuery(this).closest("li").addClass("active");
			jQuery(this).closest("li").siblings().removeClass("active");
			var li_index = jQuery(this).closest("li").index();
			jQuery(".left-side-megapopup").children('div').hide(); 
			jQuery(".left-side-megapopup > div").eq(li_index).show();
			jQuery(".left-side-megapopup > div").eq(li_index).find(".tab-content > div").not(":first-child").hide();

		});

		jQuery(".mainmega-popup1 .btn-holder .btn").on("click", function (event) {
			event.stopPropagation();
			jQuery(this).closest('.mainmega-popup1').hide();
			jQuery('.overlay-whbg').hide();
		});

		jQuery(window).click(function() {
		    jQuery('.left-side-megapopup .mainmega-popup1').hide();
		    jQuery('.right_col .overlay-whbg').hide();
		    jQuery(".category_location ul li").removeClass("active");
		});

		

		/* Dashboard page Left menu click js code End here*/
		/* Dashboard page js code End here*/


	}	


	/*Media Screen Jquery*/			
	/*if ($(window).width() <= 1024 && $(window).width() > 767) {*/
		if ($(window).width() <= 1024) {

			jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
				return window.innerHeight - $(this).offset().top - 350;
			});

			/*ON click all data blue button*/
			jQuery(".openmainmega").click(function(event){
				event.stopPropagation();

				jQuery('.side_overlay, #mainMega1 .super_region, #mainMega1 .right-part').hide();
				jQuery("#mainMega1, div.overlay, #mainMega1 .left-part, #mainMega1 .dismiss1").show();
			});

			jQuery("#mainMega1 .slct-type-dropdown li").click(function(event){
				event.stopPropagation();

				jQuery(this).addClass('active').siblings().removeClass('active');
				jQuery( ".dismiss1" ).hide();
				jQuery( ".dismiss2,.dismiss2-back-btn" ).show();
			});

			jQuery("#mainMega1 .super_region ul.selct-rgn-list li").click(function(event){ 
				event.stopPropagation();

				jQuery('#mainMega1 .left-part').hide(); 
				jQuery('#mainMega1 .right-part').show();
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');
				jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');

				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');

				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
				jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();

				jQuery('.btn_back, .btn_close').hide();
				jQuery('.btn_next').show();


			});


			/*For tabs click commodity and location*/
			jQuery("#mainMega1 ul.com-loc-tabs li").click(function(event){
				event.stopPropagation();
				
				jQuery(this).addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery(this).find('a').attr('href');
				jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery(this).attr('id',get_id);
				jQuery(this).siblings().attr('id','');
				
				
				
				if(jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').hasClass('active')){

					jQuery('#mainMega1 .dismiss3, .dismiss3-back-btn, .btn_next').show();
					jQuery('#mainMega1 .dismiss4, #mainMega1 .dismiss5, #mainMega1 .dismiss4-back-btn, #mainMega1 .dismiss5-back-btn, #mainMega1 .dismiss6-back-btn, #mainMega1 .dismiss7-back-btn, #mainMega1 .dismiss8-back-btn, #mainMega1 .btn_back,   #mainMega1 .btn_close').hide();
				}
				if(jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').hasClass('active')){

					jQuery('#mainMega1 .dismiss6, #mainMega1 .dismiss6-back-btn, #mainMega1 .btn_back, #mainMega1 .btn_close').show();
					jQuery('#mainMega1 .dismiss7, #mainMega1 .dismiss8  #mainMega1 .dismiss4-back-btn, #mainMega1 .dismiss5-back-btn, #mainMega1 .dismiss3-back-btn, #mainMega1 .dismiss7-back-btn, #mainMega1 .dismiss8-back-btn, #mainMega1 .btn_next').hide();

				}

				
			});


			/*Main mega popup1 btn back*/
			jQuery("#mainMega1 .btn_back").click(function(event){
				event.stopPropagation();
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');
				jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');

				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');

				jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery( "#mainMega1 .btn_back, #mainMega1 .btn_close" ).hide();
				jQuery( "#mainMega1 .btn_next, #mainMega1 .dismiss3, #mainMega1 .dismiss3-back-btn" ).show();
			});

			/*Main mega popup1 btn next*/
			jQuery("#mainMega1 .btn_next").click(function(event){
				event.stopPropagation();
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');

				var get_tab_content=jQuery('#mainMega1 ul.com-loc-tabs li.active a').attr('href');

				jQuery('#mainMega1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('#mainMega1 ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');

				jQuery('#mainMega1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('#mainMega1 .btn_next').hide();
				jQuery('#mainMega1 .btn_back, #mainMega1 .btn_close, #mainMega1 .dismiss6-back-btn, #mainMega1 .dismiss6').show();
			});



			jQuery(".select-region li").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss2,.dismiss2-back-btn,.dismiss4-back-btn,.dismiss5-back-btn" ).hide();
				jQuery( ".dismiss3,.dismiss3-back-btn" ).show();
			});

			jQuery("#content-1 li, #content-11 li").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss3,.dismiss3-back-btn,.dismiss5-back-btn" ).hide();
				jQuery( ".dismiss4,.dismiss4-back-btn" ).show();
			});
			jQuery("#content-3 li, #content-6 li").click(function(event){
				event.stopPropagation();

			});
			jQuery(".selcomopen_first li").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss4,.dismiss4-back-btn,.dismiss2-back-btn" ).hide();
				jQuery( ".dismiss5,.dismiss5-back-btn" ).show();
			});
			jQuery("#content-4 li, #content-44 li").click(function(event){
				event.stopPropagation();

				jQuery( ".dismiss6,.dismiss6-back-btn,.dismiss2-back-btn" ).hide();
				jQuery( ".dismiss7,.dismiss7-back-btn" ).show();
			});
			jQuery("#content-5 li, #content-55 li").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss7,.dismiss7-back-btn" ).hide();
				jQuery( ".dismiss8,.dismiss8-back-btn" ).show();
			});

			jQuery(".dismiss2-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss2,.dismiss2-back-btn" ).hide();
				jQuery( ".dismiss1" ).show();
			});

			jQuery(".dismiss3-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss3,.dismiss3-back-btn,.right-part" ).hide();
				jQuery( ".dismiss2,.dismiss2-back-btn, .left-part" ).show();
				jQuery( ".btn_back,.btn_close" ).hide();
				jQuery( ".btn_next" ).show();
			});
		 
			jQuery("#mainMega1 .dismiss4-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss4,.dismiss4-back-btn" ).hide();
				jQuery( ".dismiss3,.dismiss3-back-btn,.right-part" ).show();
				jQuery( ".btn_back,.btn_close" ).hide();
				jQuery( ".btn_next" ).show();
			});
			jQuery(".dismiss5-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss5,.dismiss5-back-btn" ).hide();
				jQuery( ".dismiss4,.dismiss4-back-btn,.right-part" ).show();
				jQuery( ".btn_back,.btn_close" ).hide();
				jQuery( ".btn_next" ).show();
			});
		 
			jQuery("#mainMega1 .dismiss6-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss6,.dismiss6-back-btn,.right-part" ).hide();
				jQuery( ".dismiss2,.dismiss2-back-btn,.left-part" ).show();
				jQuery( ".btn_back,.btn_close" ).show();
				jQuery( ".btn_next" ).hide();
			});
			jQuery(".dismiss7-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss7,.dismiss7-back-btn" ).hide();
				jQuery( ".dismiss6,.dismiss6-back-btn,.right-part" ).show();
				jQuery( ".btn_back,.btn_close" ).show();
				jQuery( ".btn_next" ).hide();
			});
			jQuery(".dismiss8-back-btn").click(function(event){
				event.stopPropagation();
				jQuery( ".dismiss8,.dismiss8-back-btn" ).hide();
				jQuery( ".dismiss7,.dismiss7-back-btn,.right-part" ).show();
				jQuery( ".btn_back,.btn_close" ).show();
				jQuery( ".btn_next" ).hide();
			});
	 

			/*Search page js code Start here*/
			jQuery(window).click(function() {
			    jQuery('.filters_container .mainmega-popup1').hide();
			  });
			//jQuery(document).ready(function(){
				jQuery('.filters_container > div').hide();
				jQuery('.mainmega-popup1 .back-btn').show();
			//});
			
			/*Left Side bar li click*/
			jQuery("ul.sidebar_menu li").click(function(event){
				event.stopPropagation();
				jQuery(this).addClass("active").siblings().removeClass("active");
				var li_index = jQuery(this).index();
				$(".overlay-whbg").show();
				jQuery(".filters_container").children('div').hide(); 
				jQuery(".filters_container > div").eq(li_index).show();
				jQuery(".filters_container > div").eq(li_index).find(".tab-content > div").hide();
				jQuery(".filters_container > div").eq(li_index).find(".tab-content > div").eq(0).show();

			});
			
			/*Click on any li under main-mage popup1*/
			jQuery(".mainmega-popup1 ul li").click(function(event){
				event.stopPropagation();
					
				var parent_div_index = jQuery(this).closest('.filter_nested').index();
				if(parent_div_index<2){
					jQuery(this).closest('.filter_nested').hide();
					jQuery(this).closest('.filter_nested').next().show();
				}
			});
			
			//*Click on any li under main-mage popup1*/
			jQuery(".mainmega-popup1 .back-btn").click(function(event){
				event.stopPropagation();
		
				jQuery(this).closest('div.filter_nested').hide().prev().show();	
			});
			
			/*Search page js End here*/

			/* Dashboard page js code Start here*/
			/* Dashboard page Left menu click js code Start here*/
			//jQuery(document).ready(function(){
				jQuery('.left-side-megapopup > div').hide();
				jQuery(".overlay-whbg").hide();
			//});

			/*Left Side bar li click*/
			jQuery(".category_location ul li a.leftmenuclick").click(function(event){
				event.stopPropagation();
				jQuery(".right_col .overlay-whbg").show();
				jQuery(this).closest("li").addClass("active");
				jQuery(this).closest("li").siblings().removeClass("active");
				var li_index = jQuery(this).closest("li").index();
				jQuery(".left-side-megapopup").children('div').hide(); 
				jQuery(".left-side-megapopup > div").eq(li_index).show();
				jQuery(".left-side-megapopup > div").eq(li_index).find(".tab-content > div").not(":first-child").hide();
				jQuery('body').removeClass('nav-sm').addClass('nav-md');

			});

			jQuery(".mainmega-popup1 .btn-holder .btn").on("click", function (event) {
				event.stopPropagation();
				jQuery(this).closest('.mainmega-popup1').hide();
				jQuery('.overlay-whbg').hide();
			});

			jQuery(window).click(function() {
			   jQuery('.left-side-megapopup .mainmega-popup1').hide();
			   jQuery('.overlay-whbg').hide();
			});

			

			/* Dashboard page Left menu click js code End here*/
			/* Dashboard page js code End here*/
				
		}


		if ($(window).width() < 767) {

			jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
				return window.innerHeight - $(this).offset().top - 250;
			});
		 jQuery(".mainmega-popup1 .btn-holder .btn").on("click", function () {
			jQuery(this).closest('.mainmega-popup1').hide();
			jQuery('.right_col .overlay-whbg, .side-overlay').hide();
		});
	} 



		/*$("ul#type1 li").click(function(){ 
			$(this).addClass('selected'); 

		});
		$(".deselect").click(function(event){ 
			event.stopPropagation();
			$(".ul#type1 li").removeClass('selected');    
		});

		$(".select").click(function(event){  
			event.stopPropagation();
		}); */


	
}
