﻿using PayPal.Api;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ZDalyWeb.PayPal.Model
{
    public class CreditCardVM
    {
        [Required]
        public string Number { get; set; }
        [Required]
        public int Code { get; set; }
        [Required]
        public string HolderName { get; set; }
        [Required]
        public int Month { get; set; }
        [Required]
        public int Year { get; set; }

        public int Type { get; set; }

        public string CardType { get; set; }
        public int PlanType { get; set; }
    }

    public class PaymentDoneVM
    {
        public string PaymentId { get; set; }
        public string CustomerName { get; set; }
        public string Method { get; set; }
        public string Email { get; set; }

        public string TransactionId { get; set; }

        public Sale Sale { get; set; }

        public string Plan { get; set; }

    }
    public class PaymentPlan
    {
        public decimal Amount { get; set; }
        public string PlanName { get; set; }
        public int Type { get; set; }
    }
    public class Payments
    {
        public int ID { get; set; }
        public string Payment_ID { get; set; }
        public decimal Total_Amt { get; set; }
        public string Currency { get; set; }
        public decimal Transaction_Fee { get; set; }
        public string Payment_Method { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }

        public int PlanType { get; set; }
    }
}