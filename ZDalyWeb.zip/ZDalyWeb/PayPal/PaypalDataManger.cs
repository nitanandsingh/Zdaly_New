﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ZDalyWeb.PayPal.Model;
using Dapper;

namespace ZDalyWeb.PayPal
{
    public class PaypalDataManger
    {
        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(ConfigurationManager.ConnectionStrings["ZdalyPkConStr"].ConnectionString);
            }
        }

        public int AddOrderPayment(Payments payments)
        {
            string query = @"insert into PAYMENTS( Payment_ID,Total_Amt,Currency,Transaction_Fee,Payment_Method,[Status],PlanType,CreatedDate)
                    VALUES(@Payment_ID,@Total_Amt,@Currency,@Transaction_Fee,@Payment_Method,@Status,@PlanType,@CreatedDate)";
            try
            {
                using (IDbConnection cn = Connection)
                {
                    int id = cn.Execute(query, new { Payment_ID = payments.Payment_ID, Total_Amt = payments.Total_Amt, Currency = payments.Currency, Status = payments.Status, Transaction_Fee = payments.Transaction_Fee, Payment_Method = payments.Payment_Method, PlanType = payments.PlanType, CreatedDate = payments.CreatedDate });
                    return id;
                }
            }
            catch
            {
                return 0;
            }

        }
        public int UpdateTransactionStatus(Payments payments)
        {
            string query = @"UPDATE PAYMENTS SET Transaction_Fee=@Transaction_Fee, [Status]=@Status Where Payment_ID = @Payment_ID ";
            try
            {
                using (IDbConnection cn = Connection)
                {
                    int id = cn.Execute(query, new { Payment_ID = payments.Payment_ID, Status = payments.Status, Transaction_Fee = payments.Transaction_Fee });
                    return id;
                }
            }
            catch
            {
                return 0;
            }

        }

        public List<Payments> GetHistory()
        {
            using (IDbConnection cn = Connection)
            {
               return cn.Query<Payments>("Select * from PAYMENTS").ToList();
            }

        }
    }
}