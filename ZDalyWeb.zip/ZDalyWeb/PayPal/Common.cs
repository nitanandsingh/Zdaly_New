﻿using PayPal.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZDalyWeb.PayPal
{
    public static class Common
    {
        public static APIContext GetAPIContext(string accessToken = "")
        {
            // Use OAuthTokenCredential to request an access token from PayPal
            var apiContext = new APIContext(string.IsNullOrEmpty(accessToken) ? GetAccessToken() : accessToken);
            apiContext.Config = GetConfig();
            return apiContext;
        }
        private static string GetAccessToken()
        {
            var config = GetConfig();
            string accessToken = new OAuthTokenCredential(config).GetAccessToken();
            return accessToken;
        }
        public static Dictionary<string, string> GetConfig()
        {
            return ConfigManager.Instance.GetProperties();
        }
               
       

    }
}