namespace ZDalyWeb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UserName : DbMigration
    {
        public override void Up()
        {
            AddColumn("AspNetUsers", "UserName", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
        }
    }
}
