﻿
// Set CartoDB username
var cartoDBusername = "mayh";

var mapsmall = null;
var maplarge = null;
var commodityid = null;
var superregionid = null;
var geojson;
var selectedmap;
// control that shows state info on hover
var info;
var legend;
var query;
var jsoncontrollerstring;
var sql = new cartodb.SQL({ user: 'mayh', format: 'geojson' });
var polygon;

$(document).ready(function () {
    // Create a new Leaflet map.
    mapsmall = L.map('world-map-gdp-small', {
        zoomControl: true,
        legend: false,
        center: [40, -95],
        zoom: 4,
        minZoom: 1,
        scrollWheelZoom: true,
        dragging: false
    });
    
    LoadMapSmall();
});

function LoadMapSmall() {

    var cartoCountriesSmall = 'https://mayh.cartodb.com/api/v2/viz/b095ec4c-3a72-11e6-9e6d-0e674067d321/viz.json';

    cartodb.createLayer(mapsmall, cartoCountriesSmall, { legends: false }).addTo(mapsmall).done(function (layers) {

    }).error(function (err) {
        console.info(err);
    });
}

function LoadMapLarge() {

    var cartoCountriesLarge = 'https://mayh.cartodb.com/api/v2/viz/1fe05d9e-3a87-11e6-9850-0ea31932ec1d/viz.json';

    cartodb.createLayer(maplarge, cartoCountriesLarge, { legends: false }).addTo(maplarge).done(function (layers) {

    }).error(function (err) {
        console.info(err);
    });
}

//listen for screen resize events
window.addEventListener('resize', function (event) {
    // get the width of the screen after the resize event
    var width = document.documentElement.clientWidth;
    // tablets are between 768 and 922 pixels wide
    // phones are less than 768 pixels wide
    // set the zoom level

    if (mapsmall != null) {
        if (width < 400) {
            mapsmall.setZoom(2);
        } else if (width > 399 && width < 768) {
            mapsmall.setZoom(3);
        } else {
            mapsmall.setZoom(4);
        }

        L.Util.requestAnimFrame(mapsmall.invalidateSize, mapsmall, !1, mapsmall._container);
    }

    if (maplarge != null) {
        if (width < 400) {
            maplarge.setZoom(2);
        } else if (width > 399 && width < 768) {
            maplarge.setZoom(4);
        } else {
            maplarge.setZoom(5);
        }

        L.Util.requestAnimFrame(maplarge.invalidateSize, maplarge, !1, maplarge._container);
    }
});

$("body").on('shown', '#world-map-gdp-small', function () {
    L.Util.requestAnimFrame(mapsmall.invalidateSize, mapsmall, !1, mapsmall._container);
});

$("body").on('shown', '#world-map-gdp', function () {
    L.Util.requestAnimFrame(maplarge.invalidateSize, maplarge, !1, maplarge._container);
});

$(".b_collapse").click(function (event) {
    event.stopPropagation();

    if (mapsmall == null) {
        mapsmall = L.map('world-map-gdp-small', {
            zoomControl: true,
            legend: false,
            center: [40, -95],
            zoom: 4,
            minZoom: 1,
            scrollWheelZoom: true,
            dragging: false
        });

        LoadMapSmall();

        var width = document.documentElement.clientWidth;

        if (mapsmall != null) {
            if (width < 400) {
                mapsmall.setZoom(2);
            } else if (width > 399 && width < 768) {
                mapsmall.setZoom(3);
            } else {
                mapsmall.setZoom(4);
            }

            L.Util.requestAnimFrame(mapsmall.invalidateSize, mapsmall, !1, mapsmall._container);
        }
    }

    $("#small_map").show();
    $("#full_map").hide();

    if (maplarge != null) {
        info = null;
        legend = null;
        maplarge.remove();
        maplarge = null;
    }
});

$(":contains('China')").closest('a').click(function () {
    maplarge.setView(new L.LatLng(35, 100), 5);
});

$(":contains('Europe')").closest('a').click(function () {
    maplarge.setView(new L.LatLng(57, 17), 4);
});

$(":contains('India')").closest('a').click(function () {
    maplarge.setView(new L.LatLng(22, 80), 5);
});

$(":contains('United States')").closest('a').click(function () {
    maplarge.setView(new L.LatLng(40, -95), 5);
});

$(":contains('Country')").closest('button').addClass("disabled");

$(":contains('Country')").closest('button').click(function () {
    $('#countryAlert').fadeIn()
});

$('#countryAlert a').click(function () {
    $('#countryAlert').hide();
});

$(".interactive_heat").click(function (event) {
    event.stopPropagation();
    $("#countryAlert").hide();

    if (maplarge == null) {
        maplarge = L.map('world-map-gdp', {
            zoomControl: true,
            legend: false,
            center: [40, -95],
            zoom: 5,
            minZoom: 1,
            scrollWheelZoom: true,
            dragging: false
        });

        LoadMapLarge();
        LoadGeolocateButton(maplarge);

        var width = document.documentElement.clientWidth;

        if (maplarge != null) {
            if (width < 400) {
                maplarge.setZoom(2);
            } else if (width > 399 && width < 768) {
                maplarge.setZoom(4);
            } else {
                maplarge.setZoom(5);
            }

            L.Util.requestAnimFrame(maplarge.invalidateSize, maplarge, !1, maplarge._container);
        }
    }

    $("#full_map").show();
    $("#small_map").hide();

    if (mapsmall != null) {
        mapsmall.remove();
        mapsmall = null;
    }

    selectedmap = angular.element('[ng-controller=dashboardController]').scope();
    selectedmap.mapselectedItem = null;

    if (selectedmap.MapName != null) {
        selectedmap.MapName = null;
    }

    selectedmap.SelectedMap = null;
});

$('#statemapbutton').click(function () {
    //cartodb.createLayer(maplarge, {
    //    user_name: 'mayh',
    //    type: 'cartodb',
    //    sublayers: [
    //    {
    //        sql: "select * from cb_2015_us_state_500k_1",
    //        cartocss: '#cb_2015_us_state_500k_1 {polygon-fill: #FFFFCC; line-color: #FFFFFF; line-width: 0.5; polygon-opacity: 0.8; line-opacity: 1;} #cb_2015_us_state_500k_1 [ aland <= 1477946338495.01] {polygon-fill: #0C2C84;}#cb_2015_us_state_500k_1 [ aland <= 259946737005.01] {polygon-fill: #225EA8;}#cb_2015_us_state_500k_1 [ aland <= 187530692786.5] {polygon-fill: #1D91C0;}#cb_2015_us_state_500k_1 [ aland <= 142032189197.01] {polygon-fill: #41B6C4;}#cb_2015_us_state_500k_1 [ aland <= 113893360151.5] {polygon-fill: #7FCDBB;}#cb_2015_us_state_500k_1 [ aland <= 70062437581.5] {polygon-fill: #C7E9B4;}#cb_2015_us_state_500k_1 [ aland <= 10705159835.5] {polygon-fill: #FFFFCC;}'
    //    }]
    //})
    //.addTo(maplarge)
    //.done(function (layer) {

    //}).error(function (err) {
    //    console.log(err);
    //});
});

$('#countymapbutton').click(function () {
    //cartodb.createLayer(maplarge, {
    //    user_name: 'mayh',
    //    type: 'cartodb',
    //    sublayers: [
    //    {
    //        sql: "select * from cb_2015_us_county_500k",
    //        cartocss: '#cb_2015_us_county_500k {polygon-fill: #FFFFCC; line-color: #FFFFFF; line-width: 0.5; polygon-opacity: 0.8; line-opacity: 1;} #cb_2015_us_county_500k [ aland <= 376824381721.01] {polygon-fill: #0C2C84;}#cb_2015_us_county_500k [ aland <= 3360268387.01] {polygon-fill: #225EA8;}#cb_2015_us_county_500k [ aland <= 2267985235.01] {polygon-fill: #1D91C0;}#cb_2015_us_county_500k [ aland <= 1752310524] {polygon-fill: #41B6C4;}#cb_2015_us_county_500k [ aland <= 1452917761] {polygon-fill: #7FCDBB;}#cb_2015_us_county_500k [ aland <= 1133976298] {polygon-fill: #C7E9B4;}#cb_2015_us_county_500k [ aland <= 816287771] {polygon-fill: #FFFFCC;}'
    //    }]
    //})
    //.addTo(maplarge)
    //.done(function (layer) {

    //}).error(function (err) {
    //    console.log(err);
    //});
});

$("#menu6.dropdown-menu").click(function () {
    selectedmap = angular.element('[ng-controller=dashboardController]').scope();

    //$("#drop4").click(function () {
        //AdjustWidth(this);
    //});

    if (selectedmap.SelectedMap != null) {
        //$(":contains('State')").closest('button').focus();

        if (info != null) {
            maplarge.removeControl(info);
        }
        
        if (legend != null) {
            maplarge.removeControl(legend);
        }

        if (maplarge != null) {
            maplarge.remove();
            maplarge = null;
        }

        if (maplarge == null) {
            maplarge = L.map('world-map-gdp', {
                zoomControl: true,
                legend: false,
                center: [40, -95],
                zoom: 5,
                minZoom: 1,
                scrollWheelZoom: true,
                dragging: false
            });

            LoadMapLarge();
            LoadGeolocateButton(maplarge);
        }

        maplarge.setView(new L.LatLng(40, -95), 5);

        $.ajax({
            url: "api/map",
            type: "POST",
            data: { "": selectedmap.SelectedMap.MapName_Id },
            success: function (data) {
                jsoncontrollerstring = JSON.parse(data);
                console.log(jsoncontrollerstring);
                query = "select * from cb_2015_us_state_500k_1 WHERE name in (" + getValues(jsoncontrollerstring, 'State').join(",") + ")";

                // create a layer
                var cartoUnitedStates = 'https://' + cartoDBusername + '.cartodb.com/api/v2/viz/5e0641ee-4304-11e6-be3c-0e3a376473ab/viz.json';

                cartodb.createLayer(maplarge, {
                    user_name: 'mayh',
                    type: 'cartodb',
                    sublayers: [
                    {
                        sql: query,
                        cartocss: '#cb_2015_us_state_500k_1 {polygon-fill: #FFFFCC; line-color: #FFFFFF; line-width: 0.5; polygon-opacity: 0.8; line-opacity: 1;} #cb_2015_us_state_500k_1 [ aland <= 1477946338495.01] {polygon-fill: #0C2C84;}#cb_2015_us_state_500k_1 [ aland <= 259946737005.01] {polygon-fill: #225EA8;}#cb_2015_us_state_500k_1 [ aland <= 187530692786.5] {polygon-fill: #1D91C0;}#cb_2015_us_state_500k_1 [ aland <= 142032189197.01] {polygon-fill: #41B6C4;}#cb_2015_us_state_500k_1 [ aland <= 113893360151.5] {polygon-fill: #7FCDBB;}#cb_2015_us_state_500k_1 [ aland <= 70062437581.5] {polygon-fill: #C7E9B4;}#cb_2015_us_state_500k_1 [ aland <= 10705159835.5] {polygon-fill: #FFFFCC;}',
                        interactivity: 'cartodb_id, name'
                    }]
                })
                .addTo(maplarge)
                .done(function (layer) {
                    layer.setInteraction(true);

                    info = L.control({ position: 'bottomright' });
                    //legend = L.control({ position: 'bottomright' });

                    info.onAdd = function (maplarge) {
                        this._div = L.DomUtil.create('div', 'info');
                        this.update();
                        return this._div;
                    };

                    info.update = function (props) {
                        this._div.innerHTML = '<h4>' + selectedmap.SelectedMap.MapName + '</h4>' + (props ?
                            '<b>' + props.State + '</b><br />' + props.Value + ' Acres'
                            : 'Hover over a state');
                    };

                    info.addTo(maplarge);

                    //var legendarray = getLegendValues(jsoncontrollerstring, 'Value');

                    //var maxLegend = Math.max.apply(Math, legendarray);

                    //legend.onAdd = function (maplarge) {

                    //    var div = L.DomUtil.create('div', 'info legend'),
                    //        grades = [0, Math.round(maxLegend / 64), Math.round(maxLegend / 32), Math.round(maxLegend / 16), Math.round(maxLegend / 8), Math.round(maxLegend / 4), Math.round(maxLegend / 2), maxLegend],
                    //        labels = [],
                    //        from, to;

                    //    for (var i = 0; i < grades.length - 1; i++) {
                    //        from = grades[i];
                    //        to = grades[i + 1];

                    //        labels.push(
                    //            '<i style="background:' + getColor(from + 1, maxLegend) + '"></i> ' +
                    //            from + (to ? '&ndash;' + to : '+'));
                    //    }

                    //    div.innerHTML = labels.join('<br>');
                    //    return div;
                    //};

                    //legend.addTo(maplarge);

                    layer.on('featureOver', function (e, pos, latlng, data) {
                        showFeature(data.cartodb_id);

                        for (var i = 0; i < jsoncontrollerstring.length; i++) {
                            if (jsoncontrollerstring[i].State == data.name) {
                                info.update(jsoncontrollerstring[i]);
                            }
                        }
                    });
                }).error(function (err) {
                    console.log(err);
                });
            },
            error: function (xhr, status, p3, p4) {
                var err = "Error " + " " + status + " " + p3;
                if (xhr.responseText && xhr.responseText[0] == "{")
                    err = JSON.parse(xhr.responseText).message;
            }
        });
    }
});

function showFeature(cartodb_id) {
    sql.execute("select ST_Simplify(the_geom, 0.1) as the_geom from cb_2015_us_state_500k_1 where cartodb_id = {{cartodb_id}}", { cartodb_id: cartodb_id }).done(function (geojson) {
        if (polygon) {
            maplarge.removeLayer(polygon);
        }
        polygon = L.geoJson(geojson, {
            style: {
                color: "#000",
                fillColor: "#fff",
                weight: 2,
                opacity: 0.65
            }
        }).addTo(maplarge);
    });
}

// Loads the geolocate button, which pans & 
// zooms to the user's current location
function LoadGeolocateButton(maplarge) {

    var options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };

    var success = function (pos) {
        var crd = pos.coords;

        //var latHTML = '<div> Latitude : ' + crd.latitude.toFixed(4) + '</div>';
        //var lonHTML = '<div> Longitude: ' + crd.longitude.toFixed(4) + '</div>';
        //var accHTML = '<div> Accuracy: ' + (crd.accuracy * 3.28084).toFixed(0) + ' feet</div>';

        //$('#divGeolocateDialog .modal-body')
		//	.empty()
		//	.append(latHTML)
		//	.append(lonHTML)
		//	.append(accHTML);

        //$('#divGeolocateDialog').modal('show');
        maplarge.setView([crd.latitude, crd.longitude], 8);
    };

    var error = function (err) {
        var errHTML = '<div> Error: ' + err.message + '</div>';
        //$('#divGeolocateDialog .modal-body')
		//	.empty()
		//	.append(errHTML);

        //$('#divGeolocateDialog').modal('show');
    };

    $('#divGeolocate').click(function () {
        navigator.geolocation.getCurrentPosition(success, error, options);
    });
}

// get color depending on population density value
function getColor(d, m) {
    return d > m/2 ? '#0C2C84' :
           d > m/4 ? '#225EA8' :
           d > m/8 ? '#1D91C0' :
           d > m/16 ? '#41B6C4' :
           d > m/32 ? '#7FCDBB' :
           d > m/64 ? '#C7E9B4' :
                    '#FFFFCC';
}

function style(feature) {
    return {
        weight: 2,
        opacity: 1,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7,
        fillColor: getColor(feature.properties.density)
    };
}

function highlightFeature(e) {
    var layer = e.target;

    layer.setStyle({
        weight: 5,
        color: '#666',
        dashArray: '',
        fillOpacity: 0.7
    });

    if (!L.Browser.ie && !L.Browser.opera) {
        layer.bringToFront();
    }

    info.update(layer.feature.properties);
}

function resetHighlight(e) {
    geojson.resetStyle(e.target);
    info.update();
}

function zoomToFeature(e) {
    maplarge.fitBounds(e.target.getBounds());
}

function onEachFeature(feature, layer) {
    layer.on({
        mouseover: highlightFeature,
        mouseout: resetHighlight,
        click: zoomToFeature
    });
}

//return an array of state values that match on a certain key for queries
function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getValues(obj[i], key));
        } else if (i == key) {
            objects.push("'" + obj[i] + "'");
        }
    }
    return objects;
}

//return an array of integer values that match on a certain key for the legends
function getLegendValues(obj, key) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getLegendValues(obj[i], key));
        } else if (i == key) {
            objects.push(obj[i]);
        }
    }
    return objects;
}

//Auto adjust dropdown list initial box to longest text length
//function AdjustWidth(ddl) {
//    var maxWidth = 0;
//    var setWidth = null;

//    $("#menu6 li a").each(function (i) {
//        if ($(this).text().length > maxWidth) {
//            maxWidth = $(this).text().length;
//        }
//    });

//    //alert(maxWidth);
//    setWidth = maxWidth * 8;

//    $(ddl).css("width", setWidth);
//}