/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var URL = window.location,
    $BODY = $('body'),
    $MENU_TOGGLE = $('#menu_toggle'),
    $SIDEBAR_MENU = $('#sidebar-menu'),
    $SIDEBAR_FOOTER = $('.sidebar-footer'),
    $LEFT_COL = $('.left_col'),
    $RIGHT_COL = $('.right_col'),
    $NAV_MENU = $('.nav_menu'),
    $FOOTER = $('footer');

// Sidebar
$(document).ready(function() {
    // TODO: This is some kind of easy fix, maybe we can improve this
    var setContentHeight = function () {
        // reset height
        $RIGHT_COL.css('min-height', $(window).height());

        var bodyHeight = $BODY.height(),
            leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
            contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

        // normalize content
        contentHeight -= $NAV_MENU.height() + $FOOTER.height();

        $RIGHT_COL.css('min-height', contentHeight);
    };

    $SIDEBAR_MENU.find('a').on('click', function(ev) {
        var $li = $(this).parent();

        if ($li.is('.active')) {
            $li.removeClass('active');
            $('ul:first', $li).slideUp(function() {
                setContentHeight();
            });
        } else {
            // prevent closing menu if we are on child menu
            if (!$li.parent().is('.child_menu')) {
                $SIDEBAR_MENU.find('li').removeClass('active');
                $SIDEBAR_MENU.find('li ul').slideUp();
            }
            
            $li.addClass('active');

            $('ul:first', $li).slideDown(function() {
                setContentHeight();
            });
        }
    });

    // toggle small or large menu
    $MENU_TOGGLE.on('click', function() {
        if ($BODY.hasClass('nav-md')) {
            $BODY.removeClass('nav-md').addClass('nav-sm');
			$MENU_TOGGLE.addClass('active');
            $LEFT_COL.removeClass('scroll-view').removeAttr('style');

            if ($SIDEBAR_MENU.find('li').hasClass('active')) {
                $SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
             }
        } else {
            $BODY.removeClass('nav-sm').addClass('nav-md');
			$MENU_TOGGLE.removeClass('active');
				
            if ($SIDEBAR_MENU.find('li').hasClass('active-sm')) {
                $SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
            }
        }

        setContentHeight();
    });

    // check active menu
    $SIDEBAR_MENU.find('a[href="' + URL + '"]').parent('li').addClass('current-page');

    $SIDEBAR_MENU.find('a').filter(function () {
        return this.href == URL;
    }).parent('li').addClass('current-page').parents('ul').slideDown(function() {
        setContentHeight();
    }).parent().addClass('active');

    // recompute content when resizing
    //$(window).smartresize(function(){  
    //    setContentHeight();
    //});
});
// /Sidebar

// Panel toolbox
$(document).ready(function() {
    $('.collapse-link').on('click', function() {
        var $BOX_PANEL = $(this).closest('.x_panel'),
            $ICON = $(this).find('i'),
            $BOX_CONTENT = $BOX_PANEL.find('.x_content');
        
        // fix for some div with hardcoded fix class
        if ($BOX_PANEL.attr('style')) {
            $BOX_CONTENT.slideToggle(200, function(){
                $BOX_PANEL.removeAttr('style');
            });
        } else {
            $BOX_CONTENT.slideToggle(200); 
            $BOX_PANEL.css('height', 'auto');  
        }

        $ICON.toggleClass('fa-chevron-up fa-chevron-down');
    });

    $('.close-link').click(function () {
        var $BOX_PANEL = $(this).closest('.x_panel');

        $BOX_PANEL.remove();
    });
});
// /Panel toolbox

// Tooltip
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
});
// /Tooltip

// Progressbar
if ($(".progress .progress-bar")[0]) {
    $('.progress .progress-bar').progressbar(); // bootstrap 3
}
// /Progressbar

// Switchery
$(document).ready(function() {
    if ($(".js-switch")[0]) {
        var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        elems.forEach(function (html) {
            var switchery = new Switchery(html, {
                color: '#26B99A'
            });
        });
    }
});
// /Switchery

// iCheck
$(document).ready(function() {
    if ($("input.flat")[0]) {
        $(document).ready(function () {
            $('input.flat').iCheck({
                checkboxClass: 'icheckbox_flat-green',
                radioClass: 'iradio_flat-green'
            });
        });
    }
});
// /iCheck

// Table
$('table input').on('ifChecked', function () {
    checkState = '';
    $(this).parent().parent().parent().addClass('selected');
    countChecked();
});
$('table input').on('ifUnchecked', function () {
    checkState = '';
    $(this).parent().parent().parent().removeClass('selected');
    countChecked();
});

var checkState = '';

$('.bulk_action input').on('ifChecked', function () {
    checkState = '';
    $(this).parent().parent().parent().addClass('selected');
    countChecked();
});
$('.bulk_action input').on('ifUnchecked', function () {
    checkState = '';
    $(this).parent().parent().parent().removeClass('selected');
    countChecked();
});
$('.bulk_action input#check-all').on('ifChecked', function () {
    checkState = 'all';
    countChecked();
});
$('.bulk_action input#check-all').on('ifUnchecked', function () {
    checkState = 'none';
    countChecked();
});

function countChecked() {
    if (checkState === 'all') {
        $(".bulk_action input[name='table_records']").iCheck('check');
    }
    if (checkState === 'none') {
        $(".bulk_action input[name='table_records']").iCheck('uncheck');
    }

    var checkCount = $(".bulk_action input[name='table_records']:checked").length;

    if (checkCount) {
        $('.column-title').hide();
        $('.bulk-actions').show();
        $('.action-cnt').html(checkCount + ' Records Selected');
    } else {
        $('.column-title').show();
        $('.bulk-actions').hide();
    }
}

// Accordion
$(document).ready(function() {
    $(".expand").on("click", function () {
        $(this).next().slideToggle(200);
        $expand = $(this).find(">:first-child");

        if ($expand.text() == "+") {
            $expand.text("-");
        } else {
            $expand.text("+");
        }
    });
});

// NProgress
if (typeof NProgress != 'undefined') {
    $(document).ready(function () {
        NProgress.start();
    });

    $(window).load(function () {
        NProgress.done();
    });
}

/**
 * Resize function without multiple trigger
 * 
 * Usage:
 * $(window).smartresize(function(){  
 *     // code here
 * });
 */
(function($,sr){
    // debouncing function from John Hann
    // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
    var debounce = function (func, threshold, execAsap) {
      var timeout;

        return function debounced () {
            var obj = this, args = arguments;
            function delayed () {
                if (!execAsap)
                    func.apply(obj, args);
                timeout = null; 
            }

            if (timeout)
                clearTimeout(timeout);
            else if (execAsap)
                func.apply(obj, args);

            timeout = setTimeout(delayed, threshold || 100); 
        };
    };

    // smartresize 
    jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');




<!-- Popup -->
//mainMega1 Height
$('.main_dropdown #mainMega1, .main_dropdown #mainMega1 .right-part, .main_dropdown #mainMega1 .slct-type-dropdown').height(function(index, height) {
     return window.innerHeight - $(this).offset().top - 100;
});

//Scripts
$(document).ready(myfunction);
//$(window).on('resize',myfunction);
$(window).resize(function(){
myfunction();
//alert('dsfs');
})
function myfunction() {
//alert('function calleded');
	$(document).click(function(e) {  
		if(e.target.id!='openmainmega'){
			$('div.overlay').hide();
			$('div.mainmega-popup1').hide();
		}
	});

	/*$('.openmainmega').click(function(event){
		event.stopPropagation();
		$('div.overlay').show();
		$('div.mainmega-popup1').show();
	}); */
	
	$('#left_megamenu,.dropsubmenu,.location-dropdown').height(function(index, height) {
		return window.innerHeight - $(this).offset().top;
	});

	$('body').on('click','.side-menu.upper-side-nav li',function(){
			//jQuery('.side_overlay').show();
	});
	
	jQuery('body').on('click','#menu_toggle',function(){
		if(jQuery(window).width() < 500){
			
			if(jQuery(this).hasClass('active')){
				$('div.side-overlay').show();
				$('.toggle a').addClass('post');    
			}
			else{
				$('div.side-overlay').hide();
				$('.toggle a').removeClass('post');    
			}
		}
	});
	
	/*jQuery(".openmainmega").click(function(event){
		event.stopPropagation();
		
		jQuery(".mainmega-popup1").show();
		jQuery(".dismiss1").show();
		jQuery(".dismiss2, .right-part,.dismiss4,.dismiss5,.dismiss7,.dismiss8").hide();
		jQuery('.selct-rgn-list li#active,#content-1 li#active,#content-11 li#active,.selcomopen_first li#active,.selcomopen_second li#active,#content-4 li#active,#content-44 li#active,.selmopen_frst li#active,.selmopen_scnd li#active').attr('class','').attr('id',''); 
		jQuery('.slct-type-dropdown li.active').removeClass('active');

	});*/
	/*jQuery(".selct-rgn-list li").click(function(event){
		event.stopPropagation();
		var cls = jQuery('.slct-type-dropdown li.active').attr('id');  
		jQuery(this).addClass(cls);
		jQuery(this).addClass('active').attr('id','active');
		jQuery(this).siblings().removeClass('active').attr('id','');
		jQuery(this).siblings().removeClass(cls);
	});*/

	/*jQuery(".slct-type-dropdown li").click(function(event){ 
		event.stopPropagation();
		jQuery(".super_region").show();
		var get_cls = jQuery(this).attr('class');
		jQuery(this).addClass('active').siblings().removeClass('active');
		jQuery('.com-loc-tabs li.active').attr('id',get_cls);
		jQuery('.selct-rgn-list li#active,#content-1 li#active,#content-11 li#active,.selcomopen_first li#active,.selcomopen_second li#active,#content-4 li#active,#content-44 li#active,.selmopen_frst li#active,.selmopen_scnd li#active').attr('class','').addClass('active');
		jQuery('.selct-rgn-list li#active,#content-1 li#active,#content-11 li#active,.selcomopen_first li#active,.selcomopen_second li#active,#content-4 li#active,#content-44 li#active,.selmopen_frst li#active,.selmopen_scnd li#active').addClass(get_cls);	
	});*/

	/*jQuery(".super_region li").click(function(event){
		event.stopPropagation();
		jQuery(".left-part").hide();
		jQuery(".right-part").show();

	});*/

	/*jQuery("#content-11 li").click(function(event){
		event.stopPropagation();
		$(".selcomopen_first").show();
		open(jQuery(this));
	});

	jQuery(".selcomopen_first li").click(function(event){
		event.stopPropagation();
		$(".selcomopen_second").show();
		open(jQuery(this));
	});

	jQuery(".selcomopen_second li").click(function(event){
	 event.stopPropagation();
	open(jQuery(this));
	});

	jQuery("#content-44 li").click(function(event){
		event.stopPropagation();
		alert("dsfsd");
		$(".selmopen_frst").show();
		open(jQuery(this));
	});

	jQuery(".selmopen_frst li").click(function(event){
		event.stopPropagation();
		$(".selmopen_scnd").show();	
		open(jQuery(this));
	});

	jQuery(".selmopen_scnd li").click(function(event){
		event.stopPropagation();
		open(jQuery(this));
	});

	/*jQuery(".com-loc-tabs li").click(function(event){
		event.stopPropagation();
		
		var tab_content=jQuery(this).find('a').attr('href');  
		if($(this).hasClass('active')){
		//alert('yes');
		}
		else{

			$(tab_content).siblings().attr('class','tab-pane fade');
			$(tab_content).attr('class','tab-pane fade active in');

		}

		jQuery('.com-loc-tabs li').attr('id','');  
		var cls = jQuery('.slct-type-dropdown li.active').attr('id');
		jQuery(this).attr('id',cls);
		var index = $(this).index(); 
		if(index == 1){  
			jQuery( ".btn_back,.btn_close" ).show();
			jQuery( ".btn_next" ).hide();
		}
		if(index == 0){ 
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		}
	});*/

	/*jQuery(".btn_next, ul.com-loc-tabs li:nth-child(2)").click(function(event){*/
	/*jQuery(".btn_next").click(function(event){
		event.stopPropagation();
		var get_class = jQuery('.slct-type-dropdown li.active').attr('id');  
		jQuery( "ul.com-loc-tabs li:nth-child(2)" ).addClass("active");
		jQuery( "ul.com-loc-tabs li:nth-child(2)" ).attr('id',get_class);
		jQuery( "ul.com-loc-tabs li:nth-child(1)" ).removeClass("active");
		jQuery( "ul.com-loc-tabs li:nth-child(1)" ).attr('id','');
		jQuery( "#tab2" ).addClass("active in");
		jQuery( "#tab1" ).removeClass("active in");
		jQuery( "#tab22" ).addClass("active in");
		jQuery( "#tab11" ).removeClass("active in");
		jQuery( ".btn_back,.btn_close" ).show();
		jQuery( ".btn_next" ).hide();
	});*/

	/*jQuery(".btn_back, ul.com-loc-tabs li:nth-child(1)").click(function(event){*/
	/*jQuery(".btn_back").click(function(event){
		event.stopPropagation();
		var get_class = jQuery('.slct-type-dropdown li.active').attr('id');  
		jQuery( "ul.com-loc-tabs li:nth-child(1)" ).addClass("active");
		jQuery( "ul.com-loc-tabs li:nth-child(1)" ).attr('id',get_class);
		jQuery( "ul.com-loc-tabs li:nth-child(2)" ).removeClass("active");
		jQuery( "ul.com-loc-tabs li:nth-child(2)" ).attr('id','');
		jQuery( "#tab1" ).addClass("active in");
		jQuery( "#tab2" ).removeClass("active in");
		jQuery( "#tab11" ).addClass("active in");
		jQuery( "#tab22" ).removeClass("active in");
		jQuery( ".btn_back,.btn_close" ).hide();
		jQuery( ".btn_next" ).show();
	});*/

	jQuery(".btn_close").click(function(event){
		event.stopPropagation();
		jQuery( ".mainmega-popup,.side_overlay" ).hide();
	});
	jQuery(".mainmega-popup1 .btn_close").click(function(event){
		event.stopPropagation();
		jQuery( ".mainmega-popup1, .overlay" ).hide();
	});
	jQuery(".searchcommodity").click(function(event){
		event.stopPropagation();
	});
	function open(current){
		var get_class = jQuery('.slct-type-dropdown li.active').attr('id');  
		if(typeof(get_class)=='undefined' || get_class==""){
			get_class=jQuery('ul.slct-type-dropdown li:first-child').attr('id');
		}
		
			current.addClass(get_class).siblings().removeClass(get_class);
			current.siblings().removeClass(get_class);
			current.siblings().removeClass('active');
			current.attr('id','active').addClass('active');
			current.attr('id','active').siblings().attr('id','');
		
	}

	jQuery(".dimssis-mainmega i").click(function(event){
		event.stopPropagation();
		jQuery( ".mainmega-popup, .side_overlay" ).hide();	
	});

	jQuery(".hightlight").click(function(event){
		event.stopPropagation();
	});

    if ($(window).width() > 1024) {	
		
		jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
			 return window.innerHeight - $(this).offset().top - 250;
		});
		/*For commodity left menu click*/
		jQuery(".mainnavmega").click(function(event){ 
			event.stopPropagation();
			
			jQuery('.mainmega-popup, .mainmega-popup .right-part').show();
			jQuery('.side_overlay').show();
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
		
			jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
			//jQuery('.mainmega-popup1 .tab-content ul').parent().hide();
			
			jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('.mainmega-popup .tab-content '+get_tab_content+' ul li' ).attr('class','');
			jQuery('.btn_next').show();
			jQuery('.btn_back, .btn_close').hide();
			
		});
		
		 /*Main mega popup btn back*/
		jQuery(".mainmega-popup .btn_back").click(function(event){
		event.stopPropagation();
			jQuery('.mainmega-popup, .mainmega-popup .right-part').show();
			jQuery('.side_overlay').show();
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
		
			jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');

			jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('.mainmega-popup .tab-content '+get_tab_content+' ul li').attr('class','');
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		});
		
		/*For location left menu click*/
		jQuery(".mainnavmegaloc").click(function(event){
				event.stopPropagation();
				jQuery('.mainmega-popup .left-part').hide();
				jQuery('.side_overlay').show();
				jQuery('.mainmega-popup, .mainmega-popup .right-part').show();
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
				jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
				
				jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup .tab-content '+get_tab_content+' ul li' ).attr('class','');
				jQuery('.btn_next').hide();
				jQuery('.btn_back, .btn_close').show();

		 });
		 
		 
		/*For on popup sub li click code*/
		
		jQuery(".mainmega-popup .tab-content ul li").click(function(event){
			event.stopPropagation();
			
			jQuery(this).closest('.list-unstyled').parent().next().next().show();
			open(jQuery(this));
		
		});
		 
		 /*Main mega popup btn next*/
		jQuery(".mainmega-popup .btn_next").click(function(event){
			event.stopPropagation();
				jQuery('.mainmega-popup .left-part').hide();
				jQuery('.side_overlay').show();
				jQuery('.mainmega-popup, .mainmega-popup .right-part').show();
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
				jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
				
				jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content+' ul li').attr('class','');
				jQuery('.btn_next').hide();
				jQuery('.btn_back, .btn_close').show();
		});
		 
		
		/*For tabs click commodity and location*/
		jQuery(".mainmega-popup ul.com-loc-tabs li").click(function(event){
				event.stopPropagation();

				jQuery(this).addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery(this).find('a').attr('href');
				jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery(this).attr('id',get_id);
				jQuery(this).siblings().attr('id','');
				
				jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
		 });
		 
		 
		 
		 /*For tabs click commodity and location*/
		jQuery(".mainmega-popup1 ul.com-loc-tabs li").click(function(event){
				event.stopPropagation();
				jQuery(this).addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery(this).find('a').attr('href');
				jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery(this).attr('id',get_id);
				jQuery(this).siblings().attr('id','');
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content+' ul li' ).attr('class','');
		 });
		 
		 
		 
		
		
		/*For on popup1 sub li click code*/
		var i=0;
		jQuery(".mainmega-popup1 .tab-content ul li").click(function(event){
			event.stopPropagation();
			
			i++;
			jQuery(this).closest('.list-unstyled').parent().next().next().show();
			var cu_width = jQuery('.mainmega-popup1 .right-part.animated.fadeInUp').outerWidth();
			
			if(i==1){
				localStorage.setItem('cu_width',cu_width);
			}
			
			var nw_width = cu_width + ( cu_width * 40) / 100;
			jQuery('.mainmega-popup1 .right-part').animate({width: nw_width});
			open(jQuery(this));
		
		});

		/*Click event for All Data Blue Button*/
		jQuery(".openmainmega").click(function(event){
			event.stopPropagation();
			
			jQuery('.mainmega-popup, .side_overlay, .mainmega-popup1 .super_region, .mainmega-popup1 .right-part,.mainmega-popup1 .dismiss2-back-btn').hide();
	
			jQuery(".mainmega-popup1, div.overlay, .mainmega-popup1 .left-part, .mainmega-popup1 .dismiss1").show();
			
			//jQuery('.mainmega-popup .tab-content '+get_tab_content+' ul li' ).attr('class','');
			
	
		});
		
		/*Click on category like agri*/
		jQuery(".mainmega-popup1 .slct-type-dropdown li").click(function(event){
			event.stopPropagation();
		
		
			jQuery(this).addClass('active').siblings().removeClass('active');
			//jQuery( ".dismiss1" ).hide();
			jQuery( ".dismiss2" ).show();
		});
		
		//jQuery(".mainmega-popup1 .super_region ul.selct-rgn-list li").click(function(event){
		//	event.stopPropagation();
		
		//	jQuery('.mainmega-popup1 .left-part').hide(); 
		//	/*if(localStorage.getItem('cu_width')!=""){
				
		//		jQuery('.mainmega-popup1 .right-part').css('width',localStorage.getItem('cu_width')+'px'); 
		//	}*/
		//	 try {
		//		  if (localStorage.getItem('cu_width')) {
		//			jQuery('.mainmega-popup1 .right-part').css('width',localStorage.getItem('cu_width')+'px');
		//		  }
		//		} catch (exception) { }
		//	jQuery('.mainmega-popup1 .right-part').show();
		//	jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
		//	var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
		//	jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
		//	var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
		//	jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
		//	jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
		//	jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
		//	jQuery('.mainmega-popup1 .tab-content '+get_tab_content+' ul li' ).attr('class','');
		//	jQuery('.mainmega-popup1 .btn_next').show();
		//	jQuery('.mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close').hide();
			
		//	//open(jQuery(this));
		
		//});
		
		
		/*Main mega popup1 btn back*/
		jQuery(".mainmega-popup1 .btn_back").click(function(event){
		event.stopPropagation();
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
			jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
		
			jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery('.mainmega-popup1 .tab-content '+get_tab_content+' ul li').attr('class','');
			jQuery( ".mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close" ).hide();
			jQuery( ".mainmega-popup1 .btn_next" ).show();
		});
		
		/*Main mega popup1 btn next*/
		jQuery(".mainmega-popup1 .btn_next").click(function(event){
			event.stopPropagation();
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
			
				var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
			
				jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
			
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content+' ul li').attr('class','');
				jQuery('.mainmega-popup1 .btn_next').hide();
				jQuery('.mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close').show();
		});
		
	
		
		$('body').on('click','.side-menu.upper-side-nav li',function(){
		
			if($(this).hasClass('open')){

					if(jQuery('.mainmega-popup:visible').length==0){

						jQuery('.side_overlay').hide();
						jQuery('#mainMega .right-part').hide(); 
					}
					else{
					
						jQuery('.mainmega-popup').hide();
						jQuery('.side_overlay').show();
					}
					
			}
			else{
			
					if(jQuery('.mainmega-popup:visible').length>=0){
						
						jQuery('.mainmega-popup').hide();
						jQuery('.side_overlay').show();
						jQuery('#mainMega .right-part').show(); 
					}
					else{
						jQuery('#mainMega .right-part').hide(); 
						jQuery('.side_overlay').show();
					}
					
			}

		});
		
	}	


	/*Media Screen Jquery*/			
	/*if ($(window).width() <= 1024 && $(window).width() > 767) {*/
	if ($(window).width() <= 1024) {

		jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
			 return window.innerHeight - $(this).offset().top - 350;
		});
		
		/*ON click all data blue button*/
		jQuery(".openmainmega").click(function(event){
			event.stopPropagation();
			
			jQuery('.mainmega-popup, .side_overlay, .mainmega-popup1 .super_region, .mainmega-popup1 .right-part').hide();
			jQuery(".mainmega-popup1, div.overlay, .mainmega-popup1 .left-part, .mainmega-popup1 .dismiss1").show();
		});
		
		jQuery(".mainmega-popup1 .slct-type-dropdown li").click(function(event){
			event.stopPropagation();
		
			jQuery(this).addClass('active').siblings().removeClass('active');
			jQuery( ".dismiss1" ).hide();
			jQuery( ".dismiss2,.dismiss2-back-btn" ).show();
		});
		
		
		jQuery(".mainmega-popup1 .super_region ul.selct-rgn-list li").click(function(event){ 
			event.stopPropagation();
			
			jQuery('.mainmega-popup1 .left-part').hide(); 
			jQuery('.mainmega-popup1 .right-part').show();
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
			jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');

			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
			jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			/*if(jQuery( "ul.com-loc-tabs li:nth-child(1)" ).hasClass('active')){
				jQuery( ".right-part,.dismiss3-back-btn,.dismiss3" ).show();
			}else{
				jQuery( ".right-part,.dismiss6-back-btn,.dismiss6" ).show();
			} */
			
			jQuery('.btn_back, .btn_close').hide();
			jQuery('.btn_next').show();
		
			
		});
		
		
		 /*For tabs click commodity and location*/
		jQuery(".mainmega-popup1 ul.com-loc-tabs li").click(function(event){
				event.stopPropagation();
				
				jQuery(this).addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery(this).find('a').attr('href');
				jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery(this).attr('id',get_id);
				jQuery(this).siblings().attr('id','');
				
				
				
			if(jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').hasClass('active')){
				
				jQuery('.mainmega-popup1 .dismiss3, .dismiss3-back-btn, .btn_next').show();
				jQuery('.mainmega-popup1 .dismiss4, .mainmega-popup1 .dismiss5, .mainmega-popup1 .dismiss4-back-btn, .mainmega-popup1 .dismiss5-back-btn, .mainmega-popup1 .dismiss6-back-btn, .mainmega-popup1 .dismiss7-back-btn, .mainmega-popup1 .dismiss8-back-btn, .mainmega-popup1 .btn_back,   .mainmega-popup1 .btn_close').hide();
			}
			if(jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').hasClass('active')){
				
				jQuery('.mainmega-popup1 .dismiss6, .mainmega-popup1 .dismiss6-back-btn, .mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close').show();
				jQuery('.mainmega-popup1 .dismiss7, .mainmega-popup1 .dismiss8  .mainmega-popup1 .dismiss4-back-btn, .mainmega-popup1 .dismiss5-back-btn, .mainmega-popup1 .dismiss3-back-btn, .mainmega-popup1 .dismiss7-back-btn, .mainmega-popup1 .dismiss8-back-btn, .mainmega-popup1 .btn_next').hide();

			}
			
				
		 });
		 
		 
		 /*Main mega popup1 btn back*/
		jQuery(".mainmega-popup1 .btn_back").click(function(event){
			event.stopPropagation();
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
			jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
		
			jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			jQuery( ".mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close" ).hide();
			jQuery( ".mainmega-popup1 .btn_next, .mainmega-popup1 .dismiss3, .mainmega-popup1 .dismiss3-back-btn" ).show();
		});
		
		/*Main mega popup1 btn next*/
		jQuery(".mainmega-popup1 .btn_next").click(function(event){
			event.stopPropagation();
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
			
				var get_tab_content=jQuery('.mainmega-popup1 ul.com-loc-tabs li.active a').attr('href');
			
				jQuery('.mainmega-popup1 '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('.mainmega-popup1 ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
			
				jQuery('.mainmega-popup1 .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup1 .btn_next').hide();
				jQuery('.mainmega-popup1 .btn_back, .mainmega-popup1 .btn_close, .mainmega-popup1 .dismiss6-back-btn, .mainmega-popup1 .dismiss6').show();
		});
		 
		/*For main mega popup code*/
		//left menu1 click
		jQuery(".mainnavmega").click(function(event){
			event.stopPropagation();
			if($(window).width()<767){
				$('body').attr('class','nav-md');
			}
			
			jQuery('.mainmega-popup, .mainmega-popup .right-part, .mainmega-popup .dismiss3').show();
			jQuery('.side_overlay').show();
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').addClass('active').siblings().removeClass('active');
			var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
		
			jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
			
			var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').attr('id',get_id);
			jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').siblings().attr('id','');
			
			jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
			
			jQuery('.mainmega-popup .dismiss4-back-btn, .mainmega-popup .dismiss5-back-btn, .mainmega-popup .dismiss6-back-btn, .mainmega-popup .dismiss7-back-btn, .mainmega-popup .dismiss8-back-btn').hide();
			
			jQuery('.btn_next').show();
			jQuery('.btn_back, .btn_close').hide();
			
		
		});
		
		jQuery(".mainnavmegaloc").click(function(event){
				event.stopPropagation();
				if($(window).width()<767){
					$('body').attr('class','nav-md');
				}
				jQuery('.mainmega-popup .left-part').hide();
				jQuery('.side_overlay').show();
				jQuery('.mainmega-popup, .mainmega-popup .right-part, .mainmega-popup .dismiss6').show();
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').addClass('active').siblings().removeClass('active');
				var get_tab_content=jQuery('.mainmega-popup ul.com-loc-tabs li.active a').attr('href');
				jQuery('.mainmega-popup '+get_tab_content).addClass('active in').siblings().removeClass('active in');
				
				var get_id = jQuery('.slct-type-dropdown li.active').attr('id');
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').attr('id',get_id);
				jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').siblings().attr('id','');
				
				jQuery('.mainmega-popup .tab-content '+get_tab_content).find('ul').parent(':not(:first)').hide();
				jQuery('.mainmega-popup .tab-content '+get_tab_content+' ul li').attr('class','');
				
				jQuery('.mainmega-popup .dismiss4-back-btn, .mainmega-popup .dismiss5-back-btn, .mainmega-popup .dismiss6-back-btn, .mainmega-popup .dismiss7-back-btn, .mainmega-popup .dismiss8-back-btn').hide();
				
				jQuery('.btn_next').hide();
				jQuery('.btn_back, .btn_close').show();
		 });
		
		
		/*For tabs click commodity and location*/
		jQuery(".mainmega-popup ul.com-loc-tabs li").click(function(event){
				event.stopPropagation();
				jQuery(this).addClass('active').siblings().removeClass('active');
				if(jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(1)').hasClass('active')){
					jQuery('.mainnavmega').click();
				}
				if(jQuery('.mainmega-popup ul.com-loc-tabs li:nth-child(2)').hasClass('active')){
					
					jQuery('.mainnavmegaloc').click();

				}
			
		 });
		 
		 /*Main mega popup btn back*/
		jQuery(".mainmega-popup .btn_back").click(function(event){
			event.stopPropagation();
			
			jQuery('.mainnavmega').click();
			
		});
		
		/*Main mega popup btn next*/
		jQuery(".mainmega-popup .btn_next").click(function(event){
			event.stopPropagation();
				jQuery('.mainnavmegaloc').click();

		});
		 
		
		jQuery(".select-region li").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss2,.dismiss2-back-btn,.dismiss4-back-btn,.dismiss5-back-btn" ).hide();
			jQuery( ".dismiss3,.dismiss3-back-btn" ).show();
		});
		
		jQuery("#content-1 li, #content-11 li").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss3,.dismiss3-back-btn,.dismiss5-back-btn" ).hide();
			jQuery( ".dismiss4,.dismiss4-back-btn" ).show();
		});
		jQuery("#content-3 li, #content-6 li").click(function(event){
			event.stopPropagation();
		
		});
		jQuery(".selcomopen_first li").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss4,.dismiss4-back-btn,.dismiss2-back-btn" ).hide();
			jQuery( ".dismiss5,.dismiss5-back-btn" ).show();
		});
		jQuery("#content-4 li, #content-44 li").click(function(event){
			event.stopPropagation();
			
			jQuery( ".dismiss6,.dismiss6-back-btn,.dismiss2-back-btn" ).hide();
			jQuery( ".dismiss7,.dismiss7-back-btn" ).show();
		});
		jQuery("#content-5 li, #content-55 li").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss7,.dismiss7-back-btn" ).hide();
			jQuery( ".dismiss8,.dismiss8-back-btn" ).show();
		});

		jQuery(".dismiss2-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss2,.dismiss2-back-btn" ).hide();
			jQuery( ".dismiss1" ).show();
		});

		jQuery(".dismiss3-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss3,.dismiss3-back-btn,.right-part" ).hide();
			jQuery( ".dismiss2,.dismiss2-back-btn, .left-part" ).show();
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		});
		jQuery(".mainmega-popup .dismiss4-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss4,.dismiss4-back-btn" ).hide();
			jQuery( ".dismiss3, .right-part" ).show();
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		});
		jQuery(".mainmega-popup1 .dismiss4-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss4,.dismiss4-back-btn" ).hide();
			jQuery( ".dismiss3,.dismiss3-back-btn,.right-part" ).show();
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		});
		jQuery(".dismiss5-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss5,.dismiss5-back-btn" ).hide();
			jQuery( ".dismiss4,.dismiss4-back-btn,.right-part" ).show();
			jQuery( ".btn_back,.btn_close" ).hide();
			jQuery( ".btn_next" ).show();
		});
		jQuery(".mainmega-popup .dismiss6-back-btn").click(function(event){
			event.stopPropagation();
			$(".mainnavmega").click();
		});
		jQuery(".mainmega-popup1 .dismiss6-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss6,.dismiss6-back-btn,.right-part" ).hide();
			jQuery( ".dismiss2,.dismiss2-back-btn,.left-part" ).show();
			jQuery( ".btn_back,.btn_close" ).show();
			jQuery( ".btn_next" ).hide();
		});
		jQuery(".dismiss7-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss7,.dismiss7-back-btn" ).hide();
			jQuery( ".dismiss6,.dismiss6-back-btn,.right-part" ).show();
			jQuery( ".btn_back,.btn_close" ).show();
			jQuery( ".btn_next" ).hide();
		});
		jQuery(".dismiss8-back-btn").click(function(event){
			event.stopPropagation();
			jQuery( ".dismiss8,.dismiss8-back-btn" ).hide();
			jQuery( ".dismiss7,.dismiss7-back-btn,.right-part" ).show();
			jQuery( ".btn_back,.btn_close" ).show();
			jQuery( ".btn_next" ).hide();
		});
		
		jQuery('body').on('click','.side-menu.upper-side-nav li:nth-child(2)',function(){

			if($(this).hasClass('open')){
				jQuery('.side_overlay').hide();
				jQuery('.dropdown-menu.megamenu.location-dropdown').hide(); 
					
			}
			else{
					jQuery('.mainmega-popup').hide();
					jQuery('.side_overlay').show();
					jQuery('.dropdown-menu.megamenu.location-dropdown').show(); 
			
			}

		});
		
		
		
		
		
	}
	
	
			
	if ($(window).width() < 767) {
	
		jQuery('.main_dropdown #mainMega1 .right-part .listbg').height(function(index, height) {
			 return window.innerHeight - $(this).offset().top - 250;
		});
		/*jQuery(".mainnavmega").click(function(event){
				event.stopPropagation();
				
				$('body').attr('class','nav-md');
				/*jQuery(".mainmega-popup").show();
				$('.side-overlay').css('display','none');
		 });*/
		 
		 
		 /*jQuery(".mainnavmegaloc").click(function(event){
				event.stopPropagation();
				
				$('body').attr('class','nav-md');
				jQuery(".mainmega-popup .right-part").show();
				$('.side-overlay').css('display','none');
		 });*/
		 
		 /*jQuery(".mainmega-popup .btn_next").click(function(event){
			event.stopPropagation();

			if(jQuery('.mainmega-popup:visible').length>0){
				var tab_content=jQuery('.mainmega-popup .com-loc-tabs li:nth-child(2)').find('a').attr('href');  
				jQuery(tab_content+' div :first-child').show();	
				jQuery(tab_content+' div :first-child').next().show();	
			}
			
			if(jQuery('.mainmega-popup1:visible').length>0){
				var tab_content=jQuery('.mainmega-popup1 .com-loc-tabs li:nth-child(2)').find('a').attr('href');  
				jQuery(tab_content+' div :first-child').show();	
				jQuery(tab_content+' div :first-child').next().show();	
			}
			
			jQuery('.mainmega-popup .tab-content '+tab_content+' ul li').attr('class','');
			
			
		});*/
		 
	
		 /*jQuery(".com-loc-tabs li").click(function(event){
			event.stopPropagation();
			var tab_content=jQuery(this).find('a').attr('href');  
			jQuery(tab_content+' div :first-child').show();	
			jQuery(tab_content+' div :first-child').next().show();	
			
		});*/
	}  
	
}
