﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using ZdalyBO.Model;
using ZDalyBAL;

namespace ZDalyWeb.Controllers
{
    public class RegisterController : Controller
    {
        public ActionResult SignUp()
        {
            return View();
        }


        [HttpPost]
        public ActionResult SignUp(UserRegistraionBO objUser)
        {
            if (ModelState.IsValid)
            {
                RegisterBAL.SignUp(objUser);
            }
            return View();
        }
        

    }
}
