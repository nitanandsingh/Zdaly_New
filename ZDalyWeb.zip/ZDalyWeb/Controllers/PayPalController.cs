﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using PayPal.Api;
using ZDalyWeb.PayPal;
using ZDalyWeb.PayPal.Model;


namespace ZDalyWeb.Controllers
{
    public class PayPalController : Controller
    {
        public ActionResult CheckOut()
        {
            PaymentPlan payPlan = null;
            if (Session["PLAN"] == null)
            {
                payPlan = new PaymentPlan();
                payPlan.Amount = 5;
                payPlan.PlanName = "Developers";
                payPlan.Type = 2;
            }
            else
            {
                payPlan = (PaymentPlan)Session["PLAN"];

            }
            ViewBag.Amount = payPlan.Amount;
            ViewBag.Plan = payPlan.PlanName;
            ViewBag.PlanType = payPlan.Type;
            return View();
        }

        public ActionResult PayWithPayPal(string paymentType = "paypal", int planType = 0)
        {
            string accessToken = "";
            var apiContext = Common.GetAPIContext(accessToken);
            string payerId = Request.Params["PayerID"];

            if (string.IsNullOrEmpty(payerId))
            {
                var selectedPlan = ChoosePlan(planType);
                #region Transaction Items
                //  Items within a transaction.
                var itemList = new ItemList()
                {
                    items = new List<Item>() 
                   {
                       new Item()
                       {
                           name = selectedPlan.PlanName,
                           currency = "USD",
                           price = selectedPlan.Amount.ToString("#.##"),
                           quantity = "1" 
                       }
                   },
                    shipping_address = null
                };

                Amount amnt = new Amount();
                amnt.currency = "USD";
                amnt.total = selectedPlan.Amount.ToString("#.##");

                List<Transaction> transactionList = new List<Transaction>();
                Transaction tran = new Transaction();
                tran.description = "Paypal Method developer plan";
                tran.amount = amnt;
                tran.item_list = itemList;

                transactionList.Add(tran);

                #endregion

                #region Payer Info
                Payer payr = new Payer();
                payr.payment_method = paymentType;
                // payr.funding_instruments = null;
                if (paymentType == "credit_card")
                {
                    payr.funding_instruments = new List<FundingInstrument>();
                    payr.funding_instruments.Add(new FundingInstrument()
                    {
                        credit_card = new CreditCard()
                        {
                            cvv2 = "874",
                            expire_month = 10,
                            expire_year = 2021,
                            first_name = "Test",
                            last_name = "Credit",
                            number = "4032036700160508",
                            type = "visa"
                        }
                    });
                    payr.payer_info = new PayerInfo();
                    payr.payer_info.email = "tester.net5@gmail.com";
                }

                #endregion

                Payment pymnt = new Payment();
                pymnt.intent = "sale";
                pymnt.payer = payr;
                pymnt.transactions = transactionList;

                string guid = Convert.ToString((new Random()).Next(100000));
                if (paymentType == "paypal")
                {
                    #region Redirect URLS
                    // These URLs will determine how the user is redirected from PayPal once they have either approved or canceled the payment.
                    var baseURI = Request.Url.Scheme + "://" + Request.Url.Authority + "/paypal/paywithpaypal";
                    var redirectUrl = baseURI + "?guid=" + guid;
                    var redirUrls = new RedirectUrls()
                    {
                        cancel_url = redirectUrl + "&cancel=true",
                        return_url = redirectUrl
                    };
                    #endregion
                    pymnt.redirect_urls = redirUrls;
                }

                Payment createdPayment = pymnt.Create(apiContext);

                #region Local DB
                // insert payment into DB
                PaypalDataManger paypalDB = new PaypalDataManger();
                Payments payments = new Payments();
                payments.PlanType = planType;
                payments.Payment_Method = "PAYPAL";
                payments.Payment_ID = createdPayment.id;
                payments.Status = "PROGRESS";
                payments.Total_Amt = selectedPlan.Amount;
                var transaction_fee = createdPayment.transactions[0].related_resources.Count>0?createdPayment.transactions[0].related_resources[0].sale.transaction_fee:null;
                payments.Transaction_Fee = transaction_fee == null ? 0 : Convert.ToDecimal(transaction_fee.value);
                payments.CreatedDate = DateTime.Now;
                int id = paypalDB.AddOrderPayment(payments);
                #endregion


                if (paymentType == "paypal")
                {
                    var links = createdPayment.links.GetEnumerator();
                    while (links.MoveNext())
                    {
                        var link = links.Current;
                        if (link.rel.ToLower().Trim().Equals("approval_url"))
                        {
                            Session.Add(guid, createdPayment.id);
                            return Redirect(link.href);
                        }
                    }
                }
                else
                {
                    return RedirectToAction("GetPaymentInfo", new { paymentId = createdPayment.id });
                    // return View("GetPaymentInfo", createdPayment);
                }



            }
            else
            {
                var guid = Request.Params["guid"];
                var paymentId = Session[guid] as string;
                // Using the information from the redirect, setup the payment to execute.
                var paymentExecution = new PaymentExecution() { payer_id = payerId };
                var payment = new Payment() { id = paymentId };

                Payment executedPayment = payment.Execute(apiContext, paymentExecution);
                PaypalDataManger paypalDB = new PaypalDataManger();
                Payments payments = new Payments();
                payments.PlanType = planType;
                payments.Payment_Method = "PAYPAL";
                payments.Payment_ID = executedPayment.id;
                payments.Status = executedPayment.transactions[0].related_resources[0].sale.state;

                var transaction_fee = executedPayment.transactions[0].related_resources.Count > 0 ? executedPayment.transactions[0].related_resources[0].sale.transaction_fee : null;
                payments.Transaction_Fee = transaction_fee == null ? 0 : Convert.ToDecimal(transaction_fee.value);
          
                int id = paypalDB.UpdateTransactionStatus(payments);
                //return View("GetPaymentInfo", executedPayment);
                return RedirectToAction("GetPaymentInfo", new { paymentId = executedPayment.id });
                //return View(executedPayment);
            }

            return null;
        }

        public ActionResult GetPaymentInfo(string paymentId = "")
        {
            PaymentDoneVM paymentDoneVM = new PaymentDoneVM();
            if (string.IsNullOrEmpty(paymentId)) { return null; }
            else
            {


                string accessToken = "";
                var apiContext = Common.GetAPIContext(accessToken);
                var payment = Payment.Get(apiContext, paymentId);
                paymentDoneVM.PaymentId = paymentId;
                paymentDoneVM.Method = "PayPal";
                Sale sale = payment.transactions[0].related_resources[0].sale;
                paymentDoneVM.Sale = sale;

                paymentDoneVM.Plan = payment.transactions[0].item_list.items[0].name;

                if (payment.payer.payment_method == "credit_card")
                {
                    CreditCard card = payment.payer.funding_instruments[0].credit_card;
                    paymentDoneVM.CustomerName = card.first_name + " " + card.last_name;
                    paymentDoneVM.Method = "Credit Card";
                    paymentDoneVM.Email = "tester.net5@gmail.com";
                    ViewBag.CardNumber = card.number;
                }
                else
                {
                    paymentDoneVM.CustomerName = payment.payer.payer_info.first_name + " " + payment.payer.payer_info.last_name;
                    paymentDoneVM.Email = payment.payer.payer_info.email;
                }


                return View(paymentDoneVM);
            }

        }


        public JsonResult CreditCard(CreditCardVM obj)
        {
            try
            {
                var config = ConfigManager.Instance.GetProperties();

                var selectedPlan = ChoosePlan(obj.PlanType);

                // Use OAuthTokenCredential to request an access token from PayPal
                var accessToken = new OAuthTokenCredential(config).GetAccessToken();
                var apiContext = new APIContext(accessToken);
                string first_name = obj.HolderName.Split(' ')[0];
                string last_name = obj.HolderName.Split(' ').Length > 1 ? obj.HolderName.Split(' ')[1] : obj.HolderName.Split(' ')[0];
                var transaction = new Transaction()
                {
                    amount = new Amount()
                    {
                        currency = "USD",
                        total = selectedPlan.Amount.ToString("#.##"),
                        //details = new Details()
                        //{
                        //    shipping = "2",
                        //    subtotal = "5",
                        //    tax = "3"
                        //}
                    },
                    description = "This is the payment transaction description.",
                    item_list = new ItemList()
                    {
                        items = new List<Item>()
                    {
                        new Item()
                        {
                            name = selectedPlan.PlanName,
                            currency = "USD",
                            price = selectedPlan.Amount.ToString("#.##"),
                            quantity = "1"
                            
                        }
                    }
                        //shipping_address = new ShippingAddress
                        //{
                        //    city = "Johnstown",
                        //    country_code = "US",
                        //    line1 = "52 N Main ST",
                        //    postal_code = "43210",
                        //    state = "OH",
                        //    recipient_name = "Joe Buyer"
                        //}
                    },
                    invoice_number = Convert.ToString((new Random()).Next(100000))
                };

                // A resource representing a Payer that funds a payment.
                var payer = new Payer()
                {
                    payment_method = obj.Type == 0 ? "debit_card" : "credit_card",
                    funding_instruments = new List<FundingInstrument>()
                {
                    new FundingInstrument()
                    {
                        credit_card = new CreditCard()
                        {
                            billing_address = new Address()
                            {
                                city = "Johnstown",
                                country_code = "US",
                                line1 = "52 N Main ST",
                                postal_code = "43210",
                                state = "OH"
                            },
                            cvv2 = "111",
                            expire_month = 10,
                            expire_year = 2021,
                            first_name =first_name,
                            last_name = last_name,
                            number = obj.Number,
                            type = obj.CardType
                        }
                    }
                },
                    payer_info = new PayerInfo
                    {
                        email = "tester.net5@email.com"
                    }
                };

                // A Payment resource; create one using the above types and intent as `sale` or `authorize`
                var payment = new Payment()
                {
                    intent = "sale",
                    payer = payer,
                    transactions = new List<Transaction>() { transaction }
                };


                // Create a payment using a valid APIContext
                var createdPayment = payment.Create(apiContext);

                #region Local DB
                // insert payment into DB
                PaypalDataManger paypalDB = new PaypalDataManger();
                Payments payments = new Payments();
                payments.PlanType = obj.PlanType;
                payments.Payment_Method = "CREDIT";
                payments.Payment_ID = createdPayment.id;
                payments.Status = "COMPLETED";
                payments.Total_Amt = selectedPlan.Amount;
                var transaction_fee = createdPayment.transactions[0].related_resources.Count > 0 ? createdPayment.transactions[0].related_resources[0].sale.transaction_fee : null;
                payments.Transaction_Fee = transaction_fee == null ? 0 : Convert.ToDecimal(transaction_fee.value);
                payments.CreatedDate = DateTime.Now;
                int id = paypalDB.AddOrderPayment(payments);
                #endregion

                return Json(new { success = true, Id = createdPayment.id });
            }
            catch
            {

            }
            return Json(new { success = false });
        }

        Transaction paypalTransaction()
        {
            // Items within a transaction.
            //var itemList = new ItemList()
            //{
            //    items = new List<Item>() 
            //        {
            //            new Item()
            //            {
            //                name = "Developers Plan",
            //                currency = "USD",
            //                price = "1",
            //                quantity = "1" 
            //            }
            //        },
            //    shipping_address = null
            //};
            //Amount amnt = new Amount();
            //amnt.currency = "USD";
            //amnt.total = "1";

            //Transaction tran = new Transaction();
            //tran.description = "Paypal Method developer plan";
            //tran.amount = amnt;
            //tran.item_list = itemList;


            var transaction = new Transaction()
            {
                amount = new Amount()
                {
                    currency = "USD",
                    total = "1",
                    details = new Details()
                    {
                        shipping = "0",
                        subtotal = "1",
                        tax = "0"
                    }
                },
                description = "This is the payment transaction description.",
                item_list = new ItemList()
                {
                    items = new List<Item>()
                    {
                        new Item()
                        {
                            name = "Item Name",
                            currency = "USD",
                            price = "1",
                            quantity = "5",
                            sku = "sku"
                        }
                    },
                    shipping_address = new ShippingAddress
                    {
                        city = "Johnstown",
                        country_code = "US",
                        line1 = "52 N Main ST",
                        postal_code = "43210",
                        state = "OH",
                        recipient_name = "Joe Buyer"
                    }
                },
                invoice_number = "Inoice+1" //Common.GetRandomInvoiceNumber()
            };
            return transaction;
            //return tran;
        }
        PaymentPlan ChoosePlan(int type)
        {
            PaymentPlan paymentPlan = new PaymentPlan();
            paymentPlan.Type = type;
            switch (type)
            {
                case 1:
                    paymentPlan.Amount = 1;
                    paymentPlan.PlanName = "Free";

                    break;

                case 2:
                    paymentPlan.Amount = 5;
                    paymentPlan.PlanName = "Developers";
                    break;

                case 3:
                    paymentPlan.Amount = 30;
                    paymentPlan.PlanName = "Sector Specific";
                    break;

                case 4:
                    paymentPlan.Amount = 90;
                    paymentPlan.PlanName = "Premium";
                    break;
                default:
                    paymentPlan.Amount = 1;
                    paymentPlan.PlanName = "Free";
                    break;
            }
            return paymentPlan;
        }



        public ActionResult GetHistory(){
            PaypalDataManger paypalDB = new PaypalDataManger();
            var list=paypalDB.GetHistory();
            return View(list);
        }


    }
}
