﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ZD_DAL_SQL.Models;

namespace ZDalyWeb.Controllers
{
    public class zd_User_RegistarationController : Controller
    {
        private ZDaly_Aug_16Entities db = new ZDaly_Aug_16Entities();

        // GET: zd_User_Registaration
        public async Task<ActionResult> SignUP()
        {
            return View();
        }

        // GET: zd_User_Registaration/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            zd_User_Registaration zd_User_Registaration = await db.zd_User_Registaration.FindAsync(id);
            if (zd_User_Registaration == null)
            {
                return HttpNotFound();
            }
            return View(zd_User_Registaration);
        }

        // GET: zd_User_Registaration/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: zd_User_Registaration/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddUser(zd_User_Registaration zd_User_Registaration)
        {
            if (ModelState.IsValid)
            {
               // zd_User_Registaration.Registration_ID_PK = 10003;
                zd_User_Registaration.Registration_Hash = "dasdfsdfsdafdaf";
                zd_User_Registaration.Registration_UserName = "dsads";
                zd_User_Registaration.Registration_Password = "dsads";
                zd_User_Registaration.Registration_Is_Trial = true;
                zd_User_Registaration.TrialSubscription_StartDate = DateTime.Now;

                zd_User_Registaration.IsDeleted = false;
                zd_User_Registaration.IsActive = true;
                zd_User_Registaration.CreatedBy = 123;
                zd_User_Registaration.CreatedOn = DateTime.Now;
                db.zd_User_Registaration.Add(zd_User_Registaration);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");

            
            }

            return View(zd_User_Registaration);
        }

        // GET: zd_User_Registaration/Edit/5
        public async Task<ActionResult> Edit()
        {
            // if (id == null)
            //  {
            //   return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            // }
            // zd_User_Registaration zd_User_Registaration = await db.zd_User_Registaration.FindAsync(id);
            //if (zd_User_Registaration == null)
            //{
            //   // return HttpNotFound();
            //}
            return View();
        }

        // POST: zd_User_Registaration/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(zd_User_Registaration zd_User_Registaration)
        {
            if (ModelState.IsValid)
            {
                //  db.Entry(zd_User_Registaration).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(zd_User_Registaration);
        }

        // GET: zd_User_Registaration/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            zd_User_Registaration zd_User_Registaration = await db.zd_User_Registaration.FindAsync(id);
            if (zd_User_Registaration == null)
            {
                return HttpNotFound();
            }
            return View(zd_User_Registaration);
        }

        // POST: zd_User_Registaration/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            zd_User_Registaration zd_User_Registaration = await db.zd_User_Registaration.FindAsync(id);
            db.zd_User_Registaration.Remove(zd_User_Registaration);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
