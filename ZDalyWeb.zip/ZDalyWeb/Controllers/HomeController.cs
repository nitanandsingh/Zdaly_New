﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using ZDalyBAL;
using ZDalyCommon.Partial;
using ZDalyModels;
using ZDalyWeb.PayPal.Model;

namespace ZDalyWeb.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult datatool()
        {
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
            return View();
        }

        public ActionResult analytics()
        {
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
            return View();
        }

        public ActionResult contactus()
        {

            return View();
        }

        public ActionResult help()
        {

            return View();
        }

        public ActionResult gopremium()
        {
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
            return View();
        }

        public ActionResult Notification(string NotificationId)
        {
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }  
            Account objaccount = new Account();
            string sendfromemail = ConfigurationManager.AppSettings["SendFromEmail"].ToString();
            string sendfromemailpassword = ConfigurationManager.AppSettings["SendFromEmailPassword"].ToString();
            string hostserver = ConfigurationManager.AppSettings["HostServer"].ToString();
            string Msg = "";

            var callbackUrl = Url.Action("DownloadFile", "API/Common",
                           new { NotificationId = NotificationId }, protocol: Request.Url.Scheme);
            StringBuilder emailmsg = new StringBuilder();
            emailmsg.Append("<p><b> Dear User </b></p> <p>Please use the download option to download the file.<a href=\"" + callbackUrl + "\">Download File</a></p>");
            string emailsubject = "Data Download";
            if (Email.SendEMail("Mayhzdaly@gmail.com", emailsubject, emailmsg.ToString(), "", sendfromemail, sendfromemailpassword, hostserver, ref Msg))
            {
                ModelState.Clear();
                return View();
            }
            else
            {
                return View();
            }
        }

        [System.Web.Http.HttpPost]
        public JsonResult PreviewData(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            List<usp_Report_Download_Data_Result> data = null;
            data = bl.GetPreviewData(_filter);
            int i = 0;
            var jsonData = new
            {
                total = 1,
                page = 1,
                records = data.Count,
                rows = (
                   from rec in data
                   select new
                   {
                       id = ++i,
                       cell = new string[] {
                      rec.SectorName, rec.SubsectorName,rec.Country, rec.State,rec.County,rec.LocationLevel,rec.Tier1_Commodity,rec.Tier2_Commodity,rec.Tier3_Commodity,
                        rec.Tier1_Attribute,  rec.Tier2_Attribute, rec.Tier3_Attribute,rec.Unit.ToString(),rec.Detail.ToString(),rec.Value.ToString(),rec.Date_Period.ToString()
                     }
                   }).ToArray()
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Payment(int type)
        {
            PaymentPlan paymentPlan = new PaymentPlan();
            paymentPlan.Type = type;
            switch (type)
            {
                case 1:
                    paymentPlan.Amount = 0;
                    paymentPlan.PlanName = "Free";
                    
                    break;

                case 2:
                    paymentPlan.Amount = 5;
                    paymentPlan.PlanName = "Developers";
                    break;

                case 3:
                    paymentPlan.Amount = 30;
                    paymentPlan.PlanName = "Sector Specific";
                    break;

                case 4:
                    paymentPlan.Amount = 90;
                    paymentPlan.PlanName = "Premium";
                    break;
                default:
                    paymentPlan.Amount = 0;
                    paymentPlan.PlanName = "Free";
                    break;
            }
            Session["PLAN"] = paymentPlan;
            return Redirect("/paypal/checkout");
        }
    }
}
