﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using ZDalyWeb.Filters;

using ZDalyModels;
using ZDalyBAL;

using System.Text;
using System.Configuration;
using ZDalyWeb.Models;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Threading.Tasks;
using System.Data;
using Dapper;
using Microsoft.AspNet.Identity.EntityFramework;
using ApiHelper.Client;
using Web.ApiInfrastructure.Client;
using ApiHelper;
using Web.ApiInfrastructure;


namespace ZDalyWeb.Controllers
{
    //[Authorize]
    [InitializeSimpleMembership]
    public class AccountController : Controller
    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
        SqlConnection cnn;
        SqlCommand cmd;
        string sql = null;

        private readonly ILoginClient loginClient;
        private readonly ITokenContainer tokenContainer;
        //Addtional changes to revert it back to Microsoft.Owin Authentication
        private ApplicationUserManager _userManager;
        private ApplicationSignInManager _signInManager;

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }

        public AccountController()
        {
            tokenContainer = new TokenContainer();
            var apiClient = new ApiClient(HttpClientInstance.Instance, tokenContainer);
            loginClient = new LoginClient(apiClient);
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
            tokenContainer = new TokenContainer();
            var apiClient = new ApiClient(HttpClientInstance.Instance, tokenContainer);
            loginClient = new LoginClient(apiClient);
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }


        //
        // GET: /Account/Login

        #region Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            if (Request.IsAuthenticated)
            {
                if (User.Identity.IsAuthenticated)
                {
                    return ManageRedirects(returnUrl);
                }
            }
            return View();
        }

        [HttpPost]
        [AllowAnonymous]

        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true

            var response = await loginClient.Login(model.Email, model.Password);            
            if (response.StatusIsSuccessful)
            {
                tokenContainer.ApiToken = response.Data;
                return RedirectToAction("Index", "New");
            }

            ModelState.Clear();
            ModelState.AddModelError("", "The username or password is incorrect");
            return View(model);


           //var user = UserManager.FindByEmail(model.Email);
           // if (user == null)
           // {
           //     ModelState.AddModelError("", "Invalid Login attempt");
           //     return View(model);
           // }
           // if (!user.IsApproved)
           // {
           //     ModelState.AddModelError("", "Your account is deactivated, Please Contact System Administrator");
           //     return View(model);
           // }
           // var result = SignInManager.PasswordSignIn(model.Email, model.Password, model.RememberMe, shouldLockout: false);
           // switch (result)
           // {
           //     case SignInStatus.Success:
           //         Session["UserName"] = user.FirstName;
           //         return RedirectToAction("Login");
           //     case SignInStatus.LockedOut:
           //         return View("Lockout");
           //     case SignInStatus.RequiresVerification:
           //         return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = model.RememberMe });
           //     case SignInStatus.Failure:
           //     default:
           //         ModelState.AddModelError("", "Invalid login attempt.");
           //         return View(model);
            //}

        }

        public ActionResult ManageRedirects(string returnUrl)
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "New");
            }
            else
            {
                return RedirectToAction("Index", "New");
            }
        }

        public ActionResult IsLockedAndAttempts(string email, string pwd, bool rem)
        {
            sql = "select * from users_reg_info where password='" + pwd.Trim() + "' and Email='" + email.Trim() + "'";
            cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
            cmd = new SqlCommand(sql, cnn);
            cnn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                if (rem)
                {


                    Response.Cookies["userid"].Value = email.Trim();
                    Response.Cookies["pwd"].Value = pwd.Trim();
                    Response.Cookies["userid"].Expires = DateTime.Now.AddDays(15);
                    Response.Cookies["pwd"].Expires = DateTime.Now.AddDays(15);

                }
                else
                {
                    Response.Cookies["EmailAddress"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);

                }

                sql = "select UserName from users_reg_info where UserId='" + reader["UserId"] + "'";
                cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                cmd = new SqlCommand(sql, cnn);
                cnn.Open();
                var firstColumn = cmd.ExecuteScalar();
                Session["UserID"] = reader["UserId"];
                Session["UserName"] = firstColumn;
                return RedirectToAction("Index", "New");
            }
            else
            {
                checkAttempts(email);
                return View("Login");
            }

        }

        public ActionResult checkAttempts(string email)
        {
            sql = "select * from users_reg_info where  Email='" + email.Trim() + "'";
            cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
            cmd = new SqlCommand(sql, cnn);
            cnn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                Int32 totalAttempts = Convert.ToInt32(reader["Attempts"]);
                if (totalAttempts >= 3)
                {
                    sql = "Update users_reg_info SET IsLocked='true'  where email='" + email.Trim() + "'";
                    cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                    cmd = new SqlCommand(sql, cnn);
                    cnn.Open();
                    cmd.ExecuteScalar();

                    MailMessage mailMsg = new MailMessage("zdalycorp@gmail.com", email.Trim());
                    mailMsg.Subject = "Unlock Your Account";
                    string body1 = "<img src=http://74.63.228.198:88/Images/ZdalyLogoFinal-03.png /><br/> Hi " + reader["UserName"].ToString() + ",<br/>" +
      "Please reset your password. <br/><br/> " +
                          "<a target='_blank' style='background-color: #10a9e5; border-radius: 3px;color: #fff;display: inline-block;  font-size: 16px; padding: 12px 20px; text-align: center;text-decoration: none;width: auto;font-weight:bold;' href=http://74.63.228.198:88/Account/ResetPassword/?key=" + reader["GUID"].ToString() + ">Reset Password</a></div> <br/>" +
       "<p>Regards</p><p>Zdaly Team</p>";



                    mailMsg.Body = body1;
                    mailMsg.IsBodyHtml = true;
                    SmtpClient smtpClient = new SmtpClient();
                    smtpClient.Host = "smtp.gmail.com";
                    smtpClient.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential();

                    NetworkCred.UserName = "zdalycorp@gmail.com";
                    NetworkCred.Password = "MaYHcorporation082015";
                    smtpClient.UseDefaultCredentials = true;
                    smtpClient.Credentials = NetworkCred;
                    smtpClient.Port = 587;
                    smtpClient.Send(mailMsg);
                    ModelState.Clear();
                    @ViewBag.Message = "You exceeded the maximum allowed number of login attempts.An email has been sent to your email addresss. Please reset your password.";
                    return View("Login");
                }
                else
                {
                    totalAttempts = totalAttempts + 1;
                    sql = "Update users_reg_info SET Attempts=" + totalAttempts + "where email='" + email.Trim() + "'";
                    cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                    cmd = new SqlCommand(sql, cnn);
                    cnn.Open();
                    cmd.ExecuteScalar();
                    ModelState.Clear();
                    @ViewBag.Message = "Your password was incorrect. Please try again.";
                    return View("Login");
                }
            }
            return View("Login");
        }

        #endregion


        public ActionResult SignUp()
        {

            return View();
        }



        //
        // POST: /Account/LogOff

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();

            return RedirectToAction("Index", "New");
        }

        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                     var apiModel = new RegisterViewModel
                    {
                        FirstName = model.FirstName,
                        Email = model.Email,
                        LastName = model.LastName,
                        IsApproved = true,
                        CompanyName = model.CompanyName,
                        PhoneNumber = model.PhoneNumber,
                        EmailConfirmed = false,
                        TwoFactorEnabled = false,
                        LockoutEnabled = false,
                        AccessFailedCount = 0,
                        PasswordHash = model.PasswordHash,
                        UserName = model.FirstName
                    };


                    var response = await loginClient.Register(model);               

                    if (response.StatusIsSuccessful)
                    {
                      //  await SignInManager.SignInAsync((, isPersistent: false, rememberBrowser: false);
                        //string a = 
                        //zd_UserSubscription objSubs = new zd_UserSubscription();
                        //objSubs.Auth_ID_FK = apiModel.Id;
                        //objSubs.UserSubscription_Start_Date = DateTime.Now;
                        //objSubs.SubscriptionType_ID_FK = 1000;
                        //objSubs.NoOfRecords_Downloaded = 100;
                        //objSubs.IsActive = true;
                        //objSubs.IsDeleted = false;
                        //objSubs.CreatedBy = 1;
                        //objSubs.CreatedOn = DateTime.Now;

                        //ZDalyDBEntities context = new ZDalyDBEntities();
                        //context.zd_UserSubscription.Add(objSubs);
                        //context.SaveChanges();
                        //Session["UserName"] = model.FirstName + " " + model.LastName;
                        return RedirectToAction("Index", "New");
                    }
                  //  AddErrors(result);
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }
        //
        // POST: /Account/Disassociate

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Disassociate(string provider, string providerUserId)
        {
            string ownerAccount = OAuthWebSecurity.GetUserName(provider, providerUserId);
            ManageMessageId? message = null;

            // Only disassociate the account if the currently logged in user is the owner
            if (ownerAccount == User.Identity.Name)
            {
                // Use a transaction to prevent the user from deleting their last login credential
                using (var scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = System.Transactions.IsolationLevel.Serializable }))
                {
                    bool hasLocalAccount = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
                    if (hasLocalAccount || OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name).Count > 1)
                    {
                        OAuthWebSecurity.DeleteAccount(provider, providerUserId);
                        scope.Complete();
                        message = ManageMessageId.RemoveLoginSuccess;
                    }
                }
            }

            return RedirectToAction("Manage", new { Message = message });
        }

        //
        // GET: /Account/Manage

        public ActionResult Manage(ManageMessageId? message)
        {
            ViewBag.StatusMessage =
                message == ManageMessageId.ChangePasswordSuccess ? "Your password has been changed."
                : message == ManageMessageId.SetPasswordSuccess ? "Your password has been set."
                : message == ManageMessageId.RemoveLoginSuccess ? "The external login was removed."
                : "";
            ViewBag.HasLocalPassword = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            ViewBag.ReturnUrl = Url.Action("Manage");
            return View();
        }





        //
        // POST: /Account/ExternalLogin

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            return new ChallengeResult(provider, Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/ExternalLoginCallback



        [AllowAnonymous]
        public async Task<ActionResult> ExternalLoginCallback(string returnUrl)
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync();
            if (loginInfo == null)
            {
                return RedirectToAction("Login");
            }

            // Sign in the user with this external login provider if the user already has a login
            var result = await SignInManager.ExternalSignInAsync(loginInfo, isPersistent: false);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = false });
                case SignInStatus.Failure:
                default:
                    // If the user does not have an account, then prompt the user to create an account
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email, ProviderName = loginInfo.Login.LoginProvider, UserName = loginInfo.ExternalIdentity.Name });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ExternalLoginConfirmation(ExternalLoginConfirmationViewModel model, string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Manage");
            }

            if (ModelState.IsValid)
            {
                // Get the information about the user from the external login provider
                var info = await AuthenticationManager.GetExternalLoginInfoAsync();
                if (info == null)
                {
                    return View("ExternalLoginFailure");
                }
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email, FirstName = model.UserName, IsApproved = true };
                var result = await UserManager.CreateAsync(user);
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, info.Login);
                    if (result.Succeeded)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                        return RedirectToLocal(returnUrl);
                    }
                }
                AddErrors(result);
            }

            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }

        //
        // GET: /Account/ExternalLoginFailure

        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_userManager != null)
                {
                    _userManager.Dispose();
                    _userManager = null;
                }

                if (_signInManager != null)
                {
                    _signInManager.Dispose();
                    _signInManager = null;
                }
            }

            base.Dispose(disposing);
        }

        [AllowAnonymous]
        [ChildActionOnly]
        public ActionResult ExternalLoginsList(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return PartialView("_ExternalLoginsListPartial", OAuthWebSecurity.RegisteredClientData);
        }

        [ChildActionOnly]
        public ActionResult RemoveExternalLogins()
        {
            ICollection<OAuthAccount> accounts = OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name);
            List<ExternalLogin> externalLogins = new List<ExternalLogin>();
            foreach (OAuthAccount account in accounts)
            {
                AuthenticationClientData clientData = OAuthWebSecurity.GetOAuthClientData(account.Provider);

                externalLogins.Add(new ExternalLogin
                {
                    Provider = account.Provider,
                    ProviderDisplayName = clientData.DisplayName,
                    ProviderUserId = account.ProviderUserId,
                });
            }

            ViewBag.ShowRemoveButton = externalLogins.Count > 1 || OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            return PartialView("_RemoveExternalLoginsPartial", externalLogins);
        }


        #region ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword(string returnUrl)
        {

            ViewBag.ReturnUrl = returnUrl;
            return View();
        }



        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByEmailAsync(model.Email);
                if (user == null)
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    return View("ForgotPasswordConfirmation");
                }

                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                // Send an email with this link
                string code = await UserManager.GeneratePasswordResetTokenAsync(user.Id);

                //Body 
                string imageUrl = Request.Url.AbsoluteUri + "/images/ZdalyLogo.png";

                if (Request.IsLocal)
                {
                    imageUrl = "http://74.63.228.198:88/images/ZdalyLogo.png";
                }

                var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);

                string body = "<img src=" + imageUrl + " /><br/> Hi " + user.FirstName + ",<br/>" +
                               "Please reset your password. <br/><br/> " +
                               "<a target='_blank' style='background-color: #10a9e5; border-radius: 3px;color: #fff;display: inline-block;  font-size: 16px; padding: 12px 20px; text-align: center;text-decoration: none;width: auto;font-weight:bold;' href=\"" + callbackUrl + "\" > Reset Password</a></div> <br/>" +
                               "<p>Regards</p><p>Zdaly Team</p>";


                await UserManager.SendEmailAsync(user.Id, "Reset Your Password", body);
                return RedirectToAction("ForgotPasswordConfirmation", "Account");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }


        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }
        //[HttpPost]
        //[AllowAnonymous]

        //public ActionResult ForgotPassword(ForgotPasswordModel objforgotpasswordmodel)
        //{

        //    sql = "select * from users_reg_info where email='" + objforgotpasswordmodel.EmailAddress.Trim() + "'";
        //    cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
        //    cmd = new SqlCommand(sql, cnn);
        //    cnn.Open();
        //    Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

        //    if (count > 0)
        //    {
        //        sql = "select * from users_reg_info where email='" + objforgotpasswordmodel.EmailAddress.Trim() + "'";
        //        cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
        //        cmd = new SqlCommand(sql, cnn);
        //        cnn.Open();
        //        SqlDataReader reader = cmd.ExecuteReader();
        //        MailMessage mailMsg = new MailMessage("zdalycorp@gmail.com", objforgotpasswordmodel.EmailAddress.Trim());
        //        mailMsg.Subject = "Password Recovery Link";
        //        while (reader.Read())
        //        {

        //            string body1 = "<img src=http://74.63.228.198:88/Images/ZdalyLogoFinal-03.png /><br/> Hi " + reader["UserName"].ToString() + ",<br/>" +
        //                "Please reset your password. <br/><br/> " +
        //                                    "<a target='_blank' style='background-color: #10a9e5; border-radius: 3px;color: #fff;display: inline-block;  font-size: 16px; padding: 12px 20px; text-align: center;text-decoration: none;width: auto;font-weight:bold;' href=http://74.63.228.198:88/Account/ResetPassword/?key=" + reader["GUID"].ToString() + ">Reset Password</a></div> <br/>" +
        //                 "<p>Regards</p><p>Zdaly Team</p>";



        //            mailMsg.Body = body1;
        //            mailMsg.IsBodyHtml = true;
        //            SmtpClient smtpClient = new SmtpClient();
        //            smtpClient.Host = "smtp.gmail.com";
        //            smtpClient.EnableSsl = true;
        //            NetworkCredential NetworkCred = new NetworkCredential();

        //            NetworkCred.UserName = "zdalycorp@gmail.com";
        //            NetworkCred.Password = "MaYHcorporation082015";
        //            smtpClient.UseDefaultCredentials = true;
        //            smtpClient.Credentials = NetworkCred;
        //            smtpClient.Port = 587;
        //            smtpClient.Send(mailMsg);
        //            ModelState.Clear();
        //            @ViewBag.MessageReset = "Reset Password link sent on your email address.";

        //        }
        //        return View("ForgotPassword");

        //    }
        //    else
        //    {
        //        ModelState.Clear();
        //        @ViewBag.Message = "Invalid email: Please check your email and try again.";
        //        return View("ForgotPassword");

        //    }

        //}

        #endregion


        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            return code == null ? View("Error") : View();
        }

        //[AllowAnonymous]
        //public ActionResult ResetPassword()
        //{
        //    return View();
        //}


        //[HttpPost]
        //[AllowAnonymous]
        //public ActionResult ResetPassword(ResetPasswordModel objreset)
        //{
        //    string link = Request["key"];

        //    if (link != null)
        //    {
        //        if (objreset.NewPassword == objreset.ConfirmPassword)
        //        {
        //            sql = "select * from users_reg_info where GUID='" + link.ToUpper() + "'";
        //            cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
        //            cmd = new SqlCommand(sql, cnn);
        //            cnn.Open();
        //            SqlDataReader reader = cmd.ExecuteReader();
        //            while (reader.Read())
        //            {

        //                sql = "Update users_reg_info SET Password=" + objreset.NewPassword + ", Attempts=" + "0" + ",IsLocked=" + "0" + " where UserId='" + reader["UserId"] + "'";

        //                cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
        //                cmd = new SqlCommand(sql, cnn);
        //                cnn.Open();
        //                cmd.ExecuteScalar();
        //                Session["UserID"] = reader["UserId"];
        //                Session["UserName"] = reader["UserName"];
        //            }

        //            cmd.ExecuteNonQuery();
        //            cmd.Dispose();
        //            cnn.Close();
        //            return RedirectToAction("Index", "New");
        //        }
        //        else {
        //            TempData["Message"] = "New password do not match with confirm password.";

        //            return RedirectToAction("ResetPassword", "Account", new { key = link.ToUpper() });
        //        }
        //    }
        //    else
        //    {
        //        return RedirectToAction("Error", "Shared");
        //    }

        //}

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await UserManager.FindByNameAsync(model.Email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("Login", "Account");
            }
            var result = await UserManager.ResetPasswordAsync(user.Id, model.Code, model.Password);
            if (result.Succeeded)
            {
                return RedirectToAction("Login", "Account");
            }
            AddErrors(result);
            return View();
        }

        #region Helpers

        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "New");
            }
        }

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
        }

        //internal class ExternalLoginResult : ActionResult
        //{
        //    public ExternalLoginResult(string provider, string returnUrl)
        //    {
        //        Provider = provider;
        //        ReturnUrl = returnUrl;
        //    }

        //    public string Provider { get; private set; }
        //    public string ReturnUrl { get; private set; }

        //    public override void ExecuteResult(ControllerContext context)
        //    {

        //        OAuthWebSecurity.RequestAuthentication(Provider, ReturnUrl);

        //    }
        //}

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }

        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // See http://go.microsoft.com/fwlink/?LinkID=177550 for
            // a full list of status codes.
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "User name already exists. Please enter a different user name.";

                case MembershipCreateStatus.DuplicateEmail:
                    return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

                case MembershipCreateStatus.InvalidPassword:
                    return "The password provided is invalid. Please enter a valid password value.";

                case MembershipCreateStatus.InvalidEmail:
                    return "The e-mail address provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidAnswer:
                    return "The password retrieval answer provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidQuestion:
                    return "The password retrieval question provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidUserName:
                    return "The user name provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.ProviderError:
                    return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                case MembershipCreateStatus.UserRejected:
                    return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                default:
                    return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
            }
        }
        #endregion


        [AllowAnonymous]
        public ActionResult Signout()
        {
            Response.AddHeader("Cache-Control", "no-cache, no-store,must-revalidate");
            Response.AddHeader("Pragma", "no-cache");
            Response.AddHeader("Expires", "0");
            Session.Abandon();

            Session.Clear();
            Response.Cookies.Clear();
            Session.RemoveAll();
            return RedirectToAction("Index", "New");
        }


        //Manage All Users
        [Authorize(Roles = "Admin")]
        public ActionResult ManageAllUsers()
        {
            UserWarehouseViewModel objVM = new UserWarehouseViewModel();
            using (IDbConnection con = connection)
            {
                con.Open();
                objVM.List = con.Query<UserWarehouseDisplayRow>("Select Id AS UserID,FullName as UserName,Email,IsApproved,CompanyUniversity AS Company from aspnetusers").ToList();

                foreach (var item in objVM.List)
                {
                    var roles = con.Query<string>("select  AspNetRoles.Name from AspNetUserRoles INNER JOIN AspNetRoles on AspNetUserRoles.RoleId = AspNetRoles.Id where AspNetUserRoles.UserId = @userid", new { userid = item.UserID }).ToList();
                    item.Role = string.Join(", ", roles);
                }
            }

            return View(objVM);
        }

        public string UpdateNameForAnyUser(string name, string userId)
        {
            try
            {
                using (IDbConnection con = connection)
                {
                    con.Open();
                    con.Execute("Update AspNetUsers set FullName = @name where Id = @id", new { id = userId, name = name });
                }
                return "Success";
            }
            catch (Exception)
            {
                return "Fail";
            }
        }

        public string UpdateCompanyForAnyUser(string name, string userId)
        {
            try
            {
                using (IDbConnection con = connection)
                {
                    con.Open();
                    con.Execute("Update AspNetUsers set CompanyUniversity = @name  where Id = @id", new { id = userId, name = name });
                }
                return "Success";
            }
            catch (Exception)
            {
                return "Fail";
            }
        }

        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> EditUser(string id)
        {
            //var user = await UserManager.FindByIdAsync(id);
            object objVM = new object();

            //objVM.FullName = user.FirstName;
            //objVM.Email = user.Email;
            //objVM.UserID = id;
            //objVM.IsActive = user.IsApproved;
            //objVM.CompanyUniversity = user.CompanyName;
            //using (IDbConnection con = connection)
            //{
            //    con.Open();
            //    objVM.Roles = con.Query<AspNetRolesVM>("select * From AspNetRoles order by Name").ToList();
            //    objVM.UserRoles = con.Query<string>("select  AspNetRoles.Name from AspNetUserRoles INNER JOIN AspNetRoles on AspNetUserRoles.RoleId = AspNetRoles.Id where AspNetUserRoles.UserId = @userid", new { userid = id }).ToList();
            //}

            return View(objVM);
        }

        public string UpdateStatus(string userName, string type)
        {
            try
            {
                var user = UserManager.FindByEmail(userName);

                if (user != null)
                {
                    if (type == "DE")
                    {
                        user.IsApproved = false;
                    }
                    else if (type == "AC")
                    {
                        user.IsApproved = true;
                    }
                    UserManager.Update(user);
                }

                return "Success";
            }
            catch (Exception)
            {
                return "Fail";
            }
        }

        public string AssignRoles(string roles, string userId)
        {
            List<int> rolesList = new List<int>();

            if (!string.IsNullOrEmpty(roles))
            {
                rolesList = roles.Split(',').Select(x => Int32.Parse(x)).ToList();
            }

            using (IDbConnection con = connection)
            {
                con.Open();

                con.Execute("Delete from AspNetUserRoles where UserId = @user", new { user = userId });

                foreach (var item in rolesList)
                {
                    con.Execute("insert into AspNetUserRoles values (@user,@role)", new { user = userId, role = item });
                }
            }

            return "Success";
        }

        public string ResetUserPassword(string userId, string password = "123123")
        {
            //UserManager<IdentityUser> userManager = new UserManager<IdentityUser>(new UserStore<IdentityUser>());

            UserManager.RemovePassword(userId);

            UserManager.AddPassword(userId, password);

            return "Success";
        }

        public ActionResult UnAuthorized()
        {
            return View();
        }
    }
}
