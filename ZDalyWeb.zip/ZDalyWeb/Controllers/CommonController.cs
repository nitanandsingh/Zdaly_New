﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Web.Mvc;
using ZDalyBAL;
using ZDalyCommon.Partial;
using ZDalyModels;

namespace ZDalyWeb.Controllers
{
    public class CommonController : ApiController
    {

        #region GetSectors
        /// <summary>
        /// function used to get sectors
        /// </summary>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSectors")]
        public List<usp_select_Sector_Result> GetSectors()
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSectors();
        }
        #endregion

        #region GetDataBasedonSectorAndSuperRegion
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetDataBasedonSectorAndSuperRegion")]
        public DatabaseBasedOnSectorAndSuperRegion GetDataBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetDataBasedonSectorAndSuperRegion(_filter);
        }
        #endregion

        #region GetDataBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSubSectorBasedonSectorAndSuperRegion")]
        public List<usp_Select_Subsector_Result> GetSubSectorBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSubSectorBasedonSectorAndSuperRegion(_filter);
        }
        #endregion

        #region GetDataBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSubSectorBasedonSectorAndSuperRegion_V1")]
        public List<usp_Select_Subsector_Result> GetSubSectorBasedonSectorAndSuperRegion_V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSubSectorBasedonSectorAndSuperRegion_V1(_filter);
        }
        #endregion

        #region GetCommodityBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCommodityBasedonSectorAndSuperRegion")]
        public List<usp_Report_Commodity1_Result> GetCommodityBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommodityBasedonSectorAndSuperRegion(_filter);
        }
        #endregion

        #region GetGeographicalDataBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetGeographicalDataBasedonSectorAndSuperRegion")]
        public List<usp_Report_Select_GeoGraphic_Level_V1_Result> GetGeographicalDataBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetGeographicalDataBasedonSectorAndSuperRegion(_filter);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetGeographicalDataV1")]
        public List<usp_Report_Select_GeoGraphic_Level_V1_Result> GetGeographicalDataV1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetGeographicalDataV1(_filter);
        }
        #endregion

        #region GetSourceDataBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSourceDataBasedonSectorAndSuperRegion")]
        public List<usp_Report_Select_Source_Result> GetSourceDataBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSourceDataBasedonSectorAndSuperRegion(_filter);
        }
        #endregion

        #region GetTimeLevelBasedonSectorAndSuperRegion
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetTimeLevelBasedonSectorAndSuperRegion")]
        public List<usp_Report_Select_Time_Level_Result> GetTimeLevelBasedonSectorAndSuperRegion(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetTimeLevel(_filter);
        }
        #endregion

        //#region GetDataBasedonSectorAndSuperRegion
        //[System.Web.Http.HttpPost]
        //public GetCommodityBasedonSectorAndSuperRegion(DataCostFilters _filter)
        //{
        //    DataCostBl bl = new DataCostBl();
        //    return bl.GetDataBasedonSectorAndSuperRegion(_filter);
        //}
        //#endregion

        //#region GetDataBasedonSectorAndSuperRegion
        //[System.Web.Http.HttpPost]
        //public GetGeographicalDataBasedonSectorAndSuperRegion(DataCostFilters _filter)
        //{
        //    DataCostBl bl = new DataCostBl();
        //    return bl.GetDataBasedonSectorAndSuperRegion(_filter);
        //}
        //#endregion

        //#region GetDataBasedonSectorAndSuperRegion
        //[System.Web.Http.HttpPost]
        //public GetSourceDataBasedonSectorAndSuperRegion(DataCostFilters _filter)
        //{
        //    DataCostBl bl = new DataCostBl();
        //    return bl.GetDataBasedonSectorAndSuperRegion(_filter);
        //}
        //#endregion

        #region GetDataBasedonSectorAndSuperRegion
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetDataForVersion1Selection")]
        public DatabaseBasedOnSectorAndSuperRegion GetDataForVersion1Selection(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetDataBasedonSectorAndSuperRegion_V1(_filter);
        }
        #endregion

        //#region GetIndustries
        ///// <summary>
        ///// function used to get counties as per the country id
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //[System.Web.Http.HttpGet]
        //[System.Web.Http.ActionName("GetThemesBySectorID")]
        //public List<SubSectorList> GetThemesBySectorID(int id)
        //{
        //    return SharedTableBl.ApplicationSharedTables.SubSectorList.Where(c => c.Sector_Id == id).ToList();
        //}
        //#endregion

        #region GetCommoditiesBySubSectorID
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetCommoditiesBySubSectorID")]
        public List<usp_Select_Commodity_1_Result> GetCommoditiesBySubSectorID(int id)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommodities(id);
        }
        #endregion

        #region GetSubCommoditiesBySubSectorID
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSubCommoditiesBySubSectorID")]
        public List<usp_Select_Commodity_2_Result> GetSubCommoditiesBySubSectorID(int? SubSectorID, int? Tier1_ID)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSubCommodities(SubSectorID, Tier1_ID);
        }
        #endregion

        #region GetSuperRegion
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SubSectorID"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSuperRegion")]
        public List<usp_select_Super_Region_Result> GetSuperRegion(string sectorName = null)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSuperRegion(sectorName);
        }
        #endregion

        #region GetSubSectors
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SectorName"></param>
        /// <param name="RegionName"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSubSectors")]
        public List<usp_Select_Subsector_Result> GetSubSectors(string SectorName, string RegionName)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSubSectors(SectorName, RegionName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SectorName"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSectorDetails")]
        public List<usp_select_SectorDetails_Result> GetSectorDetails(string SectorName)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSectorDetails(SectorName);
        }
        #endregion

        #region GetCountries
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SubSectorID"></param>
        /// <param name="Tier1_ID"></param>
        /// <param name="Tier2_ID"></param>
        /// <param name="Tier3_ID"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetCountries")]
        public List<usp_Select_Countries_Result> GetCountries(int? subSectorID, int? tier1_ID, int? tier2_ID, int? tier3_ID)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCountries(subSectorID, tier1_ID, tier2_ID, tier3_ID);
        }

       
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SubSectorID"></param>
        /// <param name="Tier1_ID"></param>
        /// <param name="Tier2_ID"></param>
        /// <param name="Tier3_ID"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCountries_v1")]
        public List<usp_Select_Countries_V1_Result> GetCountries_v1(int? subSectorID, int? tier1_ID, int? tier2_ID, int? tier3_ID, string locationLevel)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCountries_v1(subSectorID, tier1_ID, tier2_ID, tier3_ID, locationLevel).ToList();
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCountriesListv1")]
        public List<usp_Select_Countries_V1_Result> GetCountriesListv1(DataCostFilters _dataCostFilter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCountriesListv1(_dataCostFilter);
        }

        #endregion

        #region GetStates
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetStates")]
        public List<usp_Select_States_Result> GetStates(int? CountryID, int? SubSectorID, int? Tier1_ID, int? Tier2_ID, int? Tier3_ID)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetStates(CountryID, SubSectorID, Tier1_ID, Tier2_ID, Tier3_ID);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetStateListv1")]
        public List<usp_Select_States_Result> GetStateListv1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetStateListv1(_filter);
        }
        #endregion

        #region GetCounties
        /// <summary>
        /// function used to get counties as per the country id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetCounties")]
        public List<usp_Select_County_Result> GetCounties(int? CountryID, int? StateID, int? SubSectorID, int? Tier1_ID, int? Tier2_ID, int? Tier3_ID)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCounties(CountryID, StateID, SubSectorID, Tier1_ID, Tier2_ID, Tier3_ID);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCountiesListV1")]
        public List<usp_Select_County_Result> GetCountiesListV1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCountiesListV1(_filter);
        }

        #endregion

        #region Search Commodities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serachTerm"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetCommoditiesForSearch")]
        public List<usp_Select_Commodity_Result> GetCommoditiesForSearch(string searchTerm, string sectorName = "", string superRegion = "")
        {
            DataCostBl bl = new DataCostBl();

            //checking data is in cached or not
            List<usp_Select_Commodity_Result> search = Utilities.CacheHelper.Get<List<usp_Select_Commodity_Result>>("GetCommoditiesForSearch");
            if (search == null)
            {
                //fetching data
                search = bl.GetCommoditiesForSearch(string.Empty);
                //add data to cache for future use
                Utilities.CacheHelper.Add<List<usp_Select_Commodity_Result>>(search, "GetCommoditiesForSearch");
            }

            //linq query on menu object with search term
            search = search.Where(x => x.Commodity.ToLower().Contains(searchTerm.ToLower())).ToList();
            if (!string.IsNullOrEmpty(sectorName) && !string.IsNullOrEmpty(superRegion))
            {
                search = search.Where(x => x.SectorName.Trim() == sectorName && x.SuperRegion.Trim() == superRegion).ToList();
            }

            return search;

            //var obj = bl.GetCommoditiesForSearch(serachTerm).Select(x => new { value = x.Commodity, label = x.Commodity + "@#$" + x.SubsectorName + "@#%" + x.SuperRegion }).ToList().AsEnumerable();
            //return new JsonResult { Data = obj, MaxJsonLength = 86753090, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tier"></param>
        /// <param name="commodity"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetCommoditiesByTier")]
        public List<usp_Select_SearchCommodityByTier_Result> GetCommoditiesByTier(int? tier, string commodity)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommoditiesByTier(tier, commodity);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCommodity1V1")]
        public List<usp_Report_Commodity1_Result> GetCommodity1V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommodity1V1(_filter);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCommodity2V1")]
        public List<usp_Report_Commodity2_Result> GetCommodity2V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommodity2V1(_filter);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCommodity3V1")]
        public List<usp_Report_Commodity3_Result> GetCommodity3V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetCommodity3V1(_filter);
        }


        #endregion

        #region GetAttributes

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAttributes1")]
        public List<usp_Report_Select_Attr1_V1_Result> GetAttributes1(ZData data)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetAttributes1(data).ToList();
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAttributes1V1")]
        public List<usp_Report_Select_Attr1_V1_Result> GetAttributes1V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetAttributes1V1(_filter);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAttributes2V1")]
        public List<usp_Report_Select_Attr2_V1_Result> GetAttributes2V1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetAttributes2V1(_filter);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSourceV1")]
        public List<usp_Report_Select_Source_Result> GetSourceV1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetSourceV1(_filter);
        }
        #endregion

        #region GetLocation

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <param name="sectorName"></param>
        /// <param name="superRegion"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetLocation")]
        public List<usp_Select_Location_Result> GetLocation(string searchTerm, string sectorName, string superRegion)
        {
            DataCostBl bl = new DataCostBl();

            //checking data is in cached or not
            List<usp_Select_Location_Result> search = Utilities.CacheHelper.Get<List<usp_Select_Location_Result>>("GetLocation");
            if (search == null)
            {
                //fetching data
                search = bl.GetLocation(string.Empty);
                //add data to cache for future use
                Utilities.CacheHelper.Add<List<usp_Select_Location_Result>>(search, "GetLocation");
            }

            //linq query on menu object with search term
            search = search.Where(x => x.LocationName.ToLower().Contains(searchTerm.ToLower())).ToList();
            if (!string.IsNullOrEmpty(sectorName) && !string.IsNullOrEmpty(superRegion))
            {
                search = search.Where(x => x.SectorName.Trim() == sectorName && x.SuperRegion.Trim() == superRegion).ToList();
            }

            return search;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <param name="sectorName"></param>
        /// <param name="superRegion"></param>
        /// <param name="subsector_id"></param>
        /// <param name="tier1_id"></param>
        /// <param name="tier2_id"></param>
        /// <param name="tier3_id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetLocation_v1")]
        public List<usp_Select_Location_V1_Result> GetLocation_v1(string searchTerm, string sectorName = "", string superRegion = "", int? subsector_id = null, int? tier1_id = null, int? tier2_id = null, int? tier3_id = null)
        {
            DataCostBl bl = new DataCostBl();
            var newList = bl.GetLocation_v1(searchTerm, sectorName, superRegion, subsector_id, tier1_id, tier2_id, tier3_id).ToList();
            if (newList.Any(x => x.Tier == "1"))
            {
                newList.Where(x => x.Tier == "1").ToList().ForEach(x => { x.County = ""; x.State = ""; });
                newList = newList.GroupBy(x => x.Country).Select(x => x.FirstOrDefault()).ToList();
            }
            else if (newList.Any(x => x.Tier == "2"))
            {
                newList.Where(x => x.Tier == "2").ToList().ForEach(x => { x.County = ""; });
                newList = newList.GroupBy(x => new { x.Country, x.State }).Select(x => x.FirstOrDefault()).ToList();
            }

            newList = newList.Distinct().ToList();
            return newList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetLocationLevel")]
        public List<usp_Select_Location_Level_Result> GetLocationLevel()
        {
            DataCostBl bl = new DataCostBl();
            //checking data is in cached or not
            List<usp_Select_Location_Level_Result> data = Utilities.CacheHelper.Get<List<usp_Select_Location_Level_Result>>("GetLocationLevel");
            if (data == null)
            {
                //fetching data
                data = bl.GetLocationLevel();
                //add data to cache for future use
                Utilities.CacheHelper.Add<List<usp_Select_Location_Level_Result>>(data, "GetLocationLevel");
            }
            return data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sectorName"></param>
        /// <param name="superRegion"></param>
        /// <param name="subsector_id"></param>
        /// <param name="tier1_id"></param>
        /// <param name="tier2_id"></param>
        /// <param name="tier3_id"></param>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetLocationLevel_v1")]
        public List<usp_Report_Select_GeoGraphic_Level_V2_Result> GetLocationLevel_v1(string sectorName = "", string superRegion = "", int? subsector_id = null, int? tier1_id = null, int? tier2_id = null, int? tier3_id = null)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetLocationLevel_v1(sectorName, superRegion, subsector_id, tier1_id, tier2_id, tier3_id).ToList();
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetLocationV1")]
        public List<usp_Report_Select_GeoGraphic_Level_V1_Result> GetLocationV1(DataCostFilters _filter)
        {
            DataCostBl bl = new DataCostBl();
            //checking data is in cached or not
            List<usp_Report_Select_GeoGraphic_Level_V1_Result> data = new List<usp_Report_Select_GeoGraphic_Level_V1_Result>();
            data = bl.GetLocationLevelV1(_filter);          
            return data;
        }


        #endregion

        #region Get Data

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>

        #region GetDashBoardCharts

        /// <summary>
        /// Method to fetch chart data by chart ID and year range.
        /// </summary>
        /// <param name="chartID"></param>
        /// <param name="startYear"></param>
        /// <param name="endYear"></param>
        /// <returns>Json Object containing CHart header information and Chart data for a definate range.</returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetChartByChartID")]
        public List<ChartDataModel> GetChartByChartID(int chartID, int startYear, int endYear)
        {
            List<ChartDataModel> objJSON = new List<ChartDataModel>();
            ChartDataModel objTemp = new ChartDataModel();
            DataCostBl bl = new DataCostBl();

            List<usp_Select_Top_Charts_Result> objDBData = bl.GetChartByChartID(chartID, startYear, endYear);
            List<int> distinctCharts = objDBData.Select(x => x.ChartID).Distinct().ToList();
            foreach (var chart_id in distinctCharts)
            {
                objTemp = new ChartDataModel();
                objTemp.ChartID = chart_id;
                objTemp.ChartName = objDBData.Where(x => x.ChartID == chart_id).Select(x => x.Tier1_Attribute).FirstOrDefault();
                objTemp.Attribute_ID = objDBData.Where(x => x.ChartID == chart_id).Select(x => x.Tier1_Attr_Id).FirstOrDefault();
                objTemp.Unit = objDBData.Where(x => x.ChartID == chart_id).Select(x => x.Unit).FirstOrDefault();
                objTemp.SingleChartData = objDBData.Where(x => x.ChartID == chart_id).ToList();
                objJSON.Add(objTemp);
            }

            return objJSON;

        }

        /// <summary>
        /// Method to fetch chart data by offset and page size for a particular Commodity ID and Location ID
        /// </summary>
        /// <param name="commodityId"></param>
        /// <param name="locationId"></param>
        /// <param name="offSet"></param>
        /// <param name="size"></param>
        /// <returns>Json Object containing CHart header information and Chart data.</returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetTopChartsForDashboard")]
        public List<ChartDataModel> GetTopChartsForDashboard(int commodityId, int locationId, int offSet, int size)
        {
            List<ChartDataModel> objJSON = new List<ChartDataModel>();
            ChartDataModel objTemp = new ChartDataModel();
            DataCostBl bl = new DataCostBl();

            //List<usp_Select_Charts_By_Paging_Result> objDBData = bl.GetTopChartsForDashboard(commodityId, locationId, offSet, size);
            List<usp_Select_Charts_By_Paging_Result> objDBData = ZDalyWeb.Helpers.ElmahDbHelper.GetTopChartsForDashboard(commodityId, locationId, offSet, size);
            //List<int> distinctCharts = objDBData.Select(x => x.ChartID).Distinct().ToList();

            foreach (var chart in objDBData)
            {
                objTemp = new ChartDataModel();
                // objTemp.ChartID = chart.ChartID;
                objTemp.Attribute_ID = chart.Attribute_ID;
                objTemp.ChartData = GetChartDataListWithDetailsPaging(chart.ChartData);
                objTemp.MaxYear = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Max(x => Convert.ToDateTime(x.Date)).Year : 2008;
                objTemp.MinYear = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Min(x => Convert.ToDateTime(x.Date)).Year : 2007;
                objTemp.EndDate = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Max(x => Convert.ToDateTime(x.Date)).ToShortDateString() : "1/1/2015";
                objTemp.StartDate = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Min(x => Convert.ToDateTime(x.Date)).ToShortDateString() : "12/1/2015";
                objTemp.State = chart.State;
                objTemp.Unit = chart.Unit;
                objTemp.ChartName = chart.Tier1_Attribute;
                objTemp.Attribute1_ID = Convert.ToInt64(chart.Tier1_Attr_Id);
                objTemp.Attribute2_ID = Convert.ToInt64(chart.Tier2_Attr_Id);
                objTemp.Attribute3_ID = Convert.ToInt64(chart.Tier3_Attr_Id);
                objTemp.Attribute2 = chart.Tier2_Attribute;
                objTemp.Attribute3 = chart.Tier3_Attribute;
                objTemp.ChartTypeID = chart.chart_Type_Id;
                objTemp.UnitID = Convert.ToInt32(chart.Unit_id);
                objTemp.TimeLevelID = Convert.ToInt32(chart.TimeLevelID);
                objTemp.SourceID = Convert.ToInt32(chart.Source_id);
                objTemp.TimeLevelFrequency = GetTimeLevelFrequency(chart.TimeLevel);
                objTemp.LocationLevel = GetLocationLevel(chart.LocationLevel);
                objTemp.DefaultLocation = chart.DefaultLocation;
                objTemp.Units = GetUnits(chart.Units);
                objTemp.Sources = GetSources(chart.Sources);
                objTemp.UnitID = Convert.ToInt32(chart.Unit_id);
                objTemp.DetailIDList = objTemp.ChartData.Select(x => x.Detail).Distinct().ToList();
                //objTemp.DetailIDList = objDBData.Where(x => x.ChartID == chart.ChartID).Select(x => x.detail).Distinct().ToList();
                objTemp.MinMaxYear = objDBData.FirstOrDefault().MinMaxYear;
                objJSON.Add(objTemp);
            }

            return objJSON;
        }

        /// <summary>
        /// Method to fetch the attributes by Commodity ID and Location ID
        /// </summary>
        /// <param name="commodityId"></param>
        /// <param name="locationId"></param>
        /// <returns>Json object containing the different list of attributes.</returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetAttributesByLocation")]
        public ChartAttributes GetAttributesByLocation(int commodityId, int locationId)
        {
            DataCostBl bl = new DataCostBl();
            ChartAttributes objJson = new ChartAttributes();
            List<usp_Get_Attributes_Result> objDBData = bl.GetAttributesByLocation(commodityId, locationId);

            objJson.Attribute1 = objDBData.GroupBy(x => new { x.Tier1_Attr_Id, x.Tier1_Attribute }).Select(g => new SubAttributeModel { ID = g.Key.Tier1_Attr_Id, Value = g.Key.Tier1_Attribute }).ToList();
            objJson.Attribute2 = objDBData.GroupBy(x => new { x.Tier2_Attr_Id, x.Tier2_Attribute, x.Tier1_Attr_Id }).Select(g => new SubAttributeModel { ID = g.Key.Tier2_Attr_Id, Value = g.Key.Tier2_Attribute, ParentID = g.Key.Tier1_Attr_Id }).ToList();
            objJson.Attribute3 = objDBData.Select(x => new SubAttributeModel { ID = x.Tier3_Attr_Id, Value = x.Tier3_Attribute, ParentID = x.Tier2_Attr_Id, AttributeID = x.Attribute_Id }).Distinct().ToList();

            return objJson;
        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetLocationAndCommodityID")]
        public TempLocationCommodityClass GetLocationAndCommodityID(string commodity)
        {
            DataCostBl bl = new DataCostBl();
            return Helpers.ElmahDbHelper.GetLocationAndCommodityID(commodity);
        }
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetChartBySelection")]
        public List<ChartDataModel> GetChartBySelection(int commodityId = 0, int locationId = 0, int attributeId = 0, int timelevelId = 0, int sourceId = 0, int unitId = 0, int startYear = 0, int endYear = 0, string startDate = null, string endDate = null)
        {
            List<ChartDataModel> objJSON = new List<ChartDataModel>();
            ChartDataModel objTemp = new ChartDataModel();
            DataCostBl bl = new DataCostBl();

            int chartTypeId = 2;
            List<usp_Select_Chart_By_Options_Result> objDBData = bl.GetSingleChartBySelection(commodityId, locationId, attributeId, timelevelId, unitId, sourceId, startYear, endYear, Convert.ToDateTime(startDate), Convert.ToDateTime(endDate));
            foreach (var chart in objDBData)
            {
                objTemp = new ChartDataModel();
                objTemp.ChartID = chart.ChartID;
                objTemp.Attribute_ID = chart.Attribute_ID;
                objTemp.ChartData = GetChartDataList(chart.ChartData, chart.detail, Convert.ToInt32(chart.detail_id));
                objTemp.Unit = chart.Unit;
                objTemp.ChartName = chart.Tier1_Attribute;
                objTemp.Attribute2 = chart.Tier2_Attribute;
                objTemp.Attribute3 = chart.Tier3_Attribute;
                objTemp.ChartTypeID = chart.chart_Type_Id;
                //objTemp.UnitID = Convert.ToInt32(chart.Unit_id);
                objTemp.TimeLevelID = Convert.ToInt32(chart.TimeLevelID);
                // objTemp.SourceID = Convert.ToInt32(chart.Source_id);
                objTemp.DetailIDList = objDBData.Where(x => x.ChartID == chart.ChartID).Select(x => x.detail).Distinct().ToList();
                // objTemp.Units = objDBData.Where(x => x.ChartID == chart_id).Select(x => x.Unit).Distinct().ToList();
                if (objTemp.ChartData.Count > 0)
                {
                    objJSON.Add(objTemp);
                }

                //objTemp.DetailIDList = objDBData.Select(x => x.detail).FirstOrDefault().ToList();
            }
            if (objJSON.Count > 0)
            {
                List<ChartData> ChartDataBulk = new List<ChartData>();
                List<string> DetailIDListBulk = new List<string>();
                List<ChartDataModel> objJSON2 = new List<ChartDataModel>();
                foreach (var chart in objJSON)
                {
                    ChartDataBulk.AddRange(chart.ChartData);
                    DetailIDListBulk.AddRange(chart.DetailIDList);
                }
                ChartDataModel objChartDataModel = new ChartDataModel();
                objChartDataModel.ChartID = objJSON.FirstOrDefault().ChartID; objChartDataModel.Attribute_ID = objJSON.FirstOrDefault().Attribute_ID;
                objChartDataModel.ChartName = objJSON.FirstOrDefault().ChartName; objChartDataModel.Attribute2 = objJSON.FirstOrDefault().Attribute2;
                objChartDataModel.Attribute3 = objJSON.FirstOrDefault().Attribute3; objChartDataModel.TimeLevelID = objJSON.FirstOrDefault().TimeLevelID;
                objChartDataModel.Unit = objJSON.FirstOrDefault().Unit; objChartDataModel.ChartTypeID = objJSON.FirstOrDefault().ChartTypeID;
                objChartDataModel.ChartData = ChartDataBulk;
                objChartDataModel.DetailIDList = DetailIDListBulk.Distinct().ToList();
                objJSON2.Add(objChartDataModel);
                return objJSON2;
            }
            return objJSON;
        }
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetChartByLocationLevel")]
        public List<ChartDataModel> GetChartByLocationLevel(int commodityId, int attributeId, int year, string locationLevel, int unitId, int timelevelId, int endYear, int sourceId, int locationId = 0)
        {
            List<ChartDataModel> objJSON = new List<ChartDataModel>();
            ChartDataModel objTemp = new ChartDataModel();
            DataCostBl bl = new DataCostBl();

            List<usp_Select_SingleChart_By_LocationLevel_Result> objDBData = bl.GetChartByLocationLevel(commodityId, locationId, attributeId, year, locationLevel, unitId, timelevelId, endYear, sourceId);
            objTemp = new ChartDataModel();
            if (objDBData.Count > 0)
            {
                objTemp.ChartID = objDBData[0].chartlist_id;
                objTemp.Attribute_ID = attributeId;
                objTemp.DefaultLocation = Convert.ToString(objDBData[0].location_Id);
                objTemp.ChartData = new List<ChartData>();

                foreach (var chart in objDBData)
                {
                    objTemp.ChartData.Add(new ChartData { Date = chart.State, Value = Convert.ToDecimal(chart.Value), DetailId = Convert.ToInt32(chart.detail_id), Detail = chart.detail });
                }
                objTemp.DetailIDList = objTemp.ChartData.Select(x => x.Detail).Distinct().ToList();
                objTemp.MinMaxYear = objDBData.FirstOrDefault().MinMaxYear;
                objJSON.Add(objTemp);
            }


            return objJSON;
        }
        //GetChartDataOnFocus
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetChartDataOnFocus")]
        public List<ChartDataModel> GetChartDataOnFocus(int commodityId, int locationId, int attributeId)
        {
            List<ChartDataModel> objJSON = new List<ChartDataModel>();
            try
            {

                ChartDataModel objTemp = new ChartDataModel();
                DataCostBl bl = new DataCostBl();

                //List<usp_Select_Charts_By_Paging_Result> objDBData = bl.GetTopChartsForDashboard(commodityId, locationId, offSet, size);
                usp_Select_SingleCharts_By_CLA_Result chart = ZDalyWeb.Helpers.ElmahDbHelper.GetChartDataOnFocus(commodityId, locationId, attributeId);
                //List<int> distinctCharts = objDBData.Select(x => x.ChartID).Distinct().ToList();

                //foreach (var chart in objDBData)
                {
                    objTemp = new ChartDataModel();
                    // objTemp.ChartID = chart.ChartID;
                    objTemp.Attribute_ID = chart.Attribute_ID;
                    objTemp.ChartData = GetChartDataListWithDetailsPaging(chart.ChartData);
                    objTemp.MaxYear = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Max(x => Convert.ToDateTime(x.Date)).Year : 2008;
                    objTemp.MinYear = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Min(x => Convert.ToDateTime(x.Date)).Year : 2007;
                    objTemp.EndDate = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Max(x => Convert.ToDateTime(x.Date)).ToShortDateString() : "1/1/2015";
                    objTemp.StartDate = objTemp.ChartData.Count > 0 ? objTemp.ChartData.Min(x => Convert.ToDateTime(x.Date)).ToShortDateString() : "12/1/2015";
                    //objTemp.State = chart.State;
                    //objTemp.Unit = chart.Unit;
                    //objTemp.ChartName = chart.Tier1_Attribute;
                    objTemp.Attribute1_ID = Convert.ToInt64(chart.Tier1_Attr_Id);
                    objTemp.Attribute2_ID = Convert.ToInt64(chart.Tier2_Attr_Id);
                    objTemp.Attribute3_ID = Convert.ToInt64(chart.Tier3_Attr_Id);
                    //objTemp.Attribute2 = chart.Tier2_Attribute;
                    //objTemp.Attribute3 = chart.Tier3_Attribute;
                    objTemp.ChartTypeID = chart.chart_Type_Id;
                    objTemp.UnitID = Convert.ToInt32(chart.Unit_id);
                    objTemp.TimeLevelID = Convert.ToInt32(chart.TimeLevelID);
                    objTemp.SourceID = Convert.ToInt32(chart.Source_id);
                    objTemp.TimeLevelFrequency = GetTimeLevelFrequency(chart.TimeLevel);
                    objTemp.LocationLevel = GetLocationLevel(chart.LocationLevel);
                    //objTemp.DefaultLocation = chart.DefaultLocation;
                    objTemp.Units = GetUnits(chart.Units);
                    objTemp.Sources = GetSources(chart.Sources);
                    objTemp.UnitID = Convert.ToInt32(chart.Unit_id);
                    objTemp.DetailIDList = objTemp.ChartData.Select(x => x.Detail).Distinct().ToList();
                    //objTemp.DetailIDList = objDBData.Where(x => x.ChartID == chart.ChartID).Select(x => x.detail).Distinct().ToList();
                    objTemp.MinMaxYear = chart.MinMaxYear;
                    objJSON.Add(objTemp);
                }
            }
            catch (Exception ex) { }
            return objJSON;
        }
        private List<ChartData> GetChartDataList(string chartData, string detail, int detailId)
        {
            List<ChartData> objChartData = new List<ChartData>();
            if (chartData != null)
            {
                string[] chartValues = chartData.Split(',');
                foreach (var item in chartValues)
                {
                    string[] data = item.Split('-');
                    objChartData.Add(
                        new ChartData
                        {
                            Value = Convert.ToDecimal(data[0]),
                            Date = data[1],
                            Detail = detail,
                            DetailId = detailId

                        });
                }
            }
            return objChartData;
        }
        private List<ChartData> GetChartDataListWithDetailsPaging(string chartData)
        {
            List<ChartData> objChartData = new List<ChartData>();
            if (chartData != null)
            {
                string[] chartValues = chartData.Split('@');
                foreach (var item in chartValues)
                {
                    //string demo = "92228203.0000-12/31/2007 | 1309-CORN - ACRES HARVESTED,92228203.0000-12/31/2007 | 1309-CORN - ACRES HARVESTED,6103769.0000-12/31/2007 | 1917-CORN, GRAIN, IRRIGATED, ENTIRE CROP - ACRES HARVESTED,6103769.0000-12/31/2007 | 1917-CORN, GRAIN, IRRIGATED, ENTIRE CROP - ACRES HARVESTED,4318170.0000-12/31/2007 | 7982-CORN, SILAGE, IRRIGATED, NONE OF CROP - ACRES HARVESTED,4318170.0000-12/31/2007 | 7982-CORN, SILAGE, IRRIGATED, NONE OF CROP - ACRES HARVESTED,1369278.0000-12/31/2007 | 14141-CORN, SILAGE, IRRIGATED, ENTIRE CROP - ACRES HARVESTED,1369278.0000-12/31/2007 | 14141-CORN, SILAGE, IRRIGATED, ENTIRE CROP - ACRES HARVESTED,128010.0000-12/31/2007 | 15594-CORN, SILAGE, IRRIGATED, PART OF CROP, IRRIGATED PORTION - ACRES HARVESTED,128010.0000-12/31/2007 | 15594-CORN, SILAGE, IRRIGATED, PART OF CROP, IRRIGATED PORTION - ACRES HARVESTED,1497288.0000-12/31/2007 | 16061-CORN, SILAGE, IRRIGATED - ACRES HARVESTED,1497288.0000-12/31/2007 | 16061-CORN, SILAGE, IRRIGATED - ACRES HARVESTED,86248542.0000-12/31/2007 | 17008-CORN, GRAIN - ACRES HARVESTED,86248542.0000-12/31/2007 | 17008-CORN, GRAIN - ACRES HARVESTED,5979661.0000-12/31/2007 | 17310-CORN, SILAGE - ACRES HARVESTED,5979661.0000-12/31/2007 | 17310-CORN, SILAGE - ACRES HARVESTED,13156769.0000-12/31/2007 | 18141-CORN, GRAIN, IRRIGATED - ACRES HARVESTED,13156769.0000-12/31/2007 | 18141-CORN, GRAIN, IRRIGATED - ACRES HARVESTED,66656287.0000-12/31/2007 | 20697-CORN, GRAIN, IRRIGATED, NONE OF CROP - ACRES HARVESTED,66656287.0000-12/31/2007 | 20697-CORN, GRAIN, IRRIGATED, NONE OF CROP - ACRES HARVESTED,7053000.0000-12/31/2007 | 25696-CORN, GRAIN, IRRIGATED, PART OF CROP, IRRIGATED PORTION - ACRES HARVESTED,7053000.0000-12/31/2007 | 25696-CORN, GRAIN, IRRIGATED, PART OF CROP, IRRIGATED PORTION - ACRES HARVESTED";
                    int pipelen = item.IndexOf('|');
                    string[] chart = item.Substring(0, pipelen).Split('-');
                    string detailData = item.Substring(pipelen + 1);
                    int detailId = Convert.ToInt32(detailData.Substring(0, detailData.IndexOf('-')));
                    string detail = detailData.Substring(detailData.IndexOf('-') + 1);
                    objChartData.Add(
                        new ChartData
                        {
                            Value = Convert.ToDecimal(chart[0]),
                            Date = chart[1],
                            Detail = detail,
                            DetailId = detailId

                        });
                }
            }
            return objChartData;
        }
        List<TimeLevel_Frequency> GetTimeLevelFrequency(string timelevels)
        {
            List<TimeLevel_Frequency> TimeLevel_Frequency = new List<TimeLevel_Frequency>();
            if (timelevels != null)
            {
                string[] chartValues = timelevels.Split(',');
                foreach (var item in chartValues)
                {
                    string[] data = item.Split('-');
                    TimeLevel_Frequency.Add(
                        new TimeLevel_Frequency
                        {
                            TimeLevel_id = Convert.ToInt32(data[0]),
                            Frequency = data[1]
                        });
                }
            }
            return TimeLevel_Frequency;
        }

        List<string> GetLocationLevel(string locations)
        {
            List<string> levels = new List<string>();
            if (locations != null)
            {
                foreach (var item in locations.Split(','))
                {
                    levels.Add(item);
                }
            }
            return levels;
        }
        List<Units> GetUnits(string units)
        {
            List<Units> unitsList = new List<Units>();
            if (units != null)
            {
                string[] chartValues = units.Split(',');
                foreach (var item in chartValues)
                {
                    string[] data = item.Split('-');
                    unitsList.Add(
                        new Units
                        {
                            UnitId = Convert.ToInt32(data[0]),
                            Unit = data[1]
                        });
                }
            }
            return unitsList;
        }
        List<Sources> GetSources(string units)
        {
            List<Sources> unitsList = new List<Sources>();
            if (units != null)
            {
                string[] chartValues = units.Split(',');
                foreach (var item in chartValues)
                {
                    string[] data = item.Split('-');
                    unitsList.Add(
                        new Sources
                        {
                            SourceId = Convert.ToInt32(data[0]),
                            Source = string.IsNullOrEmpty(data[1]) ? "Default" : data[1]
                        });
                }
            }
            return unitsList;
        }
        #endregion

        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSearchData")]
        public List<usp_Report_Download_Data_Result> GetSearchData
            (string NotificationId)
        {
            string sector = null; string superRegion = null; string subSector_Id = null; string timeLevel_Id = null; string locationLevelName = null; string c_Tier1_Id = null; string c_Tier2_Id = null;
            string c_Tier3_Id = null; string source_Id = null; string country_Id = null; string county_Id = null; string state_Id = null; string attr1_Id = null; string attr2_Id = null;
            DateTime? startDate = null; DateTime? endDate = null;
            DataCostBl bl = new DataCostBl();

            //checking data is in cached or not
            List<usp_Report_Download_Data_Result> data = Utilities.CacheHelper.Get<List<usp_Report_Download_Data_Result>>("GetSearchData");
            if (data == null)
            {
                sector = "AGRICULTURE";
                superRegion = "UNITED STATES";
                subSector_Id = "1";
                startDate = Convert.ToDateTime("2007-12-31");
                endDate = Convert.ToDateTime("2008-03-31");
                //fetching data
                data = bl.GetSearchData(NotificationId);
                //add data to cache for future use
                // Utilities.CacheHelper.Add<List<usp_Report_Download_Data>>(data, "GetSearchData");
            }

            return data;
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSearchDataCost")]
        public List<usp_Report_Download_Data_Cost_Result> GetSearchDataCost(DataCostFilters _filter)
        {
            //string sector = null; string superRegion = null; string subSector_Id = null; string timeLevel_Id = null; string locationLevelName = null; string c_Tier1_Id = null; string c_Tier2_Id = null;
            //string c_Tier3_Id = null; string source_Id = null; string country_Id = null; string county_Id = null; string state_Id = null; string attr1_Id = null; string attr2_Id = null;
            //DateTime? startDate = null; DateTime? endDate = null;
            DataCostBl bl = new DataCostBl();

            //checking data is in cached or not
            List<usp_Report_Download_Data_Cost_Result> data = Utilities.CacheHelper.Get<List<usp_Report_Download_Data_Cost_Result>>("GetSearchDataCost");
            if (data == null)
            {
                //sector = "AGRICULTURE";
                //superRegion = "UNITED STATES";
                //subSector_Id = "1";
                //startDate = Convert.ToDateTime("2007-12-31");
                //endDate = Convert.ToDateTime("2008-03-31");
                //fetching data
                data = bl.GetSearchDataCost(_filter);

                //data = bl.GetSearchDataCost(sector, superRegion, subSector_Id, timeLevel_Id, locationLevelName, c_Tier1_Id, c_Tier2_Id, c_Tier3_Id, source_Id,
                //                       country_Id, county_Id, state_Id, attr1_Id, attr2_Id, startDate, endDate);
                
                //add data to cache for future use
                // Utilities.CacheHelper.Add<List<usp_Report_Download_Data>>(data, "GetSearchData");
            }

            return data;
        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("DownloadFile")]
        public HttpResponseMessage DownloadFile(string NotificationId)
        {
            //string sector = null; string superRegion = null; string subSector_Id = null; string timeLevel_Id = null; string locationLevelName = null; string c_Tier1_Id = null; string c_Tier2_Id = null;
            //string c_Tier3_Id = null; string source_Id = null; string country_Id = null; string county_Id = null; string state_Id = null; string attr1_Id = null; string attr2_Id = null;
            //DateTime? startDate = null; DateTime? endDate = null;
            DataCostBl bl = new DataCostBl();

            //checking data is in cached or not
            List<usp_Report_Download_Data_Result> data = null;
            //sector = "AGRICULTURE";
            //superRegion = "UNITED STATES";
            //subSector_Id = "1";
            //startDate = Convert.ToDateTime("2007-12-31");
            //endDate = Convert.ToDateTime("2008-03-31");
            //fetching data
            data = bl.GetSearchData(NotificationId);

            try
            {
                GridView gv = new GridView();
                gv.DataSource = data;
                gv.DataBind();
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);

                var binFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                var mStream = new MemoryStream();
                binFormatter.Serialize(mStream, sw.ToString());

                //This gives you the byte array.
                //mStream.ToArray();

                byte[] excelData = mStream.ToArray();



                HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
                var stream = new MemoryStream(excelData);
                result.Content = new StringContent(sw.ToString());//  new StreamContent(stream);
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                {
                    FileName = "Data.xls"
                };
                return result;
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError);
            }


            //using (XLWorkbook wb = new XLWorkbook())
            //{
            //    wb.Worksheets.Add(dt);
            //    wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            //    wb.Style.Font.Bold = true;

            //    Response.Clear();
            //    Response.Buffer = true;
            //    Response.Charset = "";
            //    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            //    Response.AddHeader("content-disposition", "attachment;filename= EmployeeReport.xlsx");

            //    using (MemoryStream MyMemoryStream = new MemoryStream())
            //    {
            //        wb.SaveAs(MyMemoryStream);
            //        MyMemoryStream.WriteTo(Response.OutputStream);
            //        Response.Flush();
            //        Response.End();
            //    }
            //}

        }


        #endregion

        #region GetData V1

        //#region GetTimeLevelBasedonSectorAndSuperRegion
        //[System.Web.Http.HttpPost]
        //[System.Web.Http.ActionName("GetTimeLevelBasedonSectorAndSuperRegion")]
        //public List<usp_Report_Select_Time_Level_Result> GetTimeLevelBasedonSectorAndSuperRegion(DataCostFilters _filter)
        //{
        //    DataCostBl bl = new DataCostBl();
        //    return bl.GetTimeLevel(_filter);
        //}
        //#endregion

        #endregion
    }
}
