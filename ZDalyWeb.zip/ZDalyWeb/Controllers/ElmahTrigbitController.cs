using ZDalyWeb.Helpers;
using ZDalyWeb.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace ZDalyWeb.Controllers
{
    public class ElmahTrigbitController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {

            return View();
        }
        [AbortAjaxAttribute]
        [HttpPost]
        public async Task<JsonResult> GetAllErrors(Pagination p)
        {
            Debug.WriteLine("GelAll errors hit");
            p.Start = p.Page * p.ItemsShow + 1;
            p.End = p.Start + p.ItemsShow - 1;
            var data = await ElmahDbHelper.GetAllErrors(p);
            return Json(data, JsonRequestBehavior.AllowGet);

        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetErrorsGroupBy(Pagination p)
        {
            Debug.WriteLine("GetErrorsGroupBy  hit");
            p.Start = p.Page * p.ItemsShow + 1;
            p.End = p.Start + p.ItemsShow - 1;
            ServerElmahGroup group = await ElmahDbHelper.GetAllErrorsGroupBy(p);
            return Json(group, JsonRequestBehavior.AllowGet);
        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetErrorsForChart()
        {

            Debug.WriteLine("GetErrorsForChart  hit");
            var data = await ElmahDbHelper.GetErrorsForChart();
            return Json(data, JsonRequestBehavior.AllowGet);

        }

        public ActionResult ErrorsByGroup()
        {
            return View();
        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetRecentErrors()
        {
            Debug.WriteLine("GetRecentErrors  hit");
            var data = await ElmahDbHelper.RecentErrors();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetFrequentErrors()
        {
            Debug.WriteLine("GetFrequentErrors  hit");
            var data = await ElmahDbHelper.GetFrequentErrors();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetFrequentURL()
        {
            Debug.WriteLine("GetFrequentErrors  hit");
            var data = await ElmahDbHelper.GetFrequentURL();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Elmah()
        {
            return View();
        }
        [AbortAjaxAttribute]
        public async Task<JsonResult> GetErrorsCount()
        {
            Debug.WriteLine("GetErrorsCount  hit");
            var data = await ElmahDbHelper.GetAllErrorsCount();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetErrorDetail(string id)
        {
            return Json(ElmahDbHelper.GetServerVariablesByID(id), JsonRequestBehavior.AllowGet);
            
        }

    }
}