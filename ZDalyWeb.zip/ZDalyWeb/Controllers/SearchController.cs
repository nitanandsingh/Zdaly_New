﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ZDalyWeb.Helpers;
using ZDalyWeb.Models.Dapper;
using ZDalyWeb.ViewModels;

namespace ZDalyWeb.Controllers
{
    public class SearchController : ApiController
    {
        private DapperManager dapperMngr = new DapperManager();

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCountries")]
        public List<CountriesVM> GetCountries(FilterData obj)
        {
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            var list = dapperMngr.GetCountries(obj.sector, obj.superRegion, obj.attributeIds);
            if (list.Count == 0)
            {
                list.Add(new CountriesVM { Id = 3, Country = "UNITED STATES" });
            }
            else
            {
                list.ForEach(x =>
                {
                    x.Country = x.Name;
                    x.Id = x.RegionId;
                });
            }
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetStates")]
        public List<StatesVM> GetStates(FilterData obj)
        {
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            var list = dapperMngr.GetStates(obj.sector, obj.superRegion, obj.attributeIds, obj.regionId);
            list.ForEach(x => x.State = x.Name);
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetCounties")]
        public List<CountiesVM> GetCounties(FilterData obj)
        {
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            var list = dapperMngr.GetCounties(obj.sector, obj.superRegion, obj.attributeIds, obj.regionId);
            list.ForEach(x =>
            {
                x.County = x.Name;
                x.Id = x.RegionId;
            });
            return list;
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAllLocation")]
        public object GetAllLocation(Location location)
        {
            location.AttrBucket = string.Join(",", location.AttrBucket.Split(',').Distinct());
            var countrylist = dapperMngr.GetCountries(location.sectorId, location.superRegionId, location.AttrBucket);
            if (countrylist.Count == 0)
            {
                countrylist.Add(new CountriesVM { Id = 3, Country = "UNITED STATES" });
            }
            else
            {
                countrylist.ForEach(x =>
                {
                    x.Country = x.Name;
                    x.Id = x.RegionId;
                });
            }

            List<StatesVM> statelist = new List<StatesVM>();
            if (location.CountryId != 0)
            {
                statelist = dapperMngr.GetStates(location.sectorId, location.superRegionId, location.AttrBucket, location.CountryId);
                statelist.ForEach(x => x.State = x.Name);
            }
            List<CountiesVM> list = new List<CountiesVM>();
            if (location.StateId != 0)
            {
                list = dapperMngr.GetCounties(location.sectorId, location.superRegionId, location.AttrBucket, location.StateId);
                list.ForEach(x =>
                {
                    x.County = x.Name;
                    x.Id = x.RegionId;
                });
            }
            return new { countrylist = countrylist, statelist = statelist, countylist = list };
        }


        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAttributeLevel1")]
        public List<AttributesVM> GetAttributeLevel1(FilterData obj)
        {
            int? rId = null;

            if (obj.regionId != 0)
                rId = obj.regionId;
            var list = dapperMngr.GetAttributeLevel1(obj.sector, obj.superRegion, obj.stratumId, obj.attributeIds, obj.remainingStratumCount, obj.selectedStratumIds, rId);
            list.Where(x => string.IsNullOrEmpty(x.Entry)).ToList().ForEach(x => x.Entry = "OVERALL");
            return list;
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetFilterTypes")]
        public List<FilterTypes> GetFilterTypes(FilterData obj)
        {
            int? rId = null;
            int? eId = null;
            if (obj.regionId != 0)
                rId = obj.regionId;

            if (obj.entryId != 0)
                eId = obj.entryId;

            string selectedStratumIds = "";
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            var uniqueAttrsList = dapperMngr.GetUniqueAttributes(obj.sector, obj.superRegion, obj.attributeIds, rId);
            if (uniqueAttrsList.Count > 0)
            {
                selectedStratumIds = string.Join(",", uniqueAttrsList.Select(x => x.StratumId));
            }
            var list = dapperMngr.GetFilterTypes(obj.sector, obj.superRegion, obj.attributeIds, rId, eId, selectedStratumIds);
            int top = 114;
            list.ForEach(x =>
            {
                top = 50 + top;
                x.topPointer = top;
            });
            return list;

        }

        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetAttributeNLevel")]
        public List<AttributeNLevel> GetAttributeNLevel(int levelId, string attributeIds, int regionId)
        {
            int? rId = null;

            if (regionId != 0)
                rId = regionId;

            var list = dapperMngr.GetAttributeNLevel(levelId, attributeIds, rId);
            return list;
        }
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetAllSectors")]
        public List<Sectors> GetAllSectors()
        {

            var list = dapperMngr.GetAllSectors();
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetAttributes")]
        public HttpResponseMessage GetAttributes(FilterData obj)
        {

            //int sector = 1, int superRegion = 1, int stratumId = 12, string attrBucket = "1,2,3,4", string selectedStratumId = null, int RemainingStratumCount = 1

            //string attrbuckets = " 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54";
            DapperManager dbMngr = new DapperManager();
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            List<StratumExpansionVM> stratumsList = dbMngr.GetRemainingStratums(obj.sector, obj.superRegion, string.Join(",", obj.selectedStratumIds.Split(',').Distinct()));
            List<StratumVM> finalList = new List<StratumVM>();
            List<Group> groups = new List<Group>();
            foreach (var str in stratumsList)
            {
                DataTable dt = dbMngr.GetLeftMenuDashboardData(obj.sector, obj.superRegion, obj.attributeIds, str.StratumIds, string.IsNullOrEmpty(obj.locationIds) ? null : obj.locationIds);
                List<StratumVM> list = dbMngr.GetStartumns(str.StratumIds);
                #region Assign Data
                foreach (var item in list)
                {
                    item.attr = new List<Pair<string, string, string>>();
                    foreach (DataRow c in dt.Rows)
                    {
                        if (!string.IsNullOrEmpty(c[item.Name].ToString()))
                        {
                            Pair<string, string, string> cc = new Pair<string, string, string>();
                            cc.First = c["AtrrBucket"].ToString();
                            cc.Second = c[item.Name].ToString();
                            item.attr.Add(cc);
                        }
                    }
                }
                #endregion
                #region AssignParents
                int minLevel = list.Select(x => x.Level).Min();
                Group objG = null;
                foreach (var itemP in list)
                {
                    if (itemP.Level != minLevel)
                    {
                        foreach (var item in itemP.attr)
                        {
                            objG = new Group();
                            objG.text = item.Second;

                            List<string> cABList = item.First.Replace(" ", "").Split(',').ToList();
                            List<string> parentList = new List<string>();

                            foreach (var ss in list.Where(x => x.Level == itemP.Level - 1).ToList())
                            {
                                foreach (var xx in ss.attr)
                                {

                                    var f = xx.First;
                                    var s = xx.Second;
                                    parentList = f.Replace(" ", "").Split(',').ToList();

                                    if (cABList.Intersect(parentList).Count() == cABList.Count)
                                    {
                                        item.Third = xx.Second;
                                        objG.ParentID = xx.Second;
                                        objG.attrs = item.First.Replace(" ", "").Replace(",", "-");
                                        objG.href = "#" + objG.attrs;
                                        break;
                                    }
                                    else
                                    {
                                        item.Third = xx.Second;
                                        objG.ParentID = "InCorrect";
                                        objG.attrs = item.First.Replace(" ", "").Replace(",", "-");
                                        objG.href = "#" + objG.attrs;
                                    }
                                }
                            }
                            groups.Add(objG);
                        }
                    }
                    else
                    {
                        foreach (var item in itemP.attr)
                        {
                            objG = new Group();
                            objG.text = item.Second;
                            objG.attrs = item.First.Replace(" ", "").Replace(",", "-");
                            objG.href = "#" + objG.attrs;
                            objG.ParentID = null;
                            groups.Add(objG);
                        }
                    }
                }
                #endregion
                finalList.AddRange(list);
            }

            #region
            //string tree = string.Empty;
            //List<NodeVM> nodes = new List<NodeVM>();
            //List<NodeVM> innernodes = new List<NodeVM>();
            //int levelCount = finalList.Max(X => X.Level); int count = 1;
            //NodeVM node = new NodeVM();
            //node.nodes = new List<NodeVM>();
            //foreach (var level1 in finalList.Where(x => x.Level == 1))
            //{


            //    int id = level1.Id;
            //    int pid = id;
            //    foreach (var attr in level1.attr)
            //    {
            //        node = new NodeVM();
            //        node.nodes = new List<NodeVM>();
            //        node.text = attr.Second;
            //        string attrName = attr.Second.ToLower();

            //        for (int i = level1.Level; i < levelCount; i++)
            //        {

            //            bool islevelExist = isLevelExist(finalList, i + 1,ref pid, ref attrName);
            //            if (islevelExist)
            //            {
            //                innernodes = new List<NodeVM>();
            //                count++;
            //                foreach (var innerlevel1 in finalList.Where(x => x.Parent == pid))
            //                {
            //                    foreach (var innerAttr in innerlevel1.attr)
            //                    {
            //                        if (!string.IsNullOrEmpty(innerAttr.Third))
            //                        {
            //                            if (innerAttr.Third.ToLower() == attrName)
            //                            {
            //                                attrName = innerAttr.Second.ToLower();
            //                                var node1 = new NodeVM { text = innerAttr.Second };
            //                                innernodes.Add(node1);
            //                            }
            //                        }
            //                    }
            //                    node.nodes.AddRange(innernodes);
            //                }
            //            }

            //        }
            //        nodes.Add(node);
            //    }

            //if (islevelExist)
            //{
            //    node.nodes.Add()
            //}

            //}
            #endregion

            IList<Group> tree = GroupEnumerable.BuildTree(groups);

            List<Group> lastLevelAttrs = tree.Where(x => x.nodes.Count == 0).ToList();

            tree.Where(x => x.nodes.Count != 0).ToList().ForEach(x => x.attrs = "NO");
            tree.Where(x => x.nodes.Count != 0).ToList().ForEach(x => x.href = "#NO");

            List<Group> childLastLevel = new List<Group>();

            Action<Group> traverse = null;

            traverse = (n) =>
            {

                if (n.nodes.Count == 0)
                {
                    childLastLevel.Add(n);
                }
                else
                {
                    n.attrs = "NO";
                    n.href = "#NO";
                }

                n.nodes.ForEach(traverse);
            };

            foreach (var item in tree.Where(x => x.nodes.Count != 0))
            {
                traverse(item);
            }

            lastLevelAttrs.AddRange(childLastLevel);
            var jsonObj = new { oldList = finalList, lastLevels = lastLevelAttrs, treeNodes = tree };
            return Request.CreateResponse(HttpStatusCode.OK, jsonObj);
            //var list = dapperMngr.GetAttributes(obj.sector, obj.superRegion, obj.stratumId, obj.attributeIds, obj.remainingStratumCount, null, null);
            //return list;
            //return finalList;
        }

        bool isLevelExist(List<StratumVM> levelList, int level, ref int pid, ref string name)
        {

            bool flag = false;
            foreach (var item in levelList)
            {
                //int pid = id;
                if (item.Level == level && item.Parent == pid)
                {

                    foreach (var attr in item.attr)
                    {
                        if (!string.IsNullOrEmpty(attr.Third))
                        {
                            if (attr.Third.ToLower() == name)
                            {
                                pid = Convert.ToInt32(item.Id);
                                flag = true;
                            }
                        }
                    }



                    // isLevelExist(levelList, item.Level+1, item.Id);                    
                }
            }

            return flag;
        }
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetSearchResult")]
        public List<SearchResult> GetSearchResult(string query)
        {
            var list = dapperMngr.GetSearchResult(query);
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetChartData")]
        public List<ChartData> GetChartData(FilterData obj)
        {
            if (obj.attributeIds.Contains('-'))
            {
                obj.attributeIds = obj.attributeIds.Replace('-', ',');
            }

            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());

            var list = dapperMngr.GetChartData(obj.sector, obj.superRegion, obj.attributeIds, obj.chartDisplayId, obj.regionType == 0 ? 3 : obj.regionType, string.IsNullOrEmpty(obj.locationIds) ? null : obj.locationIds);
            list.ForEach(x => x.Year = x.ValueDate.Year);

            if (obj.regionType != 0)
                list.ForEach(x => x.ValueDateString = x.Name);
            else
                list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetChartDataOnSelections")]
        public List<ChartData> GetChartDataOnSelections(FilterData obj)
        {
            List<string> intersects = new List<string>();
            int count = 0;
            foreach (var item in obj.selectionsAttrs)
            {
                for (int i = 0; i < obj.selectionsAttrs.Count; i++)
                {
                    if (count > i)
                    {
                        var intersect = string.Join(",", item.AttrBucket.Split(',').ToArray().Intersect(obj.selectionsAttrs[i].AttrBucket.Split(',').ToArray()).ToList());
                        intersects.Add(intersect);
                    }

                }
                count++;
            }
            //var list = dapperMngr.GetChartData(obj.sector, obj.regionId, obj.attributeIds, obj.chartDisplayId, obj.locationId, obj.regionType);
            //list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
            //return list;
            return null;
        }
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetChartSelections")]
        public List<StratumVM> GetChartSelections(int sectorId, int superRegion, int level = 100)
        {
            var list = dapperMngr.GetChartSelections(sectorId, superRegion, level);
            return list;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetSelectionValueBySelected")]
        public List<StratumVM> GetSelectionValueBySelected(FilterData obj)
        {
            //FilterData obj = null;
            //obj = new FilterData();
            //string attrbuckets = " 1, 2, 3, 4";//5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54
            //obj.sector = 1;
            //obj.superRegion = 1;
            //obj.attributeIds = attrbuckets;

            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());

            if (obj.level == 101)
            {
                List<StratumVM> detailSelection = dapperMngr.GetSelectionsForLEVEL101(obj.attributeIds);
                return detailSelection;
            }

            List<StratumVM> selection = dapperMngr.GetChartSelections(obj.sector, obj.superRegion, obj.level = obj.level);

            List<StratumVM> finalList = new List<StratumVM>();

            obj.selectedStratumIds = string.Join(",", selection.Select(x => x.Id).ToArray());
            DataTable dt = dapperMngr.GetLeftMenuDashboardData(obj.sector, obj.superRegion, obj.attributeIds, obj.selectedStratumIds, string.IsNullOrEmpty(obj.locationIds) ? null : obj.locationIds);
            foreach (var item in selection)
            {
                item.attr = new List<Pair<string, string, string>>();
                foreach (DataRow c in dt.Rows)
                {
                    if (!string.IsNullOrEmpty(c[item.Name].ToString()))
                    {
                        Pair<string, string, string> cc = new Pair<string, string, string>();
                        cc.First = c["AtrrBucket"].ToString();
                        cc.Second = c[item.Name].ToString();
                        item.attr.Add(cc);
                    }
                }
            }
            return selection;
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetRegionTypes")]
        public List<Sectors> GetRegionTypes(FilterData obj)
        {
            obj.attributeIds = string.Join(",", obj.attributeIds.Split(',').Distinct());
            var list = dapperMngr.GetRegionTypes(obj.attributeIds);
            return list;
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetChartDataNew")]
        public List<ChartData> GetChartDataNew(ChartDataParams param)
        {
            //objList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ResultVM>>(json);
            try
            {
                bool state = !(param.RegionType == "0");
                dynamic jsonResponse = JsonConvert.DeserializeObject(param.JsonObject);
                List<long> allSeries = new List<long>();
                List<SeriesRow> seriesRow = new List<SeriesRow>();
                //to store comma seperated
                string seriesID = "";
                string dbName = "";
                int count = jsonResponse.Count;

                for (int i = 0; i < count; i++)
                {

                    var item = jsonResponse[i];
                    var data = item.data;
                    var seriesId = data.seriesId;
                    var itemstate = data.state;
                    var country = data.country;
                    var county = data.county;
                    JObject stratums = item.stratums;
                    Dictionary<string, string> dicstratums = new Dictionary<string, string>();
                    foreach (var item1 in stratums)
                    {
                        var myItemKey = item1.Key;
                        var myItemValue = item1.Value;
                        dicstratums.Add(myItemKey, myItemValue.ToString());
                    }
                    allSeries.Add((long)seriesId);

                    seriesRow.Add(new SeriesRow { Series = seriesId, Country = country, State = itemstate, County = county, Attributes = dicstratums });
                    
                    dbName = item.dbName;

                }
                seriesID = string.Join(",", allSeries);
                var list = dapperMngr.GetChartDataNew(seriesID, dbName);

                list.ForEach(x => { x.Detail = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().Attributes[param.Detail]; });
                list.ForEach(x => x.County = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().County);
                list.ForEach(x => x.Country = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().Country);
                list.ForEach(x => x.State = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().State);
 
                // var data4465 = list.Where(i => i.Series == 4465844).FirstOrDefault();
                var sample = list.Where(i => i.State != null);
                //list = list.GroupBy(x => new { x.ValueDate, x.Detail }).Select(g => g.OrderByDescending(x => x.Value).First()).ToList();
                list.ForEach(x => x.Year = x.ValueDate.Year);
                if (list.Count > 10)
                {
                    list.ForEach(x => x.ValueDateString = x.ValueDate.Year.ToString());
                }
                else
                {
                    list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
                }



                if (state)
                {
                    list = list.OrderByDescending(x => x.Value).ToList();
                }
                else
                {
                    list.ForEach(x => x.Year = x.ValueDate.Year);
                    list = list.OrderBy(x => x.ValueDate).ToList();
                }


                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetChartDataNewOne")]
        public List<ChartData> GetChartDataNewOne(ChartDataParams param)
        {
            bool state = !(param.RegionType == "0");
             dynamic jsonResponse = JsonConvert.DeserializeObject(param.JsonObject);
            List<long> allSeries = new List<long>();
            List<SeriesRowNew> seriesRow = new List<SeriesRowNew>();
            //to store comma seperated
            string seriesID = "";
            string dbName = "";
            int count = jsonResponse.Count;

            for (int i = 0; i < count; i++)
            {

                var item = jsonResponse[i];
              
                var seriesId = item.seriesId;
                var stateItem = item.state;
                var country = item.country;
                var county = item.county;
                var zipcode = item["zipcode"];
                var detail=item[param.Detail];
                allSeries.Add((long)seriesId);
                // var seriesIdCount = seriesId.Count;
                //foreach (var item1 in seriesIds)
                //{
                //    var val = (long)item1;
                //    allSeries.Add(val);
                //    seriesRow.Add(new SeriesRow { Series = val, Country = country, State = state, County = county, Attributes = dicstratums });
                //}

                seriesRow.Add(new SeriesRowNew { Series = seriesId, Country = country, State = stateItem, County = county, Detail = detail,ZipCode=zipcode });
                //foreach (var prop in stratums.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                //{
                //    var name = prop.Name;
                //    var value = prop.GetValue(stratums, null);
                //   // Console.WriteLine("Name: {0}, Value: {1}", prop.Name, prop.GetValue(stratums, null));
                //}
                if (string.IsNullOrEmpty(dbName))
                dbName = item.dbName;

            }
            seriesID = string.Join(",", allSeries);
            var list = dapperMngr.GetChartDataNew(seriesID, dbName);
            list.ForEach(x => { x.Detail = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().Detail; });
            list.ForEach(x => x.County = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().County);
            list.ForEach(x => x.Country = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().Country);
            list.ForEach(x => x.State = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().State);
            list.ForEach(x => x.ZipCode = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().ZipCode);
            // var data4465 = list.Where(i => i.Series == 4465844).FirstOrDefault();
            var sample = list.Where(i => i.State != null);
            //list = list.GroupBy(x => new { x.ValueDate, x.Detail }).Select(g => g.OrderByDescending(x => x.Value).First()).ToList();
            list.ForEach(x => x.Year = x.ValueDate.Year);
            if (list.Count > 10)
            {
                list.ForEach(x => x.ValueDateString = x.ValueDate.Year.ToString());
            }
            else
            {
                list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
            }



            if (state)
            {
                list = list.OrderByDescending(x => x.Value).ToList();
            }
            else
            {
                list.ForEach(x => x.Year = x.ValueDate.Year);
                list = list.OrderBy(x => x.ValueDate).ToList();
            }


            return list;
        }



        //public List<ChartData> GetChartDataNew(List<ResultVM> objList)
        //{
        //    //objList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ResultVM>>(json);
        //    try
        //    {
        //        dynamic jsonResponse = JsonConvert.DeserializeObject(JsonObject);
        //        List<long> allSeries = new List<long>();
        //        List<SeriesRow> seriesRow = new List<SeriesRow>();
        //        //to store comma seperated
        //        string seriesID = "";
        //        string dbName = "";
        //        int count = jsonResponse.Count;

        //        for (int i = 0; i < count; i++)
        //        {

        //            var item = jsonResponse[i];
        //            var data = item.data;
        //            var seriesId = data.seriesId;
        //            var state = data.state;
        //            var country = data.country;
        //            var county = data.county;
        //            JObject stratums = item.stratums;
        //            Dictionary<string, string> dicstratums = new Dictionary<string, string>();
        //            foreach (var item1 in stratums)
        //            {
        //                var myItemKey = item1.Key;
        //                var myItemValue = item1.Value;
        //                dicstratums.Add(myItemKey, myItemValue.ToString());
        //            }
        //            allSeries.Add((long)seriesId);
        //            // var seriesIdCount = seriesId.Count;
        //            //foreach (var item1 in seriesIds)
        //            //{
        //            //    var val = (long)item1;
        //            //    allSeries.Add(val);
        //            //    seriesRow.Add(new SeriesRow { Series = val, Country = country, State = state, County = county, Attributes = dicstratums });
        //            //}

        //            seriesRow.Add(new SeriesRow { Series = seriesId, Country = country, State = state, County = county, Attributes = dicstratums });
        //            //foreach (var prop in stratums.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
        //            //{
        //            //    var name = prop.Name;
        //            //    var value = prop.GetValue(stratums, null);
        //            //   // Console.WriteLine("Name: {0}, Value: {1}", prop.Name, prop.GetValue(stratums, null));
        //            //}
        //            dbName = item.dbName;

        //        }
        //        seriesID = string.Join(",", allSeries);
        //        var list = dapperMngr.GetChartDataNew(seriesID, dbName);


        //        list.ForEach(x => { x.Detail = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().DetailID; x.StratumName = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().StratumName; });
        //        list.ForEach(x => x.County = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().County);
        //        list.ForEach(x => x.Country = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().Country);
        //        list.ForEach(x => x.State = seriesRow.Where(y => y.Series == x.Series).FirstOrDefault().State);



        //        //List<string> allVals = new List<string>();
        //        ////header
        //        //SeriesRow row = seriesRow.FirstOrDefault();
        //        //allVals.Add("Series[SPLIT]Country[SPLIT]State[SPLIT]County[SPLIT]" + string.Join("[SPLIT]", row.Attributes.Keys) + "[SPLIT]Value[SPLIT]ValueDateString");
        //        //foreach (var item in list)
        //        //{
        //        //    var seriesId = item.Series;
        //        //    var rowItem = seriesRow.Where(i => i.Series == seriesId).FirstOrDefault();
        //        //    var stringData = seriesId + "[SPLIT]" + rowItem.Country + "[SPLIT]" + rowItem.State + "[SPLIT]" + rowItem.County + "[SPLIT]";
        //        //    List<string> attributeVals = new List<string>();
        //        //    foreach (var key in rowItem.Attributes.Keys)
        //        //    {
        //        //        attributeVals.Add(rowItem.Attributes[key]);
        //        //    }
        //        //    stringData += string.Join("[SPLIT]", attributeVals) + "[SPLIT]";
        //        //    stringData += item.Value + "[SPLIT]";
        //        //    stringData += item.ValueDate.ToString();
        //        //    allVals.Add(stringData);

        //        //}

        //        return list;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("AddNewFavorite")]
        public HttpResponseMessage AddNewFavorite(UserFavorite obj)
        {
            int res = dapperMngr.AddNewFavorite(obj.json, obj.header, obj.chartType);
            return Request.CreateResponse(HttpStatusCode.OK, res);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("DeleteFavorite")]
        public HttpResponseMessage DeleteFavorite(int id)
        {
            int res = dapperMngr.DeleteFavorite(id);
            return Request.CreateResponse(HttpStatusCode.OK, res);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.ActionName("GetUserFavorites")]
        public List<UserFavoriteVM> GetUserFavorites()
        {
            return dapperMngr.GetFavorites();
        }

    }


}
