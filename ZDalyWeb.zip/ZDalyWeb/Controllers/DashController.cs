﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace ZDalyWeb.Controllers
{
    public class DashController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
