﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Xml;
using System.Xml.Linq;

namespace ZDalyWeb.Controllers
{

    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Index2()
        {
            //if (Session.Count == 0 || Session["UserID"] == null)
            //{
            //    return RedirectPermanent("/account/login");
            //}
            return View();
        }
//        public ActionResult TestService()
//        {
//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetDataflow();
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<XMLService> rep = new List<XMLService>();

//            foreach (XmlNode node in nodes[1])
//            {
//                var no = node.InnerText;
//                rep.Add(new XMLService { Name = no, Id = node.Attributes.Item(0).Value });
//            }
//            ViewBag.Response = rep;
//            //SDMX_Web_Service
//            //ASMXSDMXServiceSoapClient sdmxServiceClient = new ASMXSDMXServiceSoapClient();
//            return View();
//        }

//        public ActionResult GetDataStructure(string id)
//        {
//            string query = string.Format(@"<QueryMessage xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/message""> 
//                        <Query>
//                            <KeyFamilyWhere xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/query"">
//                                <KeyFamily>{0}</KeyFamily>
//                            </KeyFamilyWhere>
//                        </Query>
//                    </QueryMessage>", id);
//            XmlDocument queryMessageDocument = new XmlDocument();
//            queryMessageDocument.LoadXml(query);
//            XmlElement queryMessage = queryMessageDocument.DocumentElement;

//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetDataStructure(queryMessage);
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<Annotations> rep = new List<Annotations>();

//            foreach (XmlNode node in nodes[3].ChildNodes[0].ChildNodes[1])
//            {
//                var title = node.ChildNodes[0].InnerText;
//                var text = node.ChildNodes[1].InnerText;
//                rep.Add(new Annotations { Title = title, Text = text });
//            }
//            ViewBag.Response = rep;
//            ViewBag.ID = id;
//            //SDMX_Web_Service
//            //  return Json(nodes[3].InnerXml, JsonRequestBehavior.AllowGet);
//            return PartialView();
//        }
//        public ActionResult GetCompactData(string id, int startyear = 2010, int endYear = 2015)
//        {
//            string query = string.Format(
// @"<QueryMessage xmlns:xsd=""http://www.w3.org/2001/XMLSchema""
//xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""
//xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/message"">
//  <Query>
//    <DataWhere xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/query"">
//      <And>
//        <DataSet>{2}</DataSet>
//        <Time>
//          <StartTime>{0}</StartTime>
//          <EndTime>{1}</EndTime>
//        </Time>     
//
//      </And>
//    </DataWhere>
//  </Query>
//</QueryMessage>", startyear, endYear, id);

//            XmlDocument queryMessageDocument = new XmlDocument();
//            queryMessageDocument.LoadXml(query);
//            XmlElement queryMessage = queryMessageDocument.DocumentElement;

//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetCompactData(queryMessage);
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<Annotations> rep = new List<Annotations>();


//            List<NewTempClass> list = new List<NewTempClass>();

//            foreach (XmlNode node in nodes[1])
//            {
//                NewTempClass o = new NewTempClass();
//                rep = new List<Annotations>();
//                var a1 = node.Attributes.Item(0).Name + " : " + node.Attributes.Item(0).Value;
//                var a2 = node.Attributes.Item(1).Name + " : " + node.Attributes.Item(1).Value;
//                var a3 = node.Attributes.Item(2).Name + " : " + node.Attributes.Item(2).Value;
//                var a4 = node.Attributes.Item(3).Name + " : " + node.Attributes.Item(3).Value;
//                var a5 = node.Attributes.Item(4).Name + " : " + node.Attributes.Item(4).Value;

//                o.DisplayProperties = a1 + "<br/>" + a2 + "<br/>" + a3 + "<br/>" + a4 + "<br/>" + a5 + "<br/>";

//                foreach (XmlNode item in node)
//                {
//                    var title = item.Attributes.Item(0).Value;
//                    var text = item.Attributes.Item(1).Value;
//                    rep.Add(new Annotations { Title = title, Text = text });
//                }

//                o.rr = rep;
//                list.Add(o);
//            }
//            ViewBag.Response = list;

//            //SDMX_Web_Service
//            //  return Json(nodes[3].InnerXml, JsonRequestBehavior.AllowGet);
//            return PartialView();
//        }

        
//        public ActionResult TestService()
//        {
//              XmlDocument queryMessageDocument = new XmlDocument();
//            queryMessageDocument.Load(Server.MapPath("~/App_Data/Query.xml"));
//            org.un.data.NSIStdV20Service unSrv = new org.un.data.NSIStdV20Service();

//           //var quesryStructure= unSrv.QueryStructure(queryMessageDocument.DocumentElement);

//            var unService = unSrv.GetCompactData(queryMessageDocument.DocumentElement);

//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetDataflow();
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<XMLService> rep = new List<XMLService>();

//            foreach (XmlNode node in nodes[1])
//            {
//                var no = node.InnerText;
//                rep.Add(new XMLService { Name = no, Id = node.Attributes.Item(0).Value });
//            }
//            ViewBag.Response = rep;
//            //SDMX_Web_Service
//            //ASMXSDMXServiceSoapClient sdmxServiceClient = new ASMXSDMXServiceSoapClient();
//            return View();
//        }

//        public ActionResult GetDataStructure(string id)
//        {
//            string query = string.Format(@"<QueryMessage xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/message""> 
//                        <Query>
//                            <KeyFamilyWhere xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/query"">
//                                <KeyFamily>{0}</KeyFamily>
//                            </KeyFamilyWhere>
//                        </Query>
//                    </QueryMessage>", id);
//            XmlDocument queryMessageDocument = new XmlDocument();
//            queryMessageDocument.LoadXml(query);
//            XmlElement queryMessage = queryMessageDocument.DocumentElement;

//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetDataStructure(queryMessage);
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<Annotations> rep = new List<Annotations>();

//            foreach (XmlNode node in nodes[3].ChildNodes[0].ChildNodes[1])
//            {
//                var title = node.ChildNodes[0].InnerText;
//                var text = node.ChildNodes[1].InnerText;
//                rep.Add(new Annotations { Title = title, Text = text });
//            }
//            ViewBag.Response = rep;
//            ViewBag.ID = id;
//            //SDMX_Web_Service
//            //  return Json(nodes[3].InnerXml, JsonRequestBehavior.AllowGet);
//            return PartialView();
//        }
//        public ActionResult GetCompactData(string id, int startyear = 2010, int endYear = 2015)
//        {
//            string query = string.Format(
// @"<QueryMessage xmlns:xsd=""http://www.w3.org/2001/XMLSchema""
//xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""
//xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/message"">
//  <Query>
//    <DataWhere xmlns=""http://www.SDMX.org/resources/SDMXML/schemas/v2_0/query"">
//      <And>
//        <DataSet>{2}</DataSet>
//        <Time>
//          <StartTime>{0}</StartTime>
//          <EndTime>{1}</EndTime>
//        </Time>     
//
//      </And>
//    </DataWhere>
//  </Query>
//</QueryMessage>", startyear, endYear, id);

//            XmlDocument queryMessageDocument = new XmlDocument();
//            queryMessageDocument.LoadXml(query);
//            XmlElement queryMessage = queryMessageDocument.DocumentElement;

//            org.imf.dataservices.ASMXSDMXService srv = new org.imf.dataservices.ASMXSDMXService();
//            XmlElement responseXml = srv.GetCompactData(queryMessage);
//            XmlNodeList nodes = responseXml.ChildNodes;
//            List<Annotations> rep = new List<Annotations>();


//            List<NewTempClass> list = new List<NewTempClass>();

//            foreach (XmlNode node in nodes[1])
//            {
//                NewTempClass o = new NewTempClass();
//                rep = new List<Annotations>();
//                var a1 = node.Attributes.Item(0).Name + " : " + node.Attributes.Item(0).Value;
//                var a2 = node.Attributes.Item(1).Name + " : " + node.Attributes.Item(1).Value;
//                var a3 = node.Attributes.Item(2).Name + " : " + node.Attributes.Item(2).Value;
//                var a4 = node.Attributes.Item(3).Name + " : " + node.Attributes.Item(3).Value;
//                var a5 = node.Attributes.Item(4).Name + " : " + node.Attributes.Item(4).Value;

//                o.DisplayProperties = a1 + "<br/>" + a2 + "<br/>" + a3 + "<br/>" + a4 + "<br/>" + a5 + "<br/>";

//                foreach (XmlNode item in node)
//                {
//                    var title = item.Attributes.Item(0).Value;
//                    var text = item.Attributes.Item(1).Value;
//                    rep.Add(new Annotations { Title = title, Text = text });
//                }

//                o.rr = rep;
//                list.Add(o);
//            }
//            ViewBag.Response = list;

//            //SDMX_Web_Service
//            //  return Json(nodes[3].InnerXml, JsonRequestBehavior.AllowGet);
//            return PartialView();
//        }


    }

    public class XMLService
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }

    public class NewTempClass
    {
        public string DisplayProperties { get; set; }
        public List<Annotations> rr { get; set; }
    }

    public class Annotations
    {
        public string Title;
        public string Text;
    }
}
