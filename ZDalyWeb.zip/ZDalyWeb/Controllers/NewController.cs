﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Xml;
using System.Xml.Linq;
using ZDalyWeb.Models.Dapper;
using ZDalyWeb.ViewModels;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.AspNet.Identity;
using System.Globalization;
using Newtonsoft.Json;
using System.Reflection;
using Newtonsoft.Json.Linq;
using System.Net;
using SpreadsheetLight;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ZDalyWeb.Controllers
{
    
    public class NewController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Search(string q = null)
        {

            ViewBag.sectorId = 0;
            if (q != null)
            {
                ViewBag.sector = q;
                Session["searchFilterData"] = null;
            }

            if (Session["searchFilterData"] != null)
            {
                SearchResult filterData = (SearchResult)Session["searchFilterData"];
                ViewBag.sectorId = filterData.SectorId;
                ViewBag.superRegionId = filterData.SuperRegionId;
                ViewBag.subSectorId = filterData.SubSectorId;

                ViewBag.sector = filterData.Sector;
                ViewBag.subSector = filterData.SubSector;
                ViewBag.superRegion = filterData.SuperRegion;
                ViewBag.searchString = filterData.SearchString;
                ViewBag.attributeIds = filterData.AttrBucket;
                ViewBag.stratumName = filterData.StratumName;
            }

            return View();
        }

        [HttpPost]
        public ActionResult SearchFilter(SearchResult obj)
        {
            Session["searchFilterData"] = obj;

            return Json(new { success = true });
        }

        public ActionResult dashboard()
        {

#if !DEBUG
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
       //     DECLARE @ABIds VARCHAR(MAX)='10,42,62'
       // --	EXEC usp_DashBoard_Chart_Selection_Stratum 1,1,100
       // --EXEC usp_Dashboard_Chart_Show_details 1,1,@ABIds,NULL,100
       //EXEC [usp_DashBoard_Display_Chart] 1,1,@ABIds,NULL,1,3
       //-- EXEC usp_Bulk_Data_Select_Expansion 1,1,@ABIds,NULL,'32'
       //   --  select * from zd.Stratum

       // --sp_helptext [usp_DashBoard_Display_Chart]
#endif
            if (Session["dashboardFilterData"] != null)
            {

                FilterData filterData = (FilterData)Session["dashboardFilterData"];
                string locationIds = "";
                foreach (var item in filterData.selectionsAttrs)
                {

                    if (item.Id == 0 && !string.IsNullOrEmpty(item.AttrBucket))// LoacationIds
                    {
                        locationIds = item.AttrBucket;
                    }
                    else
                    {
                        filterData.selectedStratumIds = filterData.selectedStratumIds + "," + item.selectedStratumIds;
                        filterData.attributeIds = filterData.attributeIds + "," + item.AttrBucket; // Commented for defautlt attributes ids by search
                    }
                }
                ViewBag.sectorId = filterData.sector;
                ViewBag.superRegionId = filterData.superRegion;
                ViewBag.attributeIds = string.Join(",", filterData.attributeIds.Split(',').Distinct());
                ViewBag.selectedStratumIds = filterData.selectedStratumIds != null ? string.Join(",", filterData.selectedStratumIds.Split(',').Distinct()) : null;
                ViewBag.remainingStratumCount = filterData.remainingStratumCount;
                ViewBag.locationIds = locationIds;
                ViewBag.searchResult = filterData.selectionsAttrs;
                ViewBag.selectedFilterLevels = filterData.selectedFilterLevels != null ? filterData.selectedFilterLevels : null;
                ViewBag.Location = filterData.Location != null ? filterData.Location : null;
                ViewBag.FilteredJsonString = filterData.FilteredJsonString;
                ViewBag.sText = filterData.sText;
                ViewBag.FilterLocationString = filterData.FilterLocationString;
                ViewBag.stratumList = filterData.stratumList;

                if(!string.IsNullOrWhiteSpace(filterData.locationLevels) && filterData.locationLevels != "null")
                {
                    dynamic locationObj = System.Web.Helpers.Json.Decode(filterData.locationLevels);
                    string searchLocation = (locationObj != null && locationObj.Length > 0 && locationObj[0].data.Length > 0 ? locationObj[0].data[0] : string.Empty);
                    ViewBag.sLocation = searchLocation;
                }
                else
                {
                    ViewBag.sLocation = "";
                }

                ViewBag.locationLevels = filterData.locationLevels;
                ViewBag.lastLevelArray = filterData.lastLevelArray;
                ViewBag.prevLocSelected = filterData.prevLocSelected;
                ViewBag.reqLocationLevels = filterData.reqLocationLevels;
                if (filterData.searchResult != null)
                {
                    ViewBag.sector = filterData.searchResult.Sector;
                    ViewBag.subSector = filterData.searchResult.SubSector;
                    ViewBag.superRegion = filterData.searchResult.SuperRegion;
                }
                else
                {
                    if (Session["searchFilterData"] != null)
                    {
                        SearchResult filterData1 = (SearchResult)Session["searchFilterData"];
                        ViewBag.sector = filterData1.Sector;
                        ViewBag.subSector = filterData1.SubSector;
                        ViewBag.superRegion = filterData1.SuperRegion;

                    }
                }

                if (ViewBag.subSector == null)
                {
                    ViewBag.subSector = filterData.SubSector;
                }
                if (ViewBag.sector == null)
                {
                    ViewBag.sector = filterData.sectorText;
                }
            }
            else
            {
                ViewBag.sectorId = 1;
                ViewBag.superRegionId = 1;
                ViewBag.attributeIds = " 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397";
                ViewBag.selectedStratumIds = "20,22";
                ViewBag.remainingStratumCount = 0;
                ViewBag.locationIds = ""; // CountryId

                ViewBag.sector = "Agriculture";
                ViewBag.subSector = "Corn";
                ViewBag.superRegion = "United States";
            }
            return View();
        }

        public ActionResult dashboard2()
        {

#if !DEBUG
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
       //     DECLARE @ABIds VARCHAR(MAX)='10,42,62'
       // --	EXEC usp_DashBoard_Chart_Selection_Stratum 1,1,100
       // --EXEC usp_Dashboard_Chart_Show_details 1,1,@ABIds,NULL,100
       //EXEC [usp_DashBoard_Display_Chart] 1,1,@ABIds,NULL,1,3
       //-- EXEC usp_Bulk_Data_Select_Expansion 1,1,@ABIds,NULL,'32'
       //   --  select * from zd.Stratum

       // --sp_helptext [usp_DashBoard_Display_Chart]
#endif
            if (Session["dashboardFilterData"] != null)
            {

                FilterData filterData = (FilterData)Session["dashboardFilterData"];
                string locationIds = "";
                foreach (var item in filterData.selectionsAttrs)
                {

                    if (item.Id == 0 && !string.IsNullOrEmpty(item.AttrBucket))// LoacationIds
                    {
                        locationIds = item.AttrBucket;
                    }
                    else
                    {
                        filterData.selectedStratumIds = filterData.selectedStratumIds + "," + item.selectedStratumIds;
                        filterData.attributeIds = filterData.attributeIds + "," + item.AttrBucket; // Commented for defautlt attributes ids by search
                    }
                }
                ViewBag.sectorId = filterData.sector;
                ViewBag.superRegionId = filterData.superRegion;
                ViewBag.attributeIds = string.Join(",", filterData.attributeIds.Split(',').Distinct());
                ViewBag.selectedStratumIds = filterData.selectedStratumIds != null ? string.Join(",", filterData.selectedStratumIds.Split(',').Distinct()) : null;
                ViewBag.remainingStratumCount = filterData.remainingStratumCount;
                ViewBag.locationIds = locationIds;
                ViewBag.searchResult = filterData.selectionsAttrs;
                ViewBag.selectedFilterLevels = filterData.selectedFilterLevels != null ? filterData.selectedFilterLevels : null;
                ViewBag.Location = filterData.Location != null ? filterData.Location : null;
                ViewBag.FilteredJsonString = filterData.FilteredJsonString;
                ViewBag.sText = filterData.sText;
                ViewBag.FilterLocationString = filterData.FilterLocationString;
                ViewBag.stratumList = filterData.stratumList;

                if (!string.IsNullOrWhiteSpace(filterData.locationLevels) && filterData.locationLevels != "null")
                {
                    dynamic locationObj = System.Web.Helpers.Json.Decode(filterData.locationLevels);
                    string searchLocation = (locationObj != null && locationObj.Length > 0 && locationObj[0].data.Length > 0 ? locationObj[0].data[0] : string.Empty);
                    ViewBag.sLocation = searchLocation;
                }
                else
                {
                    ViewBag.sLocation = "";
                }

                ViewBag.locationLevels = filterData.locationLevels;
                ViewBag.lastLevelArray = filterData.lastLevelArray;
                ViewBag.prevLocSelected = filterData.prevLocSelected;
                ViewBag.reqLocationLevels = filterData.reqLocationLevels;
                if (filterData.searchResult != null)
                {
                    ViewBag.sector = filterData.searchResult.Sector;
                    ViewBag.subSector = filterData.searchResult.SubSector;
                    ViewBag.superRegion = filterData.searchResult.SuperRegion;
                }
                else
                {
                    if (Session["searchFilterData"] != null)
                    {
                        SearchResult filterData1 = (SearchResult)Session["searchFilterData"];
                        ViewBag.sector = filterData1.Sector;
                        ViewBag.subSector = filterData1.SubSector;
                        ViewBag.superRegion = filterData1.SuperRegion;

                    }
                }

                if (ViewBag.subSector == null)
                {
                    ViewBag.subSector = filterData.SubSector;
                }
                if (ViewBag.sector == null)
                {
                    ViewBag.sector = filterData.sectorText;
                }
            }
            else
            {
                ViewBag.sectorId = 1;
                ViewBag.superRegionId = 1;
                ViewBag.attributeIds = " 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397, 4037, 3984, 4072, 1, 623, 643, 697, 19, 37, 605, 4207, 38, 680, 4141, 661, 679, 4173, 39, 60, 73, 92, 4190, 111, 293, 4157, 698, 4191, 295, 4200, 4221, 4272, 4387, 294, 4460, 10340, 4564, 10426, 10435, 10456, 10467, 10686, 10479, 10491, 10593, 3985, 10492, 10538, 10503, 10605, 10537, 10549, 716, 718, 10594, 864, 866, 10698, 10719, 10619, 10768, 6546, 6547, 6564, 6644, 6565, 6572, 6573, 6577, 6590, 6591, 6600, 6675, 6676, 6680, 6684, 6775, 6776, 6785, 6833, 6876, 6866, 1584, 1600, 1647, 1710, 1576, 1718, 1726, 1745, 1746, 1760, 1780, 2014, 2258, 2350, 2367, 2419, 2445, 2486, 2454, 2474, 2463, 2483, 2574, 2730, 2680, 2721, 2757, 2871, 2888, 2910, 2928, 2963, 2999, 3004, 3021, 2905, 3086, 3107, 3108, 3112, 3125, 3141, 3160, 3147, 3166, 3384, 3397";
                ViewBag.selectedStratumIds = "20,22";
                ViewBag.remainingStratumCount = 0;
                ViewBag.locationIds = ""; // CountryId

                ViewBag.sector = "Agriculture";
                ViewBag.subSector = "Corn";
                ViewBag.superRegion = "United States";
            }
            return View();
        }


        [HttpPost]
        public ActionResult dashboardFilter(FilterData obj)
        {
            Session["dashboardFilterData"] = obj;

            return Json(new { success = true });
        }

        public ActionResult Test()
        {
            return View();
        }
        public JsonResult TestResults()
        {

            return Json("[ { sector:'test', superRegion:'test', suggestionString:'test', stratumName:'test' }, { sector:'test', superRegion:'test', suggestionString:'test', stratumName:'test' }, { sector:'test', superRegion:'test', suggestionString:'test', stratumName:'test' }, { sector:'test', superRegion:'test', suggestionString:'test', stratumName:'test' }, { sector:'test', superRegion:'test', suggestionString:'test', stratumName:'test' } ]", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetLatestNews(string searchQuery, string country)
        {
            List<LatestNews> resultList = new List<LatestNews>();

            if (string.IsNullOrWhiteSpace(searchQuery))
                return Json(resultList);

            searchQuery = searchQuery.Replace("+", "").Replace("  "," ");
            searchQuery = searchQuery.Replace("|", "").Trim().TrimEnd(',').Replace(",", " ");
            searchQuery = searchQuery.Replace(" ", "+");

            string countryCode = CountryBO.GetCountrySortCode(country);
            string searchURL = "https://news.google.com/news/feeds?pz=1&cf=all&ned=" + countryCode + "&gl=" + countryCode + "&hl=en&q=" + searchQuery + "&output=rss";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(searchURL);
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream = null;

                if (response.CharacterSet == "")
                    readStream = new StreamReader(receiveStream);
                else
                    readStream = new StreamReader(receiveStream, System.Text.Encoding.GetEncoding(response.CharacterSet));

                string data = readStream.ReadToEnd();

                DataSet ds = new DataSet();
                StringReader reader = new StringReader(data);
                ds.ReadXml(reader);
                DataTable dtGetNews = new DataTable();

                if (ds.Tables.Count > 3)
                {
                    dtGetNews = ds.Tables["item"];

                    foreach (DataRow dtRow in dtGetNews.Rows)
                    {
                        if (resultList.Count > 2)
                            continue;

                        LatestNews DataObj = new LatestNews();
                        DataObj.NewsTitle = dtGetNews.Columns.Contains("title") ? dtRow["title"].ToString() : string.Empty;
                        DataObj.NewsLink = dtGetNews.Columns.Contains("link") ? dtRow["link"].ToString() : string.Empty;
                        DataObj.NewsItemID = dtGetNews.Columns.Contains("item_id") ? dtRow["item_id"].ToString() : string.Empty;
                        DataObj.PubDate = dtGetNews.Columns.Contains("pubDate") ? dtRow["pubDate"].ToString() : string.Empty;
                        DataObj.Description = dtGetNews.Columns.Contains("description") ? dtRow["description"].ToString() : string.Empty;
                        DataObj.Description = DataObj.Description.Replace("size=\"-1\"", "");

                        if (!string.IsNullOrEmpty(DataObj.NewsTitle))
                            resultList.Add(DataObj);
                    }
                }
            }

            return Json(resultList);
        }

        #region Favorites
        public ActionResult Favorites()
        {
            DapperManager dpr = new DapperManager();
            List<UserFavoriteVM> objList = dpr.GetFavorites();
            return View(objList);
        }
        #endregion

        #region BulkData
        public ActionResult BulkData()
        {
            return View();
        }

        private DapperManager dapperMngr = new DapperManager();

        //public List<ChartData> GetChartDataNew(List<ResultVM> objList)
        //{
        //    //objList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ResultVM>>(json);
        //    try
        //    {
        //        List<DetailSeriesCollection> objCollection = new List<DetailSeriesCollection>();

        //        string seriesID = string.Empty;
        //        List<long> stringList = new List<long>();
        //        List<string> details = new List<string>();

        //        foreach (var item in objList)
        //        {
        //            details.Add(item.data[0].details);

        //            //Add Country 
        //            if (item.data[0].seriesId.Country != null && item.data[0].seriesId.Country.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.Country;
        //                foreach (var xTemp in tempList)
        //                {
        //                    stringList.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { DetailID = item.data[0].details, SeriesID = xTemp.seriesId, Country = xTemp.locationName });
        //                }
        //            }

        //            //Add State 
        //            if (item.data[0].seriesId.State != null && item.data[0].seriesId.State.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.State;
        //                foreach (var xTemp in tempList)
        //                {
        //                    stringList.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { DetailID = item.data[0].details, SeriesID = xTemp.seriesId, State = xTemp.locationName });
        //                }
        //            }

        //            //Add County 
        //            if (item.data[0].seriesId.County != null && item.data[0].seriesId.County.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.County;
        //                foreach (var xTemp in tempList)
        //                {
        //                    stringList.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { DetailID = item.data[0].details, SeriesID = xTemp.seriesId, County = xTemp.locationName });
        //                }
        //            }
        //        }

        //        string tableName = objList.FirstOrDefault().dbName;
        //        seriesID = string.Join(",", stringList);

        //        if (string.IsNullOrEmpty(seriesID))
        //        {
        //            return new List<ChartData>();
        //        }

        //        var list = dapperMngr.GetChartDataNew(seriesID, tableName);

        //        list.ForEach(x => x.Detail = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().DetailID);
        //        list.ForEach(x => x.County = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().County);
        //        list.ForEach(x => x.Country = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().Country);
        //        list.ForEach(x => x.State = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().State);
        //        //list = list.GroupBy(x => new { x.ValueDate, x.Detail }).Select(g => g.OrderByDescending(x => x.Value).First()).ToList();
        //        list.ForEach(x => x.Year = x.ValueDate.Year);
        //        list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());

        //        list.OrderByDescending(x => x.ValueDate);

        //        return list;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        [HttpPost]
        public string GetChartDataCsv(string JsonObject, string startDate, string endDate, string jsonObj, int editId = 0)
        {
            try
            {
                dynamic jsonResponse = JsonConvert.DeserializeObject(JsonObject);
                List<long> allSeries = new List<long>();
                List<SeriesRow> seriesRow = new List<SeriesRow>();
                //to store comma seperated
                string seriesID = "";
                string dbName = "";
                int count = jsonResponse.Count;

                for (int i = 0; i < count; i++)
                {

                    var item = jsonResponse[i];
                    var data = item.data;
                    var seriesId = data.seriesId;
                    var state = data.locations.State;
                    var country = data.locations.Country;
                    var county = data.locations.County;
                    JObject stratums = item.stratums;
                    Dictionary<string, string> dicstratums = new Dictionary<string, string>();
                    foreach (var item1 in stratums)
                    {
                        var myItemKey = item1.Key;
                        var myItemValue = item1.Value;
                        dicstratums.Add(myItemKey, myItemValue.ToString());
                    }


                    allSeries.Add((long)seriesId);
                    seriesRow.Add(new SeriesRow { Series = seriesId, Country = country, State = state, County = county, Attributes = dicstratums });
                    dbName = item.dbName;

                }
                seriesID = string.Join(",", allSeries);
                var list = dapperMngr.GetChartDataNew(seriesID, dbName);


                if (!string.IsNullOrEmpty(startDate))
                {
                    if (!string.IsNullOrEmpty(endDate))
                    {
                        DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime enDate = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        list = list.Where(i => i.ValueDate >= stDate && i.ValueDate <= enDate).ToList();
                    }
                    else
                    {
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        list = list.Where(i => i.ValueDate >= stDate).ToList();
                    }
                }

                StringBuilder allVals = new StringBuilder();
                //header
                SeriesRow row = seriesRow.FirstOrDefault();
                allVals.AppendLine("Series,Country,State,County," + string.Join(",", row.Attributes.Keys) + ",Value,ValueDateString");
                foreach (var item in list)
                {
                    List<string> dataVals = new List<string>();
                    var seriesId = item.Series;
                    var rowItem = seriesRow.Where(i => i.Series == seriesId).FirstOrDefault();
                    dataVals.Add(seriesId.ToString());
                    dataVals.Add(rowItem.Country);
                    dataVals.Add(rowItem.State);
                    dataVals.Add(rowItem.County);
                    foreach (var key in rowItem.Attributes.Keys)
                    {
                        dataVals.Add(rowItem.Attributes[key]);
                    }
                    dataVals.Add(item.Value.ToString());
                    dataVals.Add(item.ValueDate.ToString());
                    var stringEsc = "";
                    for (int i = 0; i < dataVals.Count; i++)
                    {
                        if (i == dataVals.Count - 1)
                        {
                            stringEsc += "\"{" + i + "}\"";
                        }
                        else
                        {
                            stringEsc += "\"{" + i + "}\",";
                        }

                    }

                    allVals.AppendLine(string.Format(stringEsc, dataVals.ToArray()));



                }

                string folderPath = System.Web.HttpContext.Current.Server.MapPath("~/DownloadCsv/");
                string filename = "Csv-" + Guid.NewGuid();
                System.IO.File.WriteAllText(Path.Combine(folderPath, filename + ".csv"), allVals.ToString());
                //jsonObj = jsonObj.Replace("[DOWNLOAD_LINK]", filename);
                //if (editId == 0)
                //{
                //    SaveDownload(jsonObj);
                //}
                //else
                //{
                //    EditSaveDownload(jsonObj, editId);
                //}
                return filename;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public FileResult DownloadCsv(string id)
        {
            string folderPath = System.Web.HttpContext.Current.Server.MapPath("~/DownloadCsv/");
            string filePath = Path.Combine(folderPath, id + ".csv");
            byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);
            string fileName = "BulkData.csv";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }



        public JsonResult GetChartDataPreview1(List<ResultVM> objList, string startDate, string endDate)
        {
            //objList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ResultVM>>(json);
            try
            {
                List<DetailSeriesCollection> objCollection = new List<DetailSeriesCollection>();

                string seriesID = string.Empty;
                List<long> stringList = new List<long>();
                List<string> details = new List<string>();

                foreach (var item in objList)
                {
                    details.Add(item.data[0].details);

                    //Add Country 
                    if (item.data[0].seriesId.Country != null && item.data[0].seriesId.Country.Count > 0)
                    {

                        var tempList = item.data[0].seriesId.Country;
                        foreach (var xTemp in tempList)
                        {
                            stringList.Add(xTemp.seriesId);
                            objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, Country = xTemp.locationName });
                        }
                    }

                    //Add State 
                    if (item.data[0].seriesId.State != null && item.data[0].seriesId.State.Count > 0)
                    {

                        var tempList = item.data[0].seriesId.State;
                        foreach (var xTemp in tempList)
                        {
                            stringList.Add(xTemp.seriesId);
                            objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, State = xTemp.locationName });
                        }
                    }

                    //Add County 
                    if (item.data[0].seriesId.County != null && item.data[0].seriesId.County.Count > 0)
                    {

                        var tempList = item.data[0].seriesId.County;
                        foreach (var xTemp in tempList)
                        {
                            stringList.Add(xTemp.seriesId);
                            objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, County = xTemp.locationName });
                        }
                    }
                }

                string tableName = objList.FirstOrDefault().dbName;
                seriesID = string.Join(",", stringList);

                if (string.IsNullOrEmpty(seriesID))
                {
                    return Json(new List<ChartData>(), JsonRequestBehavior.AllowGet);

                }

                var list = dapperMngr.GetChartDataNew(seriesID, tableName);

                list.ForEach(x => { x.Detail = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().DetailID; x.StratumName = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().StratumName; x.Country = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().Country; x.State = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().State; });
                //list = list.GroupBy(x => new { x.ValueDate, x.Detail }).Select(g => g.OrderByDescending(x => x.Value).First()).ToList();
                list.ForEach(x => x.Year = x.ValueDate.Year);
                list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
                if (!string.IsNullOrEmpty(startDate))
                {
                    if (!string.IsNullOrEmpty(endDate))
                    {
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime enDate = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        list = list.Where(i => i.ValueDate >= stDate && i.ValueDate <= enDate).ToList();
                    }
                    else
                    {
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        list = list.Where(i => i.ValueDate >= stDate).ToList();
                    }
                }
                list.OrderByDescending(x => x.ValueDate);
                list = list.Take(200).ToList();
                return Json(list, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public JsonResult GetChartDataPreview(string JsonObject)
        {
            dynamic jsonResponse = JsonConvert.DeserializeObject(JsonObject);
            List<long> allSeries = new List<long>();
            List<SeriesRow> seriesRow = new List<SeriesRow>();
            //to store comma seperated
            string seriesID = "";
            string dbName = "";
            int count = jsonResponse.Count;

            for (int i = 0; i < count; i++)
            {

                var item = jsonResponse[i];
                var data = item.data;
                var seriesId = data.seriesId;
                var state = data.locations.State;
                var country = data.locations.Country;
                var county = data.locations.County;
                JObject stratums = item.stratums;
                Dictionary<string, string> dicstratums = new Dictionary<string, string>();
                foreach (var item1 in stratums)
                {
                    var myItemKey = item1.Key;
                    var myItemValue = item1.Value;
                    dicstratums.Add(myItemKey, myItemValue.ToString());
                }
                allSeries.Add((long)seriesId);
                // var seriesIdCount = seriesId.Count;
                //foreach (var item1 in seriesIds)
                //{
                //    var val = (long)item1;
                //    allSeries.Add(val);
                //    seriesRow.Add(new SeriesRow { Series = val, Country = country, State = state, County = county, Attributes = dicstratums });
                //}

                seriesRow.Add(new SeriesRow { Series = seriesId, Country = country, State = state, County = county, Attributes = dicstratums });
                //foreach (var prop in stratums.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                //{
                //    var name = prop.Name;
                //    var value = prop.GetValue(stratums, null);
                //   // Console.WriteLine("Name: {0}, Value: {1}", prop.Name, prop.GetValue(stratums, null));
                //}
                dbName = item.dbName;

            }
            seriesID = string.Join(",", allSeries);
            var list = dapperMngr.GetChartDataNew(seriesID, dbName);
            List<string> allVals = new List<string>();
            //header
            SeriesRow row = seriesRow.FirstOrDefault();
            allVals.Add("Series[SPLIT]Country[SPLIT]State[SPLIT]County[SPLIT]" + string.Join("[SPLIT]", row.Attributes.Keys) + "[SPLIT]Value[SPLIT]ValueDateString");
            foreach (var item in list)
            {
                var seriesId = item.Series;
                var rowItem = seriesRow.Where(i => i.Series == seriesId).FirstOrDefault();
                var stringData = seriesId + "[SPLIT]" + rowItem.Country + "[SPLIT]" + rowItem.State + "[SPLIT]" + rowItem.County + "[SPLIT]";
                List<string> attributeVals = new List<string>();
                foreach (var key in rowItem.Attributes.Keys)
                {
                    attributeVals.Add(rowItem.Attributes[key]);
                }
                stringData += string.Join("[SPLIT]", attributeVals) + "[SPLIT]";
                stringData += item.Value + "[SPLIT]";
                stringData += item.ValueDate.ToString();
                allVals.Add(stringData);

            }

            return Json(allVals, JsonRequestBehavior.AllowGet);
        }



        //public JsonResult GetChartDataPreview(List<ResultVM> objList, string startDate, string endDate)
        //{
        //    try
        //    {
        //        List<DetailSeriesCollection> objCollection = new List<DetailSeriesCollection>();

        //        string seriesID = string.Empty;
        //        List<long> seriesIds = new List<long>();
        //        List<string> details = new List<string>();
        //        List<string> statumNames = new List<string>();



        //        // Dictionary<string, string> dynamicColumns = new Dictionary<string, string>();

        //        foreach (var item in objList)
        //        {
        //            details.Add(item.data[0].details);
        //            statumNames.Add(item.data[0].stratumName);
        //            //Add Country 
        //            if (item.data[0].seriesId.Country != null && item.data[0].seriesId.Country.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.Country;
        //                foreach (var xTemp in tempList)
        //                {
        //                    seriesIds.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, Country = xTemp.locationName });
        //                }
        //            }

        //            //Add State 
        //            if (item.data[0].seriesId.State != null && item.data[0].seriesId.State.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.State;
        //                foreach (var xTemp in tempList)
        //                {
        //                    seriesIds.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, State = xTemp.locationName });
        //                }
        //            }

        //            //Add County 
        //            if (item.data[0].seriesId.County != null && item.data[0].seriesId.County.Count > 0)
        //            {

        //                var tempList = item.data[0].seriesId.County;
        //                foreach (var xTemp in tempList)
        //                {
        //                    seriesIds.Add(xTemp.seriesId);
        //                    objCollection.Add(new DetailSeriesCollection { StratumName = item.data[0].stratumName, DetailID = item.data[0].details, SeriesID = xTemp.seriesId, County = xTemp.locationName });
        //                }
        //            }
        //        }


        //        List<string> allColumns = new List<string>();

        //        var uniqueSeriesId = seriesIds.Distinct();

        //        foreach (var seriesId in uniqueSeriesId)
        //        {
        //            foreach (var stratumName in statumNames)
        //            {

        //            }
        //        }


        //        //for (int i = 0; i < length; i++)
        //        //{

        //        //}


        //        //string tableName = objList.FirstOrDefault().dbName;
        //        //seriesID = string.Join(",", seriesIds);

        //        //if (string.IsNullOrEmpty(seriesID))
        //        //{
        //        //    return Json(new List<ChartData>(), JsonRequestBehavior.AllowGet);

        //        //}

        //        //var list = dapperMngr.GetChartDataNew(seriesID, tableName);

        //        //list.ForEach(x => { x.Detail = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().DetailID; x.StratumName = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().StratumName; x.Country = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().Country; x.State = objCollection.Where(y => y.SeriesID == x.Series).FirstOrDefault().State; });
        //        ////list = list.GroupBy(x => new { x.ValueDate, x.Detail }).Select(g => g.OrderByDescending(x => x.Value).First()).ToList();
        //        //list.ForEach(x => x.Year = x.ValueDate.Year);
        //        //list.ForEach(x => x.ValueDateString = x.ValueDate.ToShortDateString());
        //        //if (!string.IsNullOrEmpty(startDate))
        //        //{
        //        //    if (!string.IsNullOrEmpty(endDate))
        //        //    {
        //        //        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //        //        DateTime enDate = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        //        //        list = list.Where(i => i.ValueDate >= stDate && i.ValueDate <= enDate).ToList();
        //        //    }
        //        //    else
        //        //    {
        //        //        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

        //        //        list = list.Where(i => i.ValueDate >= stDate).ToList();
        //        //    }
        //        //}
        //        //list.OrderByDescending(x => x.ValueDate);
        //        //list = list.Take(200).ToList();
        //        return Json("", JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }


        //}






        public int GetBulkDataCount(string JsonObject, string startDate, string endDate)
        {
            //objList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ResultVM>>(json);
            try
            {

                dynamic jsonResponse = JsonConvert.DeserializeObject(JsonObject);
                List<long> allSeries = new List<long>();
                List<SeriesRow> seriesRow = new List<SeriesRow>();
                //to store comma seperated
                string seriesID = "";
                string dbName = "";
                int count = jsonResponse.Count;
                if (count == 0)
                {
                    return 0;
                }
                for (int i = 0; i < count; i++)
                {

                    var item = jsonResponse[i];
                    var data = item.data;
                    var seriesId = data.seriesId;
                    var state = data.locations.State;
                    var country = data.locations.Country;
                    var county = data.locations.County;
                    JObject stratums = item.stratums;
                    Dictionary<string, string> dicstratums = new Dictionary<string, string>();
                    foreach (var item1 in stratums)
                    {
                        var myItemKey = item1.Key;
                        var myItemValue = item1.Value;
                        dicstratums.Add(myItemKey, myItemValue.ToString());
                    }

                    // var seriesIdCount = seriesId.Count;
                    allSeries.Add((long)seriesId);
                    seriesRow.Add(new SeriesRow { Series = seriesId, Country = country, State = state, County = county, Attributes = dicstratums });


                    //foreach (var prop in stratums.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                    //{
                    //    var name = prop.Name;
                    //    var value = prop.GetValue(stratums, null);
                    //   // Console.WriteLine("Name: {0}, Value: {1}", prop.Name, prop.GetValue(stratums, null));
                    //}
                    dbName = item.dbName;

                }
                seriesID = string.Join(",", allSeries);
                var list = dapperMngr.GetChartDataNew(seriesID, dbName);

                if (!string.IsNullOrEmpty(startDate))
                {
                    if (!string.IsNullOrEmpty(endDate))
                    {
                        DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime enDate = DateTime.ParseExact(endDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        list = list.Where(i => i.ValueDate >= stDate && i.ValueDate <= enDate).ToList();
                    }
                    else
                    {
                        DateTime stDate = DateTime.ParseExact(startDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        list = list.Where(i => i.ValueDate >= stDate).ToList();
                    }
                }

                //List<string> allVals = new List<string>();
                ////header
                //SeriesRow row = seriesRow.FirstOrDefault();
                //allVals.Add("Series[SPLIT]Country[SPLIT]State[SPLIT]County[SPLIT]" + string.Join("[SPLIT]", row.Attributes.Keys) + "[SPLIT]Value[SPLIT]ValueDateString");
                //foreach (var item in list)
                //{
                //    var seriesId = item.Series;
                //    var rowItem = seriesRow.Where(i => i.Series == seriesId).FirstOrDefault();
                //    var stringData = seriesId + "[SPLIT]" + rowItem.Country + "[SPLIT]" + rowItem.State + "[SPLIT]" + rowItem.County + "[SPLIT]";
                //    List<string> attributeVals = new List<string>();
                //    foreach (var key in rowItem.Attributes.Keys)
                //    {
                //        attributeVals.Add(rowItem.Attributes[key]);
                //    }
                //    stringData += string.Join("[SPLIT]", attributeVals);
                //    stringData += item.Value + "[SPLIT]";
                //    stringData += item.ValueDate.ToString();
                //    allVals.Add(stringData);

                //}


                return list.Count();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public string GetSavedData(int id)
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["zdalyTesting"].ConnectionString;
            using (IDbConnection cn = new SqlConnection(connectionStr))
            {
                string query = "select  state from SavedDownloads where id=@id";
                string data = cn.Query<string>(query, new { id = id }).FirstOrDefault();
                return data;
            }

        }

        public bool SaveDownload(string savedJson)
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString;
            using (IDbConnection cn = new SqlConnection(connectionStr))
            {
                string query = "insert into SavedDownloads (userId,State) values (@userId,@state)";
                int i = cn.Execute(query, new { userId = HttpContext.User.Identity.GetUserId(), state = savedJson });
                return i > 0 ? true : false;
            }

        }

        public bool EditSaveDownload(string savedJson, int id)
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString;
            using (IDbConnection cn = new SqlConnection(connectionStr))
            {
                string query = "update SavedDownloads set state=@savedjson where id=@id";
                int i = cn.Execute(query, new { savedjson = savedJson, id = id });
                return i > 0 ? true : false;
            }

        }
        //SavedDownloads

        public string DownloadRawDataCSV(string jsonData, string seriesId, string dbName)
        {

            dynamic stratums = JsonConvert.DeserializeObject(jsonData);
            Dictionary<string, string> dicstratums = new Dictionary<string, string>();
            List<long> allSeries = new List<long>();
            List<Dictionary<string, string>> dictValues = new List<Dictionary<string, string>>();

            List<string> headers = new List<string>();

            foreach (var item in stratums.First)
            {
                if (item.Name != "dbName")
                {
                    //var name = item.Name.First().ToString().ToUpper() + item.Name.Substring(1);
                    var name = item.Name;
                    headers.Add(name);
                }
            }

            foreach (var item in stratums)
            {
                dicstratums = new Dictionary<string, string>();
                foreach (var subItem in item)
                {
                    dicstratums.Add(subItem.Name, subItem.Value.ToString());

                    if (subItem.Name == "seriesId")
                    {
                        allSeries.Add((long)subItem.Value);
                    }
                }
                dictValues.Add(dicstratums);
            }


            var seriesID = string.Join(",", allSeries);
            var list = dapperMngr.GetChartDataNew(seriesID, dbName);


            headers = headers.OrderBy(x => x).ToList();

            StringBuilder allVals = new StringBuilder();
            allVals.AppendLine(string.Join(",", headers) + ",Value,ValueDateString");
            foreach (var item in list)
            {
                List<string> cVal = new List<string>();
                var currentObj = dictValues.Where(x => x["seriesId"] == item.Series.ToString()).ToList()[0];

                foreach (var h in headers)
                {
                    cVal.Add(currentObj[h]);
                }

                cVal.Add(item.Value.ToString());
                cVal.Add(item.ValueDate.ToShortDateString());


                var stringEsc = "";
                for (int i = 0; i < cVal.Count; i++)
                {
                    if (i == cVal.Count - 1)
                    {
                        stringEsc += "\"{" + i + "}\"";
                    }
                    else
                    {
                        stringEsc += "\"{" + i + "}\",";
                    }

                }

                allVals.AppendLine(string.Format(stringEsc, cVal.ToArray()));

                //allVals.AppendLine(string.Join(",", cVal));
            }

            string folderPath = System.Web.HttpContext.Current.Server.MapPath("~/DownloadCsv/");
            string filename = "Csv-" + Guid.NewGuid();
            System.IO.File.WriteAllText(Path.Combine(folderPath, filename + ".csv"), allVals.ToString());

            return filename;
        }

        public string DownloadRawDataExcel(string jsonData, string seriesId, string dbName)
        {
            dynamic stratums = JsonConvert.DeserializeObject(jsonData);
            Dictionary<string, string> dicstratums = new Dictionary<string, string>();
            List<long> allSeries = new List<long>();
            List<Dictionary<string, string>> dictValues = new List<Dictionary<string, string>>();
            List<string> headers = new List<string>();

            #region LogicToGetHeaderAndData
            foreach (var item in stratums.First)
            {
                if (item.Name != "dbName")
                {
                    //var name = item.Name.First().ToString().ToUpper() + item.Name.Substring(1);
                    var name = item.Name;
                    headers.Add(name);
                }
            }

            foreach (var item in stratums)
            {
                dicstratums = new Dictionary<string, string>();
                foreach (var subItem in item)
                {
                    dicstratums.Add(subItem.Name, subItem.Value.ToString());

                    if (subItem.Name == "seriesId")
                    {
                        allSeries.Add((long)subItem.Value);
                    }
                }
                dictValues.Add(dicstratums);
            }


            var seriesID = string.Join(",", allSeries);
            var list = dapperMngr.GetChartDataNew(seriesID, dbName);


            headers = headers.OrderBy(x => x).ToList();
            #endregion

            #region Excel Code
            //Excel Code
            SLDocument sl = new SLDocument();
            SLStyle style = sl.CreateStyle();

            System.Drawing.Color cellBckColor = System.Drawing.Color.FromArgb(232, 237, 253);

            //STYLE
            style.Font.Bold = true;
            style.Font.FontSize = 12;
            style.Fill.SetPattern(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, cellBckColor, SLThemeColorIndexValues.Accent1Color);

            for (int i = 0; i < headers.Count; i++)
            {
                sl.SetCellValue(1, i + 1, headers[i]);
                int len = headers[i].Length;
                sl.SetColumnWidth(i + 1, len <= 10 ? 10 : len * 1.1);
            }

            sl.SetCellValue(1, headers.Count + 1, "Value");
            sl.SetCellValue(1, headers.Count + 2, "Value Date");
            sl.SetColumnWidth(headers.Count + 1, 12);
            sl.SetColumnWidth(headers.Count + 2, 12);
            sl.SetCellStyle(1, 1, 1, headers.Count + 2, style);

            int a = 2;
            foreach (var item in list)
            {
                List<string> cVal = new List<string>();
                var currentObj = dictValues.Where(x => x["seriesId"] == item.Series.ToString()).ToList()[0];

                foreach (var h in headers)
                {
                    cVal.Add(currentObj[h]);
                }
                cVal.Add(item.Value.ToString());
                cVal.Add(item.ValueDate.ToShortDateString());

                for (int i = 0; i < cVal.Count; i++)
                {
                    sl.SetCellValue(a, i + 1, cVal[i]);
                }

                a++;
            }

            string folderPath = System.Web.HttpContext.Current.Server.MapPath("~/DownloadCsv/");
            string filename = "Excel-" + Guid.NewGuid() + ".xlsx";

            sl.SaveAs(Path.Combine(folderPath, filename));


            #endregion

            return filename;
        }

        public string DownloadRawDataPDF(string jsonData, string seriesId, string dbName)
        {
            dynamic stratums = JsonConvert.DeserializeObject(jsonData);
            Dictionary<string, string> dicstratums = new Dictionary<string, string>();
            List<long> allSeries = new List<long>();
            List<Dictionary<string, string>> dictValues = new List<Dictionary<string, string>>();
            List<string> headers = new List<string>();

            #region LogicToGetHeaderAndData
            foreach (var item in stratums.First)
            {
                if (item.Name != "dbName")
                {
                    //var name = item.Name.First().ToString().ToUpper() + item.Name.Substring(1);
                    var name = item.Name;
                    headers.Add(name);
                }
            }

            foreach (var item in stratums)
            {
                dicstratums = new Dictionary<string, string>();
                foreach (var subItem in item)
                {
                    dicstratums.Add(subItem.Name, subItem.Value.ToString());

                    if (subItem.Name == "seriesId")
                    {
                        allSeries.Add((long)subItem.Value);
                    }
                }
                dictValues.Add(dicstratums);
            }


            var seriesID = string.Join(",", allSeries);
            var list = dapperMngr.GetChartDataNew(seriesID, dbName);


            headers = headers.OrderBy(x => x).ToList();
            #endregion

            #region PDFCode

            #endregion

            #region Excel Code
            //Excel Code
            SLDocument sl = new SLDocument();
            SLStyle style = sl.CreateStyle();

            System.Drawing.Color cellBckColor = System.Drawing.Color.FromArgb(232, 237, 253);

            //STYLE
            style.Font.Bold = true;
            style.Font.FontSize = 12;
            style.Fill.SetPattern(DocumentFormat.OpenXml.Spreadsheet.PatternValues.Solid, cellBckColor, SLThemeColorIndexValues.Accent1Color);

            for (int i = 0; i < headers.Count; i++)
            {
                sl.SetCellValue(1, i + 1, headers[i]);
                int len = headers[i].Length;
                sl.SetColumnWidth(i + 1, len <= 10 ? 10 : len * 1.1);
            }

            sl.SetCellValue(1, headers.Count + 1, "Value");
            sl.SetCellValue(1, headers.Count + 2, "Value Date");
            sl.SetColumnWidth(headers.Count + 1, 12);
            sl.SetColumnWidth(headers.Count + 2, 12);
            sl.SetCellStyle(1, 1, 1, headers.Count + 2, style);

            int a = 2;
            foreach (var item in list)
            {
                List<string> cVal = new List<string>();
                var currentObj = dictValues.Where(x => x["seriesId"] == item.Series.ToString()).ToList()[0];

                foreach (var h in headers)
                {
                    cVal.Add(currentObj[h]);
                }
                cVal.Add(item.Value.ToString());
                cVal.Add(item.ValueDate.ToShortDateString());

                for (int i = 0; i < cVal.Count; i++)
                {
                    sl.SetCellValue(a, i + 1, cVal[i]);
                }

                a++;
            }

            string folderPath = System.Web.HttpContext.Current.Server.MapPath("~/DownloadCsv/");
            string filename = "Excel-" + Guid.NewGuid() + ".xlsx";

            sl.SaveAs(Path.Combine(folderPath, filename));


            #endregion

            return filename;
        }

        public ActionResult NewAlgorithm()
        {
            return View();
        }
        public ActionResult NewAlgorithm2()
        {
            return View();
        }
        #endregion
    }

    public class LatestNews
    {
        public string NewsTitle { get; set; }
        public string NewsLink { get; set; }
        public string NewsItemID { get; set; }
        public string PubDate { get; set; }
        public string Description { get; set; }
    }

    public static class CountryBO
    {
        public static Dictionary<string, string> allCountries = new Dictionary<string, string>();
        static CountryBO()
        {
            string[] Names = new string[] {
                "Afghanistan",
                "Albania",
                "Algeria",
                "American Samoa",
                "Andorra",
                "Angola",
                "Anguilla",
                "Antarctica",
                "Antigua and Barbuda",
                "Argentina",
                "Armenia",
                "Aruba",
                "Australia",
                "Austria",
                "Azerbaijan",
                "Bahamas",
                "Bahrain",
                "Bangladesh",
                "Barbados",
                "Belarus",
                "Belgium",
                "Belize",
                "Benin",
                "Bermuda",
                "Bhutan",
                "Bolivia",
                "Bosnia and Herzegovina",
                "Botswana",
                "Bouvet Island",
                "Brazil",
                "British Indian Ocean Territory",
                "Brunei Darussalam",
                "Bulgaria",
                "Burkina Faso",
                "Burundi",
                "Cambodia",
                "Cameroon",
                "Canada",
                "Cape Verde",
                "Cayman Islands",
                "Central African Republic",
                "Chad",
                "Chile",
                "China",
                "Christmas Island",
                "Cocos (Keeling) Islands",
                "Colombia",
                "Comoros",
                "Congo",
                "Congo, the Democratic Republic of the",
                "Cook Islands",
                "Costa Rica",
                "Cote D'Ivoire",
                "Croatia",
                "Cuba",
                "Cyprus",
                "Czech Republic",
                "Denmark",
                "Djibouti",
                "Dominica",
                "Dominican Republic",
                "Ecuador",
                "Egypt",
                "El Salvador",
                "Equatorial Guinea",
                "Eritrea",
                "Estonia",
                "Ethiopia",
                "Falkland Islands (Malvinas)",
                "Faroe Islands",
                "Fiji",
                "Finland",
                "France",
                "French Guiana",
                "French Polynesia",
                "French Southern Territories",
                "Gabon",
                "Gambia",
                "Georgia",
                "Germany",
                "Ghana",
                "Gibraltar",
                "Greece",
                "Greenland",
                "Grenada",
                "Guadeloupe",
                "Guam",
                "Guatemala",
                "Guinea",
                "Guinea-Bissau",
                "Guyana",
                "Haiti",
                "Heard Island and Mcdonald Islands",
                "Holy See (Vatican City State)",
                "Honduras",
                "Hong Kong",
                "Hungary",
                "Iceland",
                "India",
                "Indonesia",
                "Iran, Islamic Republic of",
                "Iraq",
                "Ireland",
                "Israel",
                "Italy",
                "Jamaica",
                "Japan",
                "Jordan",
                "Kazakhstan",
                "Kenya",
                "Kiribati",
                "Korea, Democratic People's Republic of",
                "Korea, Republic of",
                "Kuwait",
                "Kyrgyzstan",
                "Lao People's Democratic Republic",
                "Latvia",
                "Lebanon",
                "Lesotho",
                "Liberia",
                "Libyan Arab Jamahiriya",
                "Liechtenstein",
                "Lithuania",
                "Luxembourg",
                "Macao",
                "Macedonia, the Former Yugoslav Republic of",
                "Madagascar",
                "Malawi",
                "Malaysia",
                "Maldives",
                "Mali",
                "Malta",
                "Marshall Islands",
                "Martinique",
                "Mauritania",
                "Mauritius",
                "Mayotte",
                "Mexico",
                "Micronesia, Federated States of",
                "Moldova, Republic of",
                "Monaco",
                "Mongolia",
                "Montserrat",
                "Morocco",
                "Mozambique",
                "Myanmar",
                "Namibia",
                "Nauru",
                "Nepal",
                "Netherlands",
                "Netherlands Antilles",
                "New Caledonia",
                "New Zealand",
                "Nicaragua",
                "Niger",
                "Nigeria",
                "Niue",
                "Norfolk Island",
                "Northern Mariana Islands",
                "Norway",
                "Oman",
                "Pakistan",
                "Palau",
                "Palestinian Territory, Occupied",
                "Panama",
                "Papua New Guinea",
                "Paraguay",
                "Peru",
                "Philippines",
                "Pitcairn",
                "Poland",
                "Portugal",
                "Puerto Rico",
                "Qatar",
                "Reunion",
                "Romania",
                "Russian Federation",
                "Rwanda",
                "Saint Helena",
                "Saint Kitts and Nevis",
                "Saint Lucia",
                "Saint Pierre and Miquelon",
                "Saint Vincent and the Grenadines",
                "Samoa",
                "San Marino",
                "Sao Tome and Principe",
                "Saudi Arabia",
                "Senegal",
                "Serbia and Montenegro",
                "Seychelles",
                "Sierra Leone",
                "Singapore",
                "Slovakia",
                "Slovenia",
                "Solomon Islands",
                "Somalia",
                "South Africa",
                "South Georgia and the South Sandwich Islands",
                "Spain",
                "Sri Lanka",
                "Sudan",
                "Suriname",
                "Svalbard and Jan Mayen",
                "Swaziland",
                "Sweden",
                "Switzerland",
                "Syrian Arab Republic",
                "Taiwan, Province of China",
                "Tajikistan",
                "Tanzania, United Republic of",
                "Thailand",
                "Timor-Leste",
                "Togo",
                "Tokelau",
                "Tonga",
                "Trinidad and Tobago",
                "Tunisia",
                "Turkey",
                "Turkmenistan",
                "Turks and Caicos Islands",
                "Tuvalu",
                "Uganda",
                "Ukraine",
                "United Arab Emirates",
                "United Kingdom",
                "United States",
                "United States Minor Outlying Islands",
                "Uruguay",
                "Uzbekistan",
                "Vanuatu",
                "Venezuela",
                "Viet Nam",
                "Virgin Islands, British",
                "Virgin Islands, US",
                "Wallis and Futuna",
                "Western Sahara",
                "Yemen",
                "Zambia",
                "Zimbabwe",
                };

            string[] Abbreviations = new string[] {
                "AF",
                "AL",
                "DZ",
                "AS",
                "AD",
                "AO",
                "AI",
                "AQ",
                "AG",
                "AR",
                "AM",
                "AW",
                "AU",
                "AT",
                "AZ",
                "BS",
                "BH",
                "BD",
                "BB",
                "BY",
                "BE",
                "BZ",
                "BJ",
                "BM",
                "BT",
                "BO",
                "BA",
                "BW",
                "BV",
                "BR",
                "IO",
                "BN",
                "BG",
                "BF",
                "BI",
                "KH",
                "CM",
                "CA",
                "CV",
                "KY",
                "CF",
                "TD",
                "CL",
                "CN",
                "CX",
                "CC",
                "CO",
                "KM",
                "CG",
                "CD",
                "CK",
                "CR",
                "CI",
                "HR",
                "CU",
                "CY",
                "CZ",
                "DK",
                "DJ",
                "DM",
                "DO",
                "EC",
                "EG",
                "SV",
                "GQ",
                "ER",
                "EE",
                "ET",
                "FK",
                "FO",
                "FJ",
                "FI",
                "FR",
                "GF",
                "PF",
                "TF",
                "GA",
                "GM",
                "GE",
                "DE",
                "GH",
                "GI",
                "GR",
                "GL",
                "GD",
                "GP",
                "GU",
                "GT",
                "GN",
                "GW",
                "GY",
                "HT",
                "HM",
                "VA",
                "HN",
                "HK",
                "HU",
                "IS",
                "IN",
                "ID",
                "IR",
                "IQ",
                "IE",
                "IL",
                "IT",
                "JM",
                "JP",
                "JO",
                "KZ",
                "KE",
                "KI",
                "KP",
                "KR",
                "KW",
                "KG",
                "LA",
                "LV",
                "LB",
                "LS",
                "LR",
                "LY",
                "LI",
                "LT",
                "LU",
                "MO",
                "MK",
                "MG",
                "MW",
                "MY",
                "MV",
                "ML",
                "MT",
                "MH",
                "MQ",
                "MR",
                "MU",
                "YT",
                "MX",
                "FM",
                "MD",
                "MC",
                "MN",
                "MS",
                "MA",
                "MZ",
                "MM",
                "NA",
                "NR",
                "NP",
                "NL",
                "AN",
                "NC",
                "NZ",
                "NI",
                "NE",
                "NG",
                "NU",
                "NF",
                "MP",
                "NO",
                "OM",
                "PK",
                "PW",
                "PS",
                "PA",
                "PG",
                "PY",
                "PE",
                "PH",
                "PN",
                "PL",
                "PT",
                "PR",
                "QA",
                "RE",
                "RO",
                "RU",
                "RW",
                "SH",
                "KN",
                "LC",
                "PM",
                "VC",
                "WS",
                "SM",
                "ST",
                "SA",
                "SN",
                "CS",
                "SC",
                "SL",
                "SG",
                "SK",
                "SI",
                "SB",
                "SO",
                "ZA",
                "GS",
                "ES",
                "LK",
                "SD",
                "SR",
                "SJ",
                "SZ",
                "SE",
                "CH",
                "SY",
                "TW",
                "TJ",
                "TZ",
                "TH",
                "TL",
                "TG",
                "TK",
                "TO",
                "TT",
                "TN",
                "TR",
                "TM",
                "TC",
                "TV",
                "UG",
                "UA",
                "AE",
                "GB",
                "US",
                "UM",
                "UY",
                "UZ",
                "VU",
                "VE",
                "VN",
                "VG",
                "VI",
                "WF",
                "EH",
                "YE",
                "ZM",
                "ZW"
            };

            if(allCountries.Count() ==0)
            {
                for (int i = 0; i < Names.Length; i++)
                {
                    allCountries.Add(Names[i].Replace(" ","").ToLower(), Abbreviations[i]);
                }
            }
        }

        public static string GetCountrySortCode(string countryName)
        {
            // default to united states
            return allCountries.ContainsKey(countryName.Replace(" ", "").ToLower().Trim()) ? allCountries[countryName.Replace(" ", "").ToLower().Trim()] : "us";
        }
    }
}