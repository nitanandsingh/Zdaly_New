﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ZDalyBAL;
using ZDalyModels;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;
using System.Net;
using WebMatrix.WebData;

namespace ZDalyWeb.Controllers
{
    public class SignUpController : Controller
    {

       
        SqlConnection cnn;
        SqlCommand cmd;
        string sql = null;
        /// <summary>
        /// Use to Save New Registration
        /// </summary>
        /// <param name="objsignupmodel">Sign Up Model </param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SignUpNewUser(SignUpModel objsignupmodel)
        {


            if (ModelState.IsValid)
            {
            sql = "select * from users_reg_info where email='" + objsignupmodel.EmailAddress + "'";
            cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                cmd = new SqlCommand(sql, cnn);
            cnn.Open();
            var firstColumn = cmd.ExecuteScalar();
            Int32 count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count > 0)
                {
                    TempData["MessageAlready"] = objsignupmodel.EmailAddress;
                    return RedirectToAction("SignUp", "Account");

                }
                else
                {
                    cmd = new SqlCommand("usp_User_Registration", cnn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserName", objsignupmodel.FirstName);
                    cmd.Parameters.AddWithValue("@Email", objsignupmodel.EmailAddress);
                    cmd.Parameters.AddWithValue("@Password", objsignupmodel.Password);
                    cmd.Parameters.AddWithValue("@Company", objsignupmodel.CompanyUniversity);
                    cmd.Parameters.AddWithValue("@Phone", objsignupmodel.Phone);
                    cmd.Parameters.AddWithValue("@IsActive", false);
                    cmd.Parameters.AddWithValue("@IsLocked", false);
                    cmd.Parameters.AddWithValue("@Attempts", 0);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    cnn.Close();

                    Session["UserName"] = objsignupmodel.FirstName;
                    //   return RedirectToAction("ConfirmAccount", "SignUp");

                    try
                    {
                        sql = "select GUID from users_reg_info where email='" + objsignupmodel.EmailAddress + "'";
                        cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                        cmd = new SqlCommand(sql, cnn);
                        cnn.Open();

                        var guidCol = cmd.ExecuteScalar();

                        MailMessage mailMsg = new MailMessage("zdalycorp@gmail.com", objsignupmodel.EmailAddress);
                        mailMsg.Subject = "Zdaly email confirmation";


                        string body1 = "<img src=http://74.63.228.198:88/Images/ZdalyLogoFinal-03.png /><br/> Hi " + objsignupmodel.FirstName + ",<br/>" +
                            "Please confirm your email address by clicking on the link below. <br/><br/> " +
                            "<a target='_blank' style='background-color: #10a9e5; border-radius: 3px;color: #fff;display: inline-block;  font-size: 16px; padding: 12px 20px; text-align: center;text-decoration: none;width: auto;font-weight:bold;' href=http://74.63.228.198:88/Signup/SignUpConfirmation/?key=" + guidCol + ">Verify your email address</a></div> <br/>" +
                            "<p>Regards</p><p>Zdaly Team</p>";

                        mailMsg.Body = body1;
                        mailMsg.IsBodyHtml = true;
                        SmtpClient smtpClient = new SmtpClient();
                        smtpClient.Host = "smtp.gmail.com";
                        smtpClient.EnableSsl = true;
                        NetworkCredential NetworkCred = new NetworkCredential();

                        NetworkCred.UserName = "zdalycorp@gmail.com";
                        NetworkCred.Password = "MaYHcorporation082015";
                        smtpClient.UseDefaultCredentials = true;
                        smtpClient.Credentials = NetworkCred;
                        smtpClient.Port = 587;
                        smtpClient.Send(mailMsg);

                    }
                    catch
                    {
                        return View();
                    }



                    return RedirectToAction("ConfirmAccount", "SignUp");
                }
            }
            else
            {
                TempData["Message"] = "Please fill fields with valid inputs.";
                return RedirectToAction("SignUp", "Account");
            }
        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult ConfirmAccount()
        {
            return View();

            //   return RedirectToAction("ConfirmAccount", "SignUp", new { target = "_blank" });


        }


        [HttpGet]
        [AllowAnonymous]
        public ActionResult SignUpConfirmation()
        {
            string link = Request["key"];

            if (link != null)
            {
                sql = "select * from users_reg_info where GUID='" + link.ToUpper() + "'";
                cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                cmd = new SqlCommand(sql, cnn);
                cnn.Open();

                Int32 count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {
                    sql = "Update users_reg_info SET IsActive='true'  where GUID='" + link.ToUpper() + "'";
                    cnn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
                    cmd = new SqlCommand(sql, cnn);
                    cnn.Open();
                    cmd.ExecuteScalar();
                    TempData["Message"] = "Your Account is verified. Thank you for confirming your account.";
                    return RedirectToAction("AccountVerified", "SignUp");
                }
                else
                {
                    TempData["Message"] = "Error Occured";
                    return RedirectToAction("SignUpConfirmation", "SignUp");
                }

            }
            else
            {
                return RedirectToAction("SignUp", "Account");
            }

        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult AccountVerified()
        {
            return View();
        }




    }
}
