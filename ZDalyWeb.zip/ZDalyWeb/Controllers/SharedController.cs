﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ZDalyWeb.Controllers
{
    public class SharedController : Controller
    {
        //
        // GET: /Share/
        public ActionResult Index()
        {
            if (Session.Count == 0 || Session["UserID"] == null)
            {
                return RedirectPermanent("/account/login");
            }
            return View();
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult LoginPopup()
        {
            return View();
        }

        public ActionResult PasswordExpaire()
        {
            return View();
        }
	}
}