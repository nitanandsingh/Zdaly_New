﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using ZadlyCommon.Partial;
using ZDalyBAL;
using ZDalyCommon.Partial;
using ZDalyModels;
using ZDalyWeb.Models;

namespace ZDalyWeb.Controllers
{
    public class MapController : ApiController
    {
        #region GetMapNames
        /// <summary>
        /// function used to get map names
        /// </summary>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        [System.Web.Http.ActionName("GetMaps")]
        public List<usp_select_Maps_Result> GetMaps(int? CommodityID)
        {
            DataCostBl bl = new DataCostBl();
            return bl.GetMaps(CommodityID);
        }
        #endregion

        [System.Web.Http.HttpPost]
        public string Post([FromBody] string mapid)
        {
            return GetMapData(mapid);
        }

        //[System.Web.Http.HttpGet]
        //public string Get(string mapid)
        //{
        //    return GetMapData("802");
        //}

        #region GetMapData
        public string GetMapData(string mapid)
        {
            DataTable dt = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString))
            using (var cmd = new SqlCommand("usp_Select_MapData", con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MapID", mapid);
                da.Fill(dt);
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> row;
                foreach (DataRow dr in dt.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }

                return serializer.Serialize(rows);
            }
        }

        #endregion

        //public HttpResponseMessage GetMapData1(string mapid)
        //{
        //    string yourJson = GetMapData(mapid);
        //    var response = Request.CreateResponse(HttpStatusCode.OK);
        //    response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
        //    return response;
        //}

        //public string ConvertDataTabletoString()
        //{
        //    DataTable dt = new DataTable();
        //    using (SqlConnection con = new SqlConnection("Data Source=SureshDasari;Initial Catalog=master;Integrated Security=true"))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("select title=City,lat=latitude,lng=longitude,description from LocationDetails", con))
        //        {
        //            con.Open();
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(dt);
        //            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        //            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        //            Dictionary<string, object> row;
        //            foreach (DataRow dr in dt.Rows)
        //            {
        //                row = new Dictionary<string, object>();
        //                foreach (DataColumn col in dt.Columns)
        //                {
        //                    row.Add(col.ColumnName, dr[col]);
        //                }
        //                rows.Add(row);
        //            }
        //            return serializer.Serialize(rows);
        //        }
        //    }
        //}
    }
}
