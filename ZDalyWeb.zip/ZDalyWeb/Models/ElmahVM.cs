using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZDalyWeb.Models
{

    public class ServerElmahVM
    {
        public List<ElmahErrorModel> Errors;
        public int Count { get; set; }
    }

    public class ElmahVM
    {
        public string ErrorId { get; set; }
        public string URL { get; set; }
        public DateTime Time { get; set; }
        public int Code { get; set; }
        public string Host { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
        public string Detail { get; set; }

        public string Application { get; set; }
        public string UserClient { get; set; }
        public string Source { get; set; }
        public string Severity { get; set; }

        //Item values
        public string AllHttp { get; set; }
        public string UserAgent { get; set; }
        public List<ServerVariables> ServerVariables { get; set; }

    }

    public class ElmahGroup
    {
        public string GroupName { get; set; }
        public List<ElmahErrorModel> OriginalErrors { get; set; }
        public List<ElmahErrorModel> GroupError { get; set; }
    }


    public class ServerElmahGroup
    {
        public List<ElmahGroup> AllErrors { get; set; }
        public int Count { get; set; }
    }

    public class ChartErrors
    {
        public string ErrorDate { get; set; }
        public int ErrorCount { get; set; }
    }

    public class FrequentErrors
    {
        public string Message { get; set; }
        public int CountMessage { get; set; }
    }

    public class FrequentUrl
    {
        public string Urls { get; set; }
        public int UrlTotal { get; set; }
    }
}