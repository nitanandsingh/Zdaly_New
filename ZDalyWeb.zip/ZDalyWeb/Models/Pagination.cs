using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZDalyWeb.Models
{
    public class Pagination
    {
        public int Page { get; set; }
        public int ItemsShow { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
        public string Sort { get; set; }
        public int Direction { get; set; }
        public string FromDate  { get; set; }
        public string ToDate { get; set; }
        public string TypeOrder { get; set; }
        public string Search { get; set; }
        public bool IsFromDashBoard { get; set; }
        public string ColumnWhere { get; set; }
    }
}