﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Dapper;
using ZDalyWeb.ViewModels;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;

namespace ZDalyWeb.Models.Dapper
{
    public class DapperManager
    {
        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(ConfigurationManager.ConnectionStrings["ZdalyPkConStr"].ConnectionString);
            }
        }

        public List<CountriesVM> GetCountries(int sector, int superRegion, string attributeIds)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<CountriesVM>("[dbo].[usp_Select_Country]", new { @Sector = sector, @SuperRegion = superRegion, @AttriBucketId = attributeIds }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<StatesVM> GetStates(int sector, int superRegion, string attributeIds, int regionId)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<StatesVM>("[dbo].[usp_Select_State]", new { @Sector = sector, @SuperRegion = superRegion, @AttriBucketId = attributeIds, @RegionId = regionId }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<CountiesVM> GetCounties(int sector, int superRegion, string attributeIds, int regionId)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<CountiesVM>("[dbo].[usp_Select_County]", new { @Sector = sector, @SuperRegion = superRegion, @AttriBucketId = attributeIds, @RegionId = regionId }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<AttributesVM> GetAttributeLevel1(int sector, int superRegion, int stratumId, string attributeIds, int RemainingStratumCount, string SelectedStratumId, int? regionId)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<AttributesVM>("[dbo].[usp_DashBoard_Bulk_Data_Select_Child_Attributes]", new { @SectorId = sector, @SuperRegionID = superRegion, @StratumId = stratumId, @LocationId = regionId, @RemainingStratumCount = RemainingStratumCount, @SelectedStratumId = SelectedStratumId, @AttriBucketIds = attributeIds }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<FilterTypes> GetFilterTypes(int sector, int superRegion, string attributeIds, int? regionId, int? entryId, string selectedStratumIds = "")
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<FilterTypes>("[dbo].[usp_Select_Stratum]", new { @Sector = sector, @SuperRegion = superRegion, @RegionId = regionId, @AttriBucketId = attributeIds, @EntryId = entryId, @SelectedStratumId = selectedStratumIds }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<FilterTypes> GetUniqueAttributes(int sector, int superRegion, string attributeIds, int? regionId)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<FilterTypes>("[dbo].[usp_Select_Unique_Attributes]", new { @Sector = sector, @SuperRegion = superRegion, @RegionId = regionId, @AttriBucketId = attributeIds }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<AttributeNLevel> GetAttributeNLevel(int levelId, string attributeIds, int? regionId)
        {
            using (IDbConnection cn = Connection)
            {
                var result = cn.Query<AttributeNLevel>("[dbo].[usp_Select_Attribute_NthLevel]", new { @Level = levelId, @LocationId = regionId, @AttriBucketIds = attributeIds }, commandType: CommandType.StoredProcedure).ToList();
                return result;
            }
        }
        public List<Sectors> GetAllSectors()
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<Sectors>("[dbo].[usp_Select_Sector]", commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<AttributesVM> GetAttributes(int sector, int superRegion, int stratumId, string attributeIds, int RemainingStratumCount, string SelectedStratumId, int? LocationId = null)
        {
            using (IDbConnection cn = Connection)
            {
                //var multipleResult = cn.QueryMultiple("[dbo].[usp_DashBoard_All_Attributes]", new { @SectorId = sector, @SuperRegionID = superRegion, @StratumId = stratumId, @LocationId = LocationId, @AttriBucketIds = attributeIds, @RemainingStratumCount = RemainingStratumCount, @SelectedStratumId = SelectedStratumId }, commandType: CommandType.StoredProcedure);
                //BulkAtriburesVM bulkResp = new BulkAtriburesVM();
                //bulkResp.Attribute1 = multipleResult.Read<AttributesVM>().ToList();
                //bulkResp.Attribute2 = multipleResult.Read<AttributesVM>().ToList();
                //bulkResp.Attribute3 = multipleResult.Read<AttributesVM>().ToList();
                //return bulkResp;
                return cn.Query<AttributesVM>("[dbo].[usp_DashBoard_All_Attributes]", new { @SectorId = sector, @SuperRegionID = superRegion, @StratumId = stratumId, @LocationId = LocationId, @AttriBucketIds = attributeIds, @RemainingStratumCount = RemainingStratumCount, @SelectedStratumId = SelectedStratumId }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<SearchResult> GetSearchResult(string searchString)
        {
            using (IDbConnection cn = Connection)
            {



                return cn.Query<SearchResult>("[dbo].[usp_Dashboard_Search]", new { SearchText = searchString }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<ChartData> GetChartData(int sector, int superRgionId, string attributeIds, int chartdisplayId, int? regionType, string locationIds = null)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<ChartData>("[dbo].[usp_DashBoard_Display_Chart]", new { @SectorId = sector, @superRegionID = superRgionId, @AttriBucketId = attributeIds, ByChartDisplay = chartdisplayId, LocationId = locationIds, RegionType = regionType, DisplayID = 32 }, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public DataTable GetLeftMenuDashboardData(int sector, int superRegion, string attributeIds, string SelectedStratumId, string LocationId = null)
        {
            DataTable dt = new DataTable();
            try
            {
               
                using (var conn = (SqlConnection)Connection)
                {
                    using (var command = new SqlCommand("usp_Bulk_Data_Select_Expansion", conn))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@sectorId", sector);
                        command.Parameters.AddWithValue("@superRegionId", superRegion);
                        command.Parameters.AddWithValue("@AttriBucketIds", attributeIds);
                        command.Parameters.AddWithValue("@LocationId", LocationId);
                        command.Parameters.AddWithValue("@StratumIds", SelectedStratumId);
                        SqlDataAdapter da = new SqlDataAdapter(command);
                        da.Fill(dt);
                    }
                }
            }
            catch(Exception ex)
            {

            }
            return dt;
        }
        public List<StratumVM> GetStartumns(string stramIds)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<StratumVM>("Select * from zd.Stratum WHERE ID IN(" + stramIds + ")").ToList();
            }
        }
        public List<Sectors> GetRegionTypes(string attributeIds)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<Sectors>(@"select Distinct zd.region.type as ID,zd.regiontype.name AS NAME From zd.series
	                                        INNER JOIN zd.region on zd.region.id = zd.series.region
	                                        INNER JOIN zd.regiontype on zd.regiontype.id = zd.region.type
	                                        where zd.series.attrbucket IN(" + attributeIds + ")").ToList();
            }
        }

        public List<StratumExpansionVM> GetRemainingStratums(int sector, int region, string strIds)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<StratumExpansionVM>("[dbo].[usp_Dashboard_Select_Expansion_stratum]", new { @SectorId = sector, SuperRegionID = region, SelectedStratumId = strIds }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        public List<StratumVM> GetChartSelections(int sector, int region, int level = 100)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<StratumVM>("[dbo].[usp_DashBoard_Chart_Selection_Stratum]", new { @SectorId = sector, SuperRegion = region, Level = level }, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public List<StratumVM> GetSelectionsForLEVEL101(string abIDs)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<StratumVM>("SELECT DISTINCT COALESCE(zd.Stratum.Id,-1) AS Id, COALESCE(zd.Stratum.Name,'NONE') As Name FROM zd.Series INNER JOIN Agriculture_Value ON zd.Series.Id = Agriculture_Value.Series LEFT JOIN zd.Property ON zd.Series.AttrBucket = zd.Property.AttrBucket AND zd.Property.Stratum = 32 LEFT JOIN zd.Stratum ON zd.Property.Stratum = zd.Stratum.Id WHERE Series.AttrBucket in (SELECT * FROM [dbo].[udf_Parse_String_from_CommaSeparatedValue](@ABIds))", new { ABIds = abIDs }).ToList();
            }
        }

        public List<ChartData> GetChartDataNew(string seriesId, string tableName)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.Query<ChartData>("[dbo].[usp_Get_Data_By_Series]", new { @SeriesIDs = seriesId, @TableName = tableName }, commandType: CommandType.StoredProcedure).ToList();
            }
        }

        public int AddNewFavorite(string json, string header, string chartType)
        {
            string userID = HttpContext.Current.User.Identity.GetUserId();

            SearchJsonVM objJson = JsonConvert.DeserializeObject<SearchJsonVM>(json);

            string childHeader = header + "|" + objJson.filters.SubSector[0] + "|" + objJson.filters.Sector[0];
            string rootHeader = objJson.searchText + "|" + objJson.filters.SubSector[0] + "|" + objJson.filters.Sector[0];

            using (IDbConnection cn = Connection)
            {
                int count = cn.ExecuteScalar<int>("SELECT COUNT(*) FROM [dbo].[UserFavorites] where MainHeader = @header and userID = @userID ", new { header = childHeader, userID = userID });
                if (count > 0)
                {
                    return cn.ExecuteScalar<int>("Update UserFavorites set SavedJson = @sJson,ChartType = @chartType where MainHeader = @header and userID = @userID ; SELECT CAST(SCOPE_IDENTITY() as int)", new { header = childHeader, sJson = json, userID = userID, chartType = chartType });
                }
                else
                {
                    return cn.ExecuteScalar<int>("INSERT INTO [dbo].[UserFavorites] VALUES (@header,@sJson,@userId,@rootHeader,@chartType); SELECT CAST(SCOPE_IDENTITY() as int)", new { header = childHeader, sJson = json, userId = userID, rootHeader = rootHeader, chartType = chartType });
                }
            }
        }


        public int DeleteFavorite(int Id)
        {
            using (IDbConnection cn = Connection)
            {
                return cn.ExecuteScalar<int>("DELETE FROM [dbo].[UserFavorites] Where Id = @Id", new { Id = Id });
            }
        }

        public List<UserFavoriteVM> GetFavorites()
        {
            string userID = HttpContext.Current.User.Identity.GetUserId();

            using (IDbConnection cn = Connection)
            {
                return cn.Query<UserFavoriteVM>("Select * From UserFavorites").ToList();
            }
        }
    }
}