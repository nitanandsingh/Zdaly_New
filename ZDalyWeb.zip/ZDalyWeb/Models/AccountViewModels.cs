﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ZDalyWeb.Models
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        public string UserName { get; set; }

        public string ProviderName { get; set; }
    }

    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }

    public class SendCodeViewModel
    {
        public string SelectedProvider { get; set; }
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
        public string ReturnUrl { get; set; }
        public bool RememberMe { get; set; }
    }

    public class VerifyCodeViewModel
    {
        [Required]
        public string Provider { get; set; }

        [Required]
        [Display(Name = "Code")]
        public string Code { get; set; }
        public string ReturnUrl { get; set; }

        [Display(Name = "Remember this browser?")]
        public bool RememberBrowser { get; set; }

        public bool RememberMe { get; set; }
    }

    public class ForgotViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class SignUpModel
    {
        
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        //[Required]
        //[EmailAddress]
        //[Display(Name = "Email")]
        //public string Email { get; set; }

        //[Required]
        //[StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        //[Display(Name = "Password")]
        //public string Password { get; set; }

        //[Required]
        //[Display(Name = "Full Name")]
        //public string FullName { get; set; }

        //[Display(Name = "Confirm password")]
        //[Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        //public string ConfirmPassword { get; set; }

        //public string UserID { get; set; }
        //public bool IsActive { get; set; }
        //public string CompanyUniversity { get; set; }
        //public string Phone { get; set; }
        //public List<string> UserRoles { get; set; }
        //public List<AspNetRolesVM> Roles { get; set; }
        public string Id { get; set; }
        public string FirstName { get; set; }
        public bool IsApproved { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PasswordHash { get; set; }
        public string SecurityStamp { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public Nullable<System.DateTime> LockoutEndDateUtc { get; set; }
        public bool LockoutEnabled { get; set; }
        public int AccessFailedCount { get; set; }
        public string LastName { get; set; }
        public string CompanyName { get; set; }
        public string UserName { get; set; }
    }

    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        public string Code { get; set; }
    }

    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class UserListModelProfile
    {
        public Guid UserId { get; set; }

        public string UserName { get; set; }

        public string Roles { get; set; }

        public string PreviousRole { get; set; }
        [Required]
        public string FirstName { get; set; }

        [Compare("Password", ErrorMessage = "Password and confirm password not match")]
        public string ConfirmPassword { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }
        public string Image { get; set; }
        //public HttpPostedFileBase ImageFile { get; set; }
        [Required]

        public string Email { get; set; }
    }

    public class UserWarehouseViewModel
    {
        public List<UserWarehouseDisplayRow> List { get; set; }
    }

    public class UserWarehouseDisplayRow
    {
        public int ID { get; set; }
        public string UserID { get; set; }
        public int WorkgroupID { get; set; }
        public int CompanyID { get; set; }
        public string UserName { get; set; }
        public string Workgroup { get; set; }
        public string Company { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public bool IsApproved { get; set; }

    }

    public partial class AspNetRolesVM
    { 
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
