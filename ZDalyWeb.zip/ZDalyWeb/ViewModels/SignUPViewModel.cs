﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZDalyWeb.ViewModels
{
    public class SignUPViewModel
    {
        public IEnumerable<ZDalyModels.AspNetUser> AspNetUser { get; set; }
      //  public IEnumerable<ZDalyModels.zd_SubscriptionTypes> zd_SubscriptionTypes { get; set; }
    }
}