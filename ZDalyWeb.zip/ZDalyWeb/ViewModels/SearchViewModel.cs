﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ZDalyWeb.ViewModels
{

    public class FilterTypes
    {
        public int Id { get; set; }
        public string Stratum { get; set; }
        public int LevelId { get; set; }

        public int StratumId { get; set; }

        // for css
        public int topPointer { get; set; }
    }

    public class CountriesVM
    {
        public int Id { get; set; }

        public int LocationId { get; set; }
        public string Country { get; set; }

        public int RegionId { get; set; }
        public string Name { get; set; }
    }
    public class StatesVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int LocationId { get; set; }

        public string State { get; set; }
    }
    public class CountiesVM
    {
        public int Id { get; set; }
        public int LocationId { get; set; }        
        public string County { get; set; }
        public int RegionId { get; set; }
        public string Name { get; set; }
    }

    public class AttributeLevel1
    {
        public string Entry { get; set; }
        public int LevelId { get; set; }
        public string AttrBucket { get; set; }
    }
    public class AttributeNLevel
    {
        public string Attribute1 { get; set; }
        public string Attribute2 { get; set; }

        public string Tier1_Commodity { get; set; }
        public string Tier2_Commodity { get; set; }
        public string Attribute3 { get; set; }
        public int LevelID { get; set; }
        public int AttrCount { get; set; }
        public string AtrrBucket { get; set; }

        public string Sector { get; set; }
        public string Source { get; set; }
        public string SubSector { get; set; }


    }
    public class Sectors
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string AttrBucket{get;set;}
        public string selectedStratumIds { get; set; }
    }

    public class AttributesVM
    {
        public string Attribute { get; set; }
        public string Attribute1 { get; set; }
        public string Attribute2 { get; set; }
        public string Attribute3 { get; set; }
        public string StratumId { get; set; }
        public string RemainingStratumCount { get; set; }
        public string SelectedStratumIds { get; set; }
        public int AttrCount { get; set; }
        public string AttrBucket { get; set; }
        public int RefID { get; set; }
        public int TempTableID { get; set; }
        public string Entry { get; set; }
        public string HeaderName { get; set; }
        public int level { get; set; }
    }
    public class BulkAtriburesVM
    {
        public List<AttributesVM> Attribute1 { get; set; }
        public List<AttributesVM> Attribute2 { get; set; }
        public List<AttributesVM> Attribute3 { get; set; }
    }
    public class FilterData
    {
        public int sector { get; set; } 
        public int superRegion { get; set; } 
        public string attributeIds { get; set; }
        public int regionId { get; set; } public int entryId { get; set; }
        public int stratumId { get; set; }
        public string selectedStratumIds { get; set; }
        public int remainingStratumCount { get; set; }
        public int level { get; set; }
        public int chartDisplayId { get; set; }
        public int? locationId { get; set; }
        public int? regionType { get; set; }
        public List<Sectors> selectionsAttrs { get; set; }
        public List<AttributesVM> selectedFilterLevels { get; set; }
        public string locationIds { get; set; }
        public SearchResult searchResult { get; set; }
        public Location Location { get; set; }
        public string SubSector { get; set; }
        public string FilteredJsonString { get; set; }
        public string sText { get; set; }
        public string sectorText { get; set; }
        public string FilterLocationString { get; set; }
        public string stratumList { get; set; }
        public string lastLevelArray { get; set; }
        public string locationLevels { get; set; }
        public string prevLocSelected { get; set; }
        public string reqLocationLevels { get; set; }
    }
    public class SearchResult
    {
        public string Sector { get; set; }
        public int SectorId { get; set; }
        public int SubSectorId { get; set; }
        public string SuperRegionId { get; set; }
        public string SubSector { get; set; }
        public string SuperRegion { get; set; }
        public string Entry { get; set; }
        public int EntryId { get; set; }
        public string AttrBucket { get; set; }
        public string regionId { get; set; }

        public string SearchString { get; set; }
        public string StratumName { get; set; }
    }
    public class ChartData
    {
        public long Series { get; set; }
        public DateTime ValueDate { get; set; }
        public long Value { get; set; }
        public string Name { get; set; }
        public string ValueDateString { get; set; }
        public  string Detail { get; set; }
        public string ZipCode { get; set; }
        public string StratumName { get; set; }
        public int Year { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string County { get; set; }
    }

    public class StratumVM
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int? Parent { get; set; }
        public int Level { get; set; }
        public List<Pair<string, string, string>> attr { get; set; }

        public string pABIds { get; set; }
    }

    public class Pair<T1, T2, T3>
    {
        public T1 First { get; set; }
        public T2 Second { get; set; }
        public T3 Third { get; set; }
    }

    public class StratumExpansionVM
    {
        public string RootParent { get; set; }
        public string StratumName { get; set; }
        public string StratumIds { get; set; }
    }


    public class NodeVM
    {
        public string text { get; set; }
        public string href { get; set; }
        public SearchResult jsonobj { get; set; }
        public List<NodeVM> nodes { get; set; }
    }
    public class Group
    {
        public string text { get; set; }

        public string ParentID { get; set; }

        public string attrs { get; set; }
        public string href { get; set; }

        public List<Group> nodes { get; set; }

    }
    public class selectedFilters
    {
        public int Id { get; set; }
        /// <summary>
        /// selected text of Levels
        /// </summary>
        public string text { get; set; }
        public string Stratum { get; set; }

        public string AttrBucket { get; set; }
        public string selectedStratumIds { get; set; }
    }

    public class Location
    {
        public int CountryId { get; set; }
        public string Country { get; set; }
        public int StateId { get; set; }
        public string State { get; set; }
        public int CountyId { get; set; }
        public string County { get; set; }


        public int sectorId { get; set; }
        public int superRegionId { get; set; }
        public string AttrBucket { get; set; }
    }

    public class UserFavorite
    {
        public string json { get; set; }
        public string header { get; set; }
        public string chartType { get; set; }
    }
    public class ChartDataParams
    {
        public string JsonObject { get; set; }
        public string RegionType { get; set; }
        public string Detail { get; set; }
    }

     
   
    //New List for Chart Data
    //public class Datum
    //{
    //    public List<long> seriesId { get; set; }
    //    public string details { get; set; }
    //}

    //public class ResultVM
    //{
    //    public List<Datum> data { get; set; }
    //    public string dbName { get; set; }
    //    public int propertyId { get; set; }
    //}

    public class DetailSeriesCollection
    {
        public string StratumName { get; set; }
        public string DetailID { get; set; }
        public long SeriesID { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string County { get; set; }
    }


    //Update Class for Final Result VM
    public class State
    {
        public long seriesId { get; set; }
        public string locationName { get; set; }
        public string locationParent { get; set; }
    }

    public class Country
    {
        public long seriesId { get; set; }
        public string locationName { get; set; }
        public string locationParent { get; set; }
    }

    public class County
    {
        public long seriesId { get; set; }
        public string locationName { get; set; }
        public string locationParent { get; set; }
    }

    public class SeriesId
    {
        public List<State> State { get; set; }
        public List<Country> Country { get; set; }
        public List<County> County { get; set; }
    }

    public class Datum
    {
        public SeriesId seriesId { get; set; }
        public string details { get; set; }
        public string stratumName { get; set; }
    }

    public class ResultVM
    {
        public List<Datum> data { get; set; }
        public string dbName { get; set; }
        public int propertyId { get; set; }
        public string regionType { get; set; }
    }
    public class ResultVMNew
    {
        public List<Datum> data { get; set; }
        public string dbName { get; set; }
        public int propertyId { get; set; }
        public string regionType { get; set; }
    }

    public class SeriesRow
    {
        public long Series { get; set; }
        public string Country { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public Dictionary<string,string> Attributes { get; set; }
    }

    public class SeriesRowNew
    {
        public long Series { get; set; }
        public string Country { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public string Detail { get; set; }
        public string ZipCode { get; set; }
    }
    //UserFavorite
    public class UserFavoriteVM
    {
        public int Id { get; set; }
        public string MainHeader { get; set; }
        public string SavedJson { get; set; }
        public string UserId { get; set; }
        public string ToolHeader { get; set; }
        public string ChartType { get; set; }
    }

    //New Autogenerated code for Favorites
    public class Filters
    {
        public List<string> Sector { get; set; }
        [JsonProperty("Sub-Sector")]
        public List<string> SubSector { get; set; }

        public List<string> Tier1_Commodity { get; set; }
        public List<string> Tier2_Commodity { get; set; }
        public List<string> Tier3_Commodity { get; set; }
        public List<string> Attribute1 { get; set; }
        public List<string> Attribute2 { get; set; }
        public List<string> Attribute3 { get; set; }
        public List<string> Source { get; set; }
        public List<string> Unit { get; set; }
        public List<string> Time_Level { get; set; }
    }

    public class SearchJsonVM
    {
        public string searchText { get; set; }
        public Filters filters { get; set; }
    }
}

