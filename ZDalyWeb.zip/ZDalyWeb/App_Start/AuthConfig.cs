﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Web.WebPages.OAuth;
using System.Configuration;

namespace ZDalyWeb
{

    public static class AuthConfig
    {
        public static void RegisterAuth()
        {
            // To let users of this site log in using their accounts from other sites such as Microsoft, Facebook, and Twitter,
            // you must update this site. For more information visit http://go.microsoft.com/fwlink/?LinkID=252166


            //OAuthWebSecurity.RegisterGoogleClient();


            //OAuthWebSecurity.RegisterClient(new GooglePlusClient(
            //    ConfigurationManager.AppSettings["googleConsumerKey"].ToString(),
            //    ConfigurationManager.AppSettings["googleConsumerSecret"].ToString()), "Google", null);



            //OAuthWebSecurity.RegisterYahooClient();

            //OAuthWebSecurity.RegisterFacebookClient(
            //    appId: ConfigurationManager.AppSettings["facebookappid"].ToString(),
            //    appSecret: ConfigurationManager.AppSettings["facebookappsecret"].ToString());

            //OAuthWebSecurity.RegisterTwitterClient(
            //    consumerKey: "DTnUrCMRJTJKSaKqL7Z7rlYX4",
            //    consumerSecret: "SVZdZ9bRtkP3C25BPjug3ikVuCJnbOgtigNDL2nkeK3pMAGhEe");

            

           

            //OAuthWebSecurity.RegisterLinkedInClient(
            //    consumerKey: ConfigurationManager.AppSettings["linkedconsumerkey"].ToString(),
            //    consumerSecret: ConfigurationManager.AppSettings["linkedconsumersecret"].ToString());

           
        }
    }
}
