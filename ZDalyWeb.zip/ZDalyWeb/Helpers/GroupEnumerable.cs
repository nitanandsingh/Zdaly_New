﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ZDalyWeb.ViewModels;

namespace ZDalyWeb.Helpers
{
    public static class GroupEnumerable
    {
        public static IList<Group> BuildTree(this IEnumerable<Group> source)
        {
            var groups = source.GroupBy(i => i.ParentID);

            var roots = groups.FirstOrDefault(g => g.Key == null).ToList();

            if (roots.Count > 0)
            {
                var dict = groups.Where(g => g.Key != null).ToDictionary(g => g.Key, g => g.ToList());
                for (int i = 0; i < roots.Count; i++)
                    AddChildren(roots[i], dict);
            }

            return roots;
        }

        private static void AddChildren(Group node, IDictionary<string, List<Group>> source)
        {
            if (source.ContainsKey(node.text))
            {
                node.nodes = source[node.text];
                for (int i = 0; i < node.nodes.Count; i++)
                    AddChildren(node.nodes[i], source);
            }
            else
            {
                node.nodes = new List<Group>();
            }
        }
    }
}