using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;
using ZDalyWeb.Models;
using System.Xml;

using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading;
using ZDalyModels;
namespace ZDalyWeb.Helpers
{
    public class ElmahDbHelper
    {

        public static Task<ServerElmahVM> GetAllErrors(Pagination p)
        {
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;


            return Task.Factory.StartNew<ServerElmahVM>((context) =>
            {
                using (IDbConnection cn = Connection)
                {

                    //p.Direction = 1;
                    string query = "getErrors";
                    if (!p.IsFromDashBoard)
                    {
                        p.FromDate = (string.IsNullOrEmpty(p.FromDate)) ? "1/1/1754" : ConvertToUtcTime(p.FromDate).ToString("MM-dd-yyyy HH:mm:ss");
                        p.ToDate = (string.IsNullOrEmpty(p.ToDate)) ? DateTime.Now.AddDays(1).ToString("MM-dd-yyyy") : ConvertToUtcTime(p.ToDate).ToString("MM-dd-yyyy HH:mm:ss");

                    }
                    else
                    {
                        p.ColumnWhere = "";
                        //p.FromDate = ConvertToUtcTime(p.FromDate).ToString("MM-dd-yyyy HH:mm:ss");
                        //p.ToDate = ConvertToUtcTime(p.ToDate).ToString("MM-dd-yyyy HH:mm:ss");
                    }
                    if (p.Search == null)
                    {
                        p.Search = "";
                    }
                    //if (p.Search != null)
                    //{
                    //  p.Search=  p.Search.Replace("'", "''");
                    //}

                    //using (SqlCommand cmd = new SqlCommand("getErrors", (SqlConnection)cn))
                    //{
                    //    cmd.CommandType = CommandType.StoredProcedure;

                    //    cmd.Parameters.Add("@start", SqlDbType.VarChar).Value = p.Start;
                    //    cmd.Parameters.Add("@end", SqlDbType.VarChar).Value = p.End;
                    //    cmd.Parameters.Add("@sort", SqlDbType.VarChar).Value = "";
                    //    cmd.Parameters.Add("@direction", SqlDbType.VarChar).Value = p.Direction;
                    //    cmd.Parameters.Add("@fromDate", SqlDbType.VarChar).Value = p.FromDate;
                    //    cmd.Parameters.Add("@toDate", SqlDbType.VarChar).Value = p.ToDate;
                    //    cmd.Parameters.Add("@search", SqlDbType.NVarChar).Value = p.Search;
                    //    cmd.Parameters.Add("@columnwhere", SqlDbType.NVarChar).Value = p.ColumnWhere;

                    //    cn.Open();
                    //    SqlDataReader rd = cmd.ExecuteReader();
                    //    while (rd.Read())
                    //    {
                    //        var readerRow = rd;
                    //    };


                    //}
                    HttpContext ctx = (HttpContext)context;

                    var multipleData = cn.QueryMultiple(query, new { start = p.Start, end = p.End, sort = p.Sort, direction = p.Direction, fromDate = p.FromDate, toDate = p.ToDate, search = p.Search, columnwhere = p.ColumnWhere }, commandType: CommandType.StoredProcedure);
                    List<ElmahErrorModel> errors = multipleData.Read<ElmahErrorModel>().ToList();
                    int count = multipleData.Read<int>().FirstOrDefault();
                    //List<ElmahVM> errorsListVM = new List<ElmahVM>();

                    //foreach (var error in errors)
                    //{
                    //    if (!ctx.Response.IsClientConnected)
                    //    {
                    //        Debug.WriteLine("Hello Cancelling ");
                    //        tokenSource.Cancel();

                    //    }
                    //    ElmahVM elmahObj = new ElmahVM();
                    //    elmahObj.ErrorId = error.ErrorId.ToString();
                    //    elmahObj.Code = error.StatusCode;
                    //    elmahObj.ServerVariables = new List<ServerVariables>();
                    //    elmahObj.Message = error.Message;
                    //    elmahObj.Host = error.Host;
                    //    elmahObj.Time = ConvertToIndianTime(error.TimeUtc);
                    //    elmahObj.Application = error.Application;
                    //    elmahObj.Type = error.Type;
                    //    XmlDocument doc = new XmlDocument();
                    //    doc.LoadXml(error.AllXml);
                    //    var parentNode = doc.SelectSingleNode("error");
                    //    elmahObj.Detail = parentNode.Attributes.GetNamedItem("detail").Value;
                    //    //foreach (XmlAttribute parentAttribute in parentNode.Attributes)
                    //    //{
                    //    //    elmahVm.Detail = parentAttribute.("detail").Value;

                    //    //}

                    //    var serverVariablesNode = doc.SelectSingleNode("error/serverVariables");
                    //    var serverVariableChildNodes = serverVariablesNode.SelectNodes("item");
                    //    foreach (XmlNode itemnode in serverVariableChildNodes)
                    //    {
                    //        ServerVariables ServerVariables = new ServerVariables();
                    //        ServerVariables.ItemName = itemnode.Attributes.GetNamedItem("name").Value;


                    //        ServerVariables.ValueString = itemnode.ChildNodes.Item(0).Attributes.GetNamedItem("string").Value;
                    //        elmahObj.ServerVariables.Add(ServerVariables);
                    //    }
                    //    elmahObj.Source = error.Source;
                    //    elmahObj.URL = elmahObj.ServerVariables.Where(i => i.ItemName == "URL").FirstOrDefault().ValueString;
                    //    elmahObj.UserAgent = elmahObj.ServerVariables.Where(i => i.ItemName == "HTTP_USER_AGENT").FirstOrDefault().ValueString;
                    //    errorsListVM.Add(elmahObj);
                    //}
                    Debug.WriteLine("GelAll errors Return Data");
                    ServerElmahVM serverVM = new ServerElmahVM();
                    serverVM.Errors = errors;
                    serverVM.Count = count;
                    return serverVM;
                }
            }, HttpContext.Current, token);




        }


        public static ElmahVM GetServerVariablesByID(string errorId)
        {
            using (IDbConnection cn = Connection)
            {
                string query = "select * from ELMAH_Error where ErrorId=@id";
                var errorFound = cn.Query<ElmahErrorModel>(query, new { id = errorId }).FirstOrDefault();
                if (errorFound != null)
                {
                    XmlDocument doc = new XmlDocument();
                    ElmahVM elmahObj = new ElmahVM();
                    doc.LoadXml(errorFound.AllXml);
                    var parentNode = doc.SelectSingleNode("error");
                    elmahObj.Detail = parentNode.Attributes.GetNamedItem("detail").Value;
                    elmahObj.ErrorId = errorFound.ErrorId.ToString();
                    elmahObj.Message = errorFound.Message;
                    elmahObj.Code = errorFound.StatusCode;
                    elmahObj.Host = errorFound.Host;
                    elmahObj.Application = errorFound.Application;
                    elmahObj.Source = errorFound.Source;
                    elmahObj.Type = errorFound.Type;
                    elmahObj.ServerVariables = new List<ServerVariables>();
                    elmahObj.Time = errorFound.TimeUtc;
                    var serverVariablesNode = doc.SelectSingleNode("error/serverVariables");
                    var serverVariableChildNodes = serverVariablesNode.SelectNodes("item");
                    foreach (XmlNode itemnode in serverVariableChildNodes)
                    {
                        ServerVariables ServerVariables = new ServerVariables();
                        ServerVariables.ItemName = itemnode.Attributes.GetNamedItem("name").Value;


                        ServerVariables.ValueString = itemnode.ChildNodes.Item(0).Attributes.GetNamedItem("string").Value;
                        elmahObj.ServerVariables.Add(ServerVariables);
                    }
                    elmahObj.URL = elmahObj.ServerVariables.Where(i => i.ItemName == "URL").FirstOrDefault().ValueString;
                    elmahObj.UserAgent = elmahObj.ServerVariables.Where(i => i.ItemName == "HTTP_USER_AGENT").FirstOrDefault().ValueString;
                    return elmahObj;
                }
                else
                    return null;
            }
        }


        public static Task<ServerElmahGroup> GetAllErrorsGroupBy(Pagination p)
        {
            // return Task.FromResult<ServerElmahGroup>(new ServerElmahGroup());
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;
            return Task.Factory.StartNew<ServerElmahGroup>((context) =>
            {
                HttpContext ctx = (HttpContext)context;
                if (!ctx.Response.IsClientConnected)
                    tokenSource.Cancel();
                using (IDbConnection cn = Connection)
                {
                    //p.Direction = 1;
                    string query = "GetErrorsbyGroup";

                    p.FromDate = (string.IsNullOrEmpty(p.FromDate)) ? "1/1/1754" : ConvertToUtcTime(p.FromDate).ToString("MM-dd-yyyy HH:mm:ss");
                    p.ToDate = (string.IsNullOrEmpty(p.ToDate)) ? DateTime.Now.AddDays(1).ToString("MM-dd-yyyy") : ConvertToUtcTime(p.ToDate).ToString("MM-dd-yyyy HH:mm:ss");
                    if (p.Search == null)
                    {
                        p.Search = "";
                    }

                    var multipleData = cn.QueryMultiple(query, new { start = p.Start, stop = p.End, typeorderby = p.TypeOrder, direction = 0, fromDate = p.FromDate, toDate = p.ToDate, search = p.Search }, commandType: CommandType.StoredProcedure);
                    List<ElmahErrorModel> errors = multipleData.Read<ElmahErrorModel>().ToList();
                    int count = multipleData.Read<int>().FirstOrDefault();
                    List<ElmahGroup> errorsListVM = new List<ElmahGroup>();
                    List<string> groupArray = new List<string>();
                    switch (p.TypeOrder.ToLower())
                    {
                        case "application":
                            groupArray = errors.Select(i => i.Application).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Application == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "host":
                            groupArray = errors.Select(i => i.Host).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Host == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "type":
                            groupArray = errors.Select(i => i.Type).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Type == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "source":
                            groupArray = errors.Select(i => i.Source).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Source == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "message":
                            groupArray = errors.Select(i => i.Message).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Message == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "statuscode":
                            groupArray = errors.Select(i => i.StatusCode.ToString()).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.StatusCode.ToString() == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "url":
                            groupArray = errors.Select(i => i.Url.ToString()).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Url.ToString() == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        case "useragent":
                            groupArray = errors.Select(i => i.Useragent.ToString()).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.Useragent.ToString() == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                        default:
                            groupArray = errors.Select(i => i.StatusCode.ToString()).Distinct().ToList();
                            foreach (var grouptext in groupArray)
                            {
                                ElmahGroup group = new ElmahGroup();
                                group.GroupError = new List<ElmahErrorModel>();
                                group.GroupName = grouptext;
                                group.OriginalErrors = errors.Where(i => i.StatusCode.ToString() == grouptext).ToList();
                                errorsListVM.Add(group);
                            }
                            break;
                    }

                    //foreach (var group in errorsListVM)
                    //{

                    //    foreach (var error in group.OriginalErrors)
                    //    {
                    //        if (!ctx.Response.IsClientConnected)
                    //            tokenSource.Cancel();
                    //        ElmahVM elmahObj = new ElmahVM();
                    //        elmahObj.ErrorId = error.ErrorId.ToString();
                    //        elmahObj.Code = error.StatusCode;
                    //        elmahObj.ServerVariables = new List<ServerVariables>();
                    //        elmahObj.Message = error.Message;
                    //        elmahObj.Host = error.Host;
                    //        elmahObj.Time = ConvertToIndianTime(error.TimeUtc);
                    //        elmahObj.Application = error.Application;
                    //        elmahObj.Type = error.Type;
                    //        //XmlDocument doc = new XmlDocument();
                    //        //doc.LoadXml(error.AllXml);
                    //        //var parentNode = doc.SelectSingleNode("error");
                    //        //elmahObj.Detail = parentNode.Attributes.GetNamedItem("detail").Value;
                    //        ////foreach (XmlAttribute parentAttribute in parentNode.Attributes)
                    //        ////{
                    //        ////    elmahVm.Detail = parentAttribute.("detail").Value;

                    //        ////}

                    //        //var serverVariablesNode = doc.SelectSingleNode("error/serverVariables");
                    //        //var serverVariableChildNodes = serverVariablesNode.SelectNodes("item");
                    //        //foreach (XmlNode itemnode in serverVariableChildNodes)
                    //        //{
                    //        //    ServerVariables ServerVariables = new ServerVariables();
                    //        //    ServerVariables.ItemName = itemnode.Attributes.GetNamedItem("name").Value;


                    //        //    ServerVariables.ValueString = itemnode.ChildNodes.Item(0).Attributes.GetNamedItem("string").Value;
                    //        //    elmahObj.ServerVariables.Add(ServerVariables);
                    //        //}
                    //        //elmahObj.Source = error.Source;
                    //        //elmahObj.URL = elmahObj.ServerVariables.Where(i => i.ItemName == "URL").FirstOrDefault().ValueString;
                    //        //elmahObj.UserAgent = elmahObj.ServerVariables.Where(i => i.ItemName == "HTTP_USER_AGENT").FirstOrDefault().ValueString;
                    //        //group.OriginalErrors = null;
                    //        group.GroupError.Add(elmahObj);
                    //    }
                    //}

                    Debug.WriteLine("GelAll errors group by Return Data");
                    ServerElmahGroup serverVM = new ServerElmahGroup();

                    serverVM.AllErrors = errorsListVM;
                    serverVM.Count = count;
                    return serverVM;
                }
            }, HttpContext.Current, token);


        }

        private static DateTime ConvertToUtcTime(string indiandate)
        {
            string format = "yyyy-MM-dd T HH:mm:ss";

            var dateTime = Convert.ToDateTime(indiandate);
            return TimeZoneInfo.ConvertTimeToUtc(dateTime, TimeZoneInfo.Local);
        }

        private static DateTime ConvertToIndianTime(DateTime utcDate)
        {
            return TimeZoneInfo.ConvertTimeFromUtc(utcDate, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
        }


        public static Task<List<ChartErrors>> GetErrorsForChart()
        {

            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;


            var task = Task.Factory.StartNew<List<ChartErrors>>(() =>
            {

                using (IDbConnection cn = Connection)
                {

                    string query = "select  distinct top 10 CAST(CONVERT(date,DATEADD(hour,5.30,TimeUtc)) as varchar(100)) ErrorDate,count(CONVERT(date,TimeUtc)) as errorcount from [dbo].[ELMAH_Error] group by CONVERT(date,DATEADD(hour,5.30,TimeUtc))";

                    var data = cn.Query<ChartErrors>(query).ToList();
                    Debug.WriteLine("GetErrorsForChart Return Data");


                    Debug.WriteLine("computed task is true");
                    return data;
                }

            }, token);


            return task;
        }

        public static Task<List<FrequentErrors>> GetFrequentErrors()
        {
            return Task.Factory.StartNew<List<FrequentErrors>>(() =>
            {
                using (IDbConnection cn = Connection)
                {
                    string query = "select   distinct top 5 message,COUNT(Message) as countmessage from ELMAH_Error group by  message order by countmessage desc";

                    Debug.WriteLine("GetAllErrorsCount Return Data");
                    return cn.Query<FrequentErrors>(query).ToList();
                }

            });

        }


        public static Task<List<FrequentUrl>> GetFrequentURL()
        {
            return Task.Factory.StartNew<List<FrequentUrl>>(() =>
             {
                 using (IDbConnection cn = Connection)
                 {
                     string query = " select  top 5  temp.urls,COUNT(temp.urls) as urltotal from   (select  CONVERT(xml,allxml).value('(/error/serverVariables/item/value/@string)[43]', 'varchar(150)' ) as urls from ELMAH_Error) temp group by temp.urls order by COUNT(temp.urls) desc ";
                     return cn.Query<FrequentUrl>(query).ToList();
                 }

             });


        }
        public static Task<List<ElmahVM>> RecentErrors()
        {
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;
            return Task.Factory.StartNew<List<ElmahVM>>((context) =>
            {
                HttpContext ctx = (HttpContext)context;
                if (!ctx.Response.IsClientConnected)
                    tokenSource.Cancel();
                using (IDbConnection cn = Connection)
                {
                    string query = "select top 5 * from ELMAH_Error order by TimeUtc desc";
                    List<ElmahErrorModel> errors = cn.Query<ElmahErrorModel>(query).ToList();

                    List<ElmahVM> errorsListVM = new List<ElmahVM>();

                    foreach (var error in errors)
                    {
                        if (!ctx.Response.IsClientConnected)
                            tokenSource.Cancel();
                        ElmahVM elmahObj = new ElmahVM();
                        elmahObj.ErrorId = error.ErrorId.ToString();
                        elmahObj.Code = error.StatusCode;
                        elmahObj.ServerVariables = new List<ServerVariables>();
                        elmahObj.Message = error.Message;
                        elmahObj.Host = error.Host;
                        elmahObj.Time = ConvertToIndianTime(error.TimeUtc);
                        elmahObj.Application = error.Application;
                        elmahObj.Type = error.Type;
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(error.AllXml);
                        var parentNode = doc.SelectSingleNode("error");
                        elmahObj.Detail = parentNode.Attributes.GetNamedItem("detail").Value;
                        //foreach (XmlAttribute parentAttribute in parentNode.Attributes)
                        //{
                        //    elmahVm.Detail = parentAttribute.("detail").Value;

                        //}

                        var serverVariablesNode = doc.SelectSingleNode("error/serverVariables");
                        var serverVariableChildNodes = serverVariablesNode.SelectNodes("item");
                        foreach (XmlNode itemnode in serverVariableChildNodes)
                        {
                            ServerVariables ServerVariables = new ServerVariables();
                            ServerVariables.ItemName = itemnode.Attributes.GetNamedItem("name").Value;


                            ServerVariables.ValueString = itemnode.ChildNodes.Item(0).Attributes.GetNamedItem("string").Value;
                            elmahObj.ServerVariables.Add(ServerVariables);
                        }
                        elmahObj.Source = error.Source;
                        elmahObj.URL = elmahObj.ServerVariables.Where(i => i.ItemName == "URL").FirstOrDefault().ValueString;
                        elmahObj.UserAgent = elmahObj.ServerVariables.Where(i => i.ItemName == "HTTP_USER_AGENT").FirstOrDefault().ValueString;
                        errorsListVM.Add(elmahObj);
                    }
                    Debug.WriteLine("Recent errors Return Data");
                    return errorsListVM;
                }
            }, HttpContext.Current, token);


        }
        public static Task<string> GetAllErrorsCount()
        {
            return Task.Factory.StartNew<string>(() =>
            {
                using (IDbConnection cn = Connection)
                {
                    string query = "select count(*) from ELMAH_Error";
                    Debug.WriteLine("GetAllErrorsCount Return Data");
                    return cn.Query<int>(query).FirstOrDefault().ToString();
                }
            });

        }

        public static ZDalyModels.TempLocationCommodityClass GetLocationAndCommodityID(string commodity)
        {
            //return Task.Factory.StartNew<List<int>>(() =>
            //{
            //    using (IDbConnection cn = Connection)
            //    {
            //        string spName = "usp_get_chartIDs_for_Commodity";

            //        return cn.Query<int>(spName, new { offset = offset, size = size, commodity_Id = commodityID, location_Id = locationID }, commandType: CommandType.StoredProcedure).ToList();
            //    }
            //});

            using (IDbConnection cn = Connection)
            {
                string sql = "Select TOP(1) location_Id,Commodity_Id,count(*) as NUMOFRECORDS From US_Agri.ChartLists where Commodity_Id in (select Commodity_Id from US_Agri.Commodities LEFT JOIN US_Agri.Commodity1 ON Commodities.Tier1_Id = Commodity1.Tier1_Id LEFT JOIN US_Agri.Commodity2 ON Commodities.Tier2_Id = Commodity2.Tier2_Id LEFT JOIN US_Agri.Commodity3 ON Commodities.Tier3_Id = Commodity3.Tier3_Id where Tier1_Commodity = @commodity OR Tier2_Commodity = @commodity OR Tier3_Commodity = @commodity) and defaultID = 1 group by location_Id,Commodity_Id  Order by NUMOFRECORDS desc     ";

                return cn.Query<ZDalyModels.TempLocationCommodityClass>(sql, new { commodity = commodity }).SingleOrDefault();
            }
        }

        //public static List<usp_Select_Charts_By_Paging_Result> GetTopChartsForDashboard(int commodityId, int locationId, int offSet, int size)
        //{
        //    try
        //    {
        //        using (IDbConnection cn = Connection)
        //        {
        //            var list = cn.Query<usp_Select_Charts_By_Paging_Result>("usp_Select_Charts_By_Paging", new { offSet = offSet, size = size, commodity_Id = commodityId, location_Id = locationId, @fromYear = 2008 }, commandType: CommandType.StoredProcedure).ToList();
        //            return list;

        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return null;
        //}
        //public static usp_Select_SingleCharts_By_CLA_Result GetChartDataOnFocus(int commodityId, int locationId, int attributeId)
        //{
        //    try
        //    {
        //        using (IDbConnection cn = Connection)
        //        {
        //            var list = cn.Query<usp_Select_SingleCharts_By_CLA_Result>("usp_Select_SingleCharts_By_CLA", new { commodity_Id = commodityId, location_Id = locationId, attribute_Id = attributeId }, commandType: CommandType.StoredProcedure).FirstOrDefault();
        //            return list;
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return null;
        //}
        public static IDbConnection Connection
        {
            get
            {
                return new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);
       

            }
        }

        //New Temporary Queries
        public static List<int> GetChartIDByCommodityAndLocation(int offset, int size, int commodityID, int locationID)
        {
            //return Task.Factory.StartNew<List<int>>(() =>
            //{
            //    using (IDbConnection cn = Connection)
            //    {
            //        string spName = "usp_get_chartIDs_for_Commodity";

            //        return cn.Query<int>(spName, new { offset = offset, size = size, commodity_Id = commodityID, location_Id = locationID }, commandType: CommandType.StoredProcedure).ToList();
            //    }
            //});

            using (IDbConnection cn = Connection)
            {
                string spName = "usp_get_chartIDs_for_Commodity";

                return cn.Query<int>(spName, new { offset = offset, size = size, commodity_Id = commodityID, location_Id = locationID }, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        
    }
}