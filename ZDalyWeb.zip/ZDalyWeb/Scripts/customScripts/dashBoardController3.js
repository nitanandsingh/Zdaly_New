﻿/**
 * Let's you use underscore as a service from a controller.
 * Got the idea from: http://stackoverflow.com/questions/14968297/use-underscore-inside-controllers
 * @author: Andres Aguilar https://github.com/andresesfm
 */
angular.module('underscore', []).factory('_', ['$window', function ($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);

var app = angular.module('app', ['underscore', 'ui.autocomplete', 'ngSanitize']);
app.directive('ngUpdateHidden', function () {
    return function (scope, el, attr) {
        var model = attr['ngModel'];
        scope.$watch(model, function (nv) {
            el.val(nv);
            //console.log(nv)
        });
    };
})

app.filter('checkIfEmpty', function () {

    return function (original, replacement) {
        if (original != "") {
            return original;
        }
        else {
            return replacement;
        }
    }

});
app.filter('replacePipe', function () {

    return function (original) {
        var newOrig = original.split("|");
        newOrig = newOrig.filter(function (item) {
            return (item) ? true : false;

        });
        return newOrig.join(", ");
    }

});


app.controller('dashboardController', ['$scope', "$q", '$compile', 'dashboardService', '_', '$timeout', function ($scope, $q, $compile, dashboardService, _, $timeout) {

    $scope.sector = 0;
    $scope.superRegion = 0;
    $scope.attributeIds = "";
    $scope.subSectorId = 0;
    $scope.subSectorTxt = "";
    $scope.sectorTxt = "";
    $scope.superRegionTxt = "";
    $scope.regionId = 0;
    $scope.selectedStratumIds = "";

    $scope.collectionFilterLevels = [];
    $scope.locationLevel1 = []; $scope.locationLevel2 = []; $scope.locationLevel3 = [];
    $scope.attrLevel1 = []; $scope.attrLevel2 = []; $scope.attrLevel3 = [];
    $scope.selectedStateIndex = -1; $scope.selectedCountryIndex = -1; $scope.selectedCountyIndex = -1;
    $scope.isState = false; $scope.isCountry = false; $scope.isCounty = false;
    $scope.selectedAttr1Index = -1; $scope.selectedAttr2Index = -1; $scope.selectedAttr3Index = -1;
    $scope.loadingMsg = "";
    $scope.Location = Location;
    $scope.isLocation = false;
    if (reqLocationLevels) {

        $scope.reqlocationLevels = JSON.parse(reqLocationLevels);
    }


    var tempSelectedLocation = { CountryId: 0, Country: '', StateId: 0, CountyId: 0, State: '', County: '' };


    //dashboardService.GetSearchResultsFromAPI(sText).then(function (res) {

    //    var data = res.responseEntity.searchResponse;

    //    $scope.stratumName = _.filter(data, function (o) { return o.sector == filterData.sectorTxt && o.subSector == filterData.subSectorTxt })[0].stratumName;

    //});

    if (!$scope.Location) {
        $scope.Location = tempSelectedLocation;
    }
    else {
        $scope.selectedStateIndex = $scope.Location.StateId;
        $scope.selectedCountryIndex = $scope.Location.CountryId;
        $scope.selectedCountyIndex = $scope.Location.CountyId;
    }

    var data1 = filterData;






    ///////////////////nEW lOCATION cODE//////////////
    $scope.locationCounter = 0;
    finalLocationObj = null;
    //if (prevLocSelected) {
    //    $scope.prevLocSelected =JSON.parse(prevLocSelected);
    //}
    //else {
    //    $scope.prevLocSelected = [];
    //}

    //if (locationLevels) {
    //    $scope.locationLevels = JSON.parse(locationLevels);
    //    $scope.locationCounter = $scope.locationLevels.length - 1;
    //}
    //else {
    //    $scope.locationLevels = [];
    //}
    // $scope.prevLocSelected = [];
    $scope.prevLocSelected = [];
    $scope.locationLevels = [];
    $scope.locationSelected = null;
    $scope.getLocationFilter = function (hidePopup) {
        $scope.locationCounter = 0;
        if (!hidePopup) {
            $scope.locationSelected = true;
            $scope.isShowPopup = true;
        }


        //var top = $(passedEventObject.currentTarget).offset().top;
        //var subTop = $('#filters_container').offset().top;

        //$(".popup-pointer").css({ top: (top - subTop) + 'px' });
        //$("#filters_container").show();
        if (locationJson) {
            $scope.prevLocSelected = [];
            $scope.locationLevels = [];
            var locJsonObject = JSON.parse(locationJson);
            // $scope.getLocationFilter(true);
            var params = '{';
            params += '"searchText" : "' + sText + '",';
            params += '"filters" : ' + jsonXX;


            params += '}';
            var jsonObj = JSON.parse(params);

            jsonObj["location"] = true;
            jsonObj["reqAttList"] = "";



            dashboardService.GetLocData(jsonObj).then(function (data) {
                var newprevLocSelected = JSON.parse(prevLocSelected);
                var locations = data.responseEntity.locations;

                var key = Object.keys(locations)[0];

                var locationData = locations[key].map(function (location) {
                    return location.locations.join(",");

                });

                var nextLevel = {
                    headerText: key,
                    data: locationData,
                    selectedItem: newprevLocSelected[0] ? newprevLocSelected[0].selectedItem : null
                };

                //  var newSelection = { header: key, selectedItem: newprevLocSelected[0] ? newprevLocSelected[0].selectedItem : null };
                //$scope.prevLocSelected.pus
                $scope.locationLevels.push(nextLevel);






                runLocationLoop(JSON.parse(prevLocSelected));
                //newprevLocSelected.forEach(function (item, index) {

                //    setTimeout(function () {
                //        (function (item, index) {
                //            console.log("calling index", item, index);

                //            $scope.getNextLevelInitial(item.header, item.selectedItem, nextLevel, index, newprevLocSelected[index + 1]);

                //        })(item, index);
                //    }, (index) * 800);


                //});



            });


        }

        else {
            $scope.locLoader = true;




            var params = '{';
            params += '"searchText" : "' + sText + '",';
            params += '"filters" : ' + jsonXX;


            params += '}';
            var jsonObj = JSON.parse(params);

            jsonObj["location"] = true;
            jsonObj["reqAttList"] = "";



            dashboardService.GetLocData(jsonObj, $scope.reqlocationLevels).then(function (data) {
                $scope.locLoader = false;
                var locations = data.responseEntity.locations;
                if (Object.keys(locations).length == 1) {
                    var key = Object.keys(locations)[0];
                    if (locations[key].length > 0) {
                        var locationData = locations[key].map(function (location) {
                            return location.locations.join(",");

                        });

                        $scope.locationLevels.push({
                            headerText: key,
                            data: locationData
                        });
                    }
                }
                else {
                    $scope.locationLevels.push({
                        headerText: "SelectLevel",
                        data: Object.keys(locations)
                    });
                }


            });

        }

    }

    function runLocationLoop(myLocObj) {

        var counter = -1;
        console.log("runLocationLoop");
        function next() {
            setTimeout(function () {
                counter++;
                if (counter < myLocObj.length) {
                    console.log("next", myLocObj[counter].header, myLocObj[counter].selectedItem, {}, counter, myLocObj[counter + 1]);

                    $scope.getNextLevelInitial(myLocObj[counter].header, myLocObj[counter].selectedItem, {}, counter, myLocObj[counter + 1], myLocObj).then(next);

                }

            }, 0);





        }
        next();
    }


    $scope.closeLocationPopup = function (isNullify) {


        if (isNullify)
            finalLocationObj = null;
        else {
            var textArray = [];


            Object.keys(finalLocationObj).forEach(function (key) {
                textArray.push(finalLocationObj[key][0].split(":")[1]);
            });

            //$scope.selectedFilters.push({ Stratum: "Location", Id: 0, text: textArray.reverse().join(","), AttrBucket: "", selectedStratumIds: "" });

            //var index = $scope.Filters.indexOf($scope.locationSelected);
            //$scope.Filters.splice(index, 1);
            var lastLevelArrayObj = JSON.parse(lastLevelArray);
            lastLevelArrayObj.forEach(function (item) {
                if (item.key == "Location") {
                    item.value = textArray.reverse().join(",")
                }
            });
            lastLevelArray = JSON.stringify(lastLevelArrayObj);
            locationJson = JSON.stringify(finalLocationObj);
            prevLocSelected = JSON.stringify($scope.prevLocSelected);
            reqLocationLevels = JSON.stringify($scope.reqlocationLevels);
            $scope.selectActiveLevel();
        }
        //$scope.locationLevels = [];
        $scope.locationSelected = null;
        $scope.isShowPopup = false;
        //$scope.selectedFilter = null;

    }

    $scope.getNextLevelInitial = function (header, selectedItem, level, levelIndex, nextItem, wholePrevSelected) {

        //level.selectedItem = selectedItem;
        //if (header != "SelectLevel") {
        //    selected
        //}
        var defer = $q.defer();

        var newSelection = { header: header, selectedItem: selectedItem };





        if (levelIndex < $scope.locationCounter) {
            var splicedLevels = $scope.locationLevels.splice(levelIndex + 1, $scope.locationLevels.length);

            $scope.prevLocSelected.splice(levelIndex, $scope.prevLocSelected.length);
            $scope.locationCounter = levelIndex;
        }



        $scope.prevLocSelected.push(newSelection);



        $scope.currentLevelIndex = levelIndex;



        var params = '{';
        params += '"searchText" : "' + sText + '",';
        params += '"filters" : ' + jsonXX;



        params += '}';
        var jsonObj = JSON.parse(params);

        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";

        var prevSelectedLocs = $scope.prevLocSelected.filter(function (prevLoc) {
            return (prevLoc.header != "SelectLevel");

        });
        var locationObj = {};
        var locTemp = {};
        prevSelectedLocs.forEach(function (locItem, index) {
            if (index == 0) {
                locationObj[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
                locTemp[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
            }
            else {
                locationObj[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                locTemp[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];

                if (selectedItem.toLowerCase() == "overall") {
                    var prevUnselected = $scope.locationLevels.filter(function (locLevel) {
                        return (locLevel.headerText == "SelectLevel")

                    });
                    var lastPrevSelected = prevUnselected[prevUnselected.length - 1];
                    lastPrevSelected.data.forEach(function (levelText) {
                        locationObj[levelText] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                    });



                }
            }
        });

        finalLocationObj = locationObj;
        jsonObj["locations"] = locationObj;

        var locationLevel = {};
        Object.keys(locTemp).forEach(function (key, index) {
            locationLevel[key] = index + 1;
        });
        var wildcardSelected = Object.keys(locationObj).filter(function (key) {
            var locTempKeys = Object.keys(locationLevel);
            return (locTempKeys.indexOf(key) == -1)
        });

        wildcardSelected.forEach(function (key) {

            locationLevel[key] = Object.keys(locTemp).length;

        });


        jsonObj["locationLevels"] = locationLevel;
        $scope.reqlocationLevels = locationLevel;



        if (header == "SelectLevel") {
            if ($scope.locationLevels[$scope.locationCounter] && $scope.locationLevels[$scope.locationCounter].headerText != "SelectLevel") {
                console.log("$scope.locationLevels[levelIndex-1]", $scope.locationLevels[$scope.locationCounter]);
                $scope.prevLocSelected.splice($scope.prevLocSelected.indexOf(newSelection), 1);
                // $scope.locationLevels.splice((levelIndex), 1);
                console.log("resolving fix");


                defer.resolve();
            }
            else {
                $scope.locLoader = true;
                dashboardService.GetLocData(jsonObj, $scope.reqlocationLevels).then(function (data) {

                    var locations = data.responseEntity.locations;

                    var locationData = [];
                    if (locations[selectedItem]) {
                        locations[selectedItem].forEach(function (location) {
                            locationData = locationData.concat(location.locations);
                        });


                        $scope.locationLevels.push({
                            headerText: selectedItem,
                            data: locationData,
                            selectedItem: nextItem ? nextItem.selectedItem : null
                        });
                        $scope.locLoader = false;

                        setTimeout(function () {
                            $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 900);

                        }, 200);

                    }

                    $scope.locationCounter++;
                    defer.resolve();
                });

            }


        }

        else {
            $scope.locLoader = true;
            dashboardService.GetLocData(jsonObj, $scope.reqlocationLevels).then(function (data) {
                console.info("Getting Loc Data ", data);
                $scope.locLoader = false;
                var locations = data.responseEntity.locations;
                if (Object.keys(locations).length == 1) {
                    var key = Object.keys(locations)[0];
                    if (locations[key].length > 0) {
                        var locationData = locations[key].map(function (location) {
                            return location.locations.join(",");

                        });

                        $scope.locationLevels.push({
                            headerText: key,
                            data: locationData
                        });
                    }
                }
                else {

                    var nonEmpty = Object.keys(locations).filter(function (key) {
                        return locations[key].length > 0;
                    });

                    var showSlections = nonEmpty.filter(function (key) {
                        var found = true;
                        $scope.prevLocSelected.forEach(function (prevSelected) {

                            if (prevSelected.header.toLowerCase() == key.toLowerCase()) {
                                found = false;
                            }
                        });

                        return found;
                    });
                    if (showSlections.length == 1) {


                        var locationData = [];
                        locations[showSlections[0]].forEach(function (location) {
                            locationData = locationData.concat(location.locations);
                        });
                        //var showData = locations[showSlections[0]];
                        var selectedItemShow;
                        if (locationData.indexOf(nextItem.selectedItem) == -1) {
                            selectedItemShow = wholePrevSelected[levelIndex + 2].selectedItem;
                        }
                        else {
                            selectedItemShow = nextItem.selectedItem;
                        }
                        $scope.locationLevels.push({
                            headerText: showSlections[0],
                            data: locationData,
                            selectedItem: nextItem ? selectedItemShow : null
                        });
                    }


                    else if (showSlections.length > 1) {
                        $scope.locationLevels.push({
                            headerText: "SelectLevel",
                            data: showSlections,
                            selectedItem: nextItem ? nextItem.selectedItem : null
                        });
                    }
                    else {
                        //  $scope.prevLocSelected.pop(newSelection);
                    }

                }

                setTimeout(function () {
                    $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 800);

                }, 200);
                $scope.locationCounter++;
                defer.resolve();

            });


        }
        return defer.promise;


    }




    $scope.getNextLevel = function (header, selectedItem, level, levelIndex) {
        if (selectedItem == level.selectedItem || $scope.locLoader) {

            return false;
        }
        level.selectedItem = selectedItem;
        //if (header != "SelectLevel") {
        //    selected
        //}


        var newSelection = { header: header, selectedItem: selectedItem };





        if (levelIndex < $scope.locationCounter) {
            var splicedLevels = $scope.locationLevels.splice(levelIndex + 1, $scope.locationLevels.length);

            $scope.prevLocSelected.splice(levelIndex, $scope.prevLocSelected.length);
            $scope.locationCounter = levelIndex;
        }

        $scope.prevLocSelected.push(newSelection);



        $scope.currentLevelIndex = levelIndex;



        var params = '{';
        params += '"searchText" : "' + sText + '",';
        params += '"filters" : ' + jsonXX;



        params += '}';
        var jsonObj = JSON.parse(params);

        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";

        var prevSelectedLocs = $scope.prevLocSelected.filter(function (prevLoc) {
            return (prevLoc.header != "SelectLevel");

        });
        var locationObj = {};
        var locTemp = {};
        prevSelectedLocs.forEach(function (locItem, index) {
            if (index == 0) {
                locationObj[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
                locTemp[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
            }
            else {
                locationObj[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                locTemp[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];

                if (selectedItem.toLowerCase() == "overall") {
                    var prevUnselected = $scope.locationLevels.filter(function (locLevel) {
                        return (locLevel.headerText == "SelectLevel")

                    });
                    var lastPrevSelected = prevUnselected[prevUnselected.length - 1];
                    lastPrevSelected.data.forEach(function (levelText) {
                        locationObj[levelText] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                    });



                }
            }
        });

        finalLocationObj = locationObj;
        jsonObj["locations"] = locationObj;

        var locationLevel = {};
        Object.keys(locTemp).forEach(function (key, index) {
            locationLevel[key] = index + 1;
        });
        var wildcardSelected = Object.keys(locationObj).filter(function (key) {
            var locTempKeys = Object.keys(locationLevel);
            return (locTempKeys.indexOf(key) == -1)
        });

        wildcardSelected.forEach(function (key) {

            locationLevel[key] = Object.keys(locTemp).length;

        });


        jsonObj["locationLevels"] = locationLevel;
        $scope.reqlocationLevels = locationLevel;


        if (header == "SelectLevel") {
            $scope.locLoader = true;
            dashboardService.GetLocData(jsonObj, $scope.reqlocationLevels).then(function (data) {

                var locations = data.responseEntity.locations;

                var locationData = [];
                locations[selectedItem].forEach(function (location) {
                    locationData = locationData.concat(location.locations);
                });


                $scope.locationLevels.push({
                    headerText: selectedItem,
                    data: locationData
                });
                $scope.locLoader = false;


                setTimeout(function () {
                    $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 900);
                }, 200);


            });
        }

        else {
            $scope.locLoader = true;
            dashboardService.GetLocData(jsonObj, $scope.reqlocationLevels).then(function (data) {
                console.info("Getting Loc Data ", data);
                $scope.locLoader = false;
                var locations = data.responseEntity.locations;
                if (Object.keys(locations).length == 1) {
                    var key = Object.keys(locations)[0];
                    if (locations[key].length > 0) {
                        var locationData = locations[key].map(function (location) {
                            return location.locations.join(",");

                        });

                        $scope.locationLevels.push({
                            headerText: key,
                            data: locationData
                        });
                    }
                }
                else {

                    var nonEmpty = Object.keys(locations).filter(function (key) {
                        return locations[key].length > 0;
                    });

                    var showSlections = nonEmpty.filter(function (key) {
                        var found = true;
                        $scope.prevLocSelected.forEach(function (prevSelected) {

                            if (prevSelected.header.toLowerCase() == key.toLowerCase()) {
                                found = false;
                            }
                        });

                        return found;
                    });
                    if (showSlections.length == 1) {


                        var locationData = [];
                        locations[showSlections[0]].forEach(function (location) {
                            locationData = locationData.concat(location.locations);
                        });
                        //var showData = locations[showSlections[0]];

                        $scope.locationLevels.push({
                            headerText: showSlections[0],
                            data: locationData
                        });
                    }


                    else if (showSlections.length > 1) {
                        $scope.locationLevels.push({
                            headerText: "SelectLevel",
                            data: showSlections
                        });
                    }
                    else {
                        //  $scope.prevLocSelected.pop(newSelection);
                    }

                }

                setTimeout(function () {
                    $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 800);

                }, 200);


            });
        }

        $scope.locationCounter++;

    }





    ///////////////////////////////////////













    var collectionFilterLevels = [];
    if (searchFilterLevels != null) {
        var rootLevel = _.where(searchFilterLevels, { level: 0 });
        //$scope.Location.AttrBucket = rootLevel[0].AttrBucket;
        initfuncton();

        for (i = 0; i < rootLevel.length; i++) {
            var stratumId = rootLevel[i].StratumId;
            var flag = true;
            var obj = rootLevel[i];
            obj.Levels = [];
            a = 0;
            tempStratumId = parseInt(stratumId);
            while (flag) {
                tempStratumId = parseInt(tempStratumId);
                tempArray = _.findWhere(searchFilterLevels, { RefID: tempStratumId });

                if (tempArray == undefined) {
                    flag = false;
                    break;
                }
                else {
                    tempArray.RootID = obj.StratumId;
                    obj.Levels.push(tempArray);

                    if (tempArray.StratumId == null) {

                        flag = false;
                    }
                    else {
                        tempStratumId = tempArray.StratumId;
                    }
                }
            }
            if (obj.Levels.length > 0)
                collectionFilterLevels.push(obj);
        }
        $scope.collectionFilterLevels = collectionFilterLevels;
    }
    else {

        $scope.Location.AttrBucket = data1.attributeIds;

    }

    function initfuncton() {

        console.log(jsonXX);

        var jsonObj = JSON.parse(jsonXX);
        var tempTopFilters = [];
        $scope.tempTopFilters = JSON.parse(lastLevelArray);

        if (!jsonObj.hasOwnProperty("Tier3_Commodity")) {
            if (!jsonObj.hasOwnProperty("Tier2_Commodity")) {
                if (!jsonObj.hasOwnProperty("Tier1_Commodity")) {

                }
                else {
                    tempTopFilters.push({
                        key: "Tier1_Commodity",
                        value: jsonObj["Tier1_Commodity"]
                    });
                }
            }
            else {
                tempTopFilters.push({
                    key: "Tier2_Commodity",
                    value: jsonObj["Tier2_Commodity"]
                });
            }
        }
        else {
            tempTopFilters.push({
                key: "Tier3_Commodity",
                value: jsonObj["Tier3_Commodity"]
            });
        }

        if (!jsonObj.hasOwnProperty("Attribute3")) {
            if (!jsonObj.hasOwnProperty("Attribute2")) {
                if (!jsonObj.hasOwnProperty("Attribute1")) {

                }
                else {
                    tempTopFilters.push({
                        key: "Attribute1",
                        value: jsonObj["Attribute1"]
                    });
                }
            }
            else {
                tempTopFilters.push({
                    key: "Attribute2",
                    value: jsonObj["Attribute2"]
                });
            }
        }
        else {
            tempTopFilters.push({
                key: "Attribute3",
                value: jsonObj["Attribute3"]
            });
        }


        var locationFilter = $scope.tempTopFilters.filter(function (item) {
            return item.key == "Location";
        });
        $scope.topLocationFilter = locationFilter;


        var locationObj = JSON.parse(locationJson);

        console.log(locationObj);
        if (locationObj) {
            var country = locationObj.Country;
            var state = locationObj.State;

            var county = locationObj.County;


            var displayTextArray = [];
            if (county) {
                displayTextArray.push(county[0].split(":")[1]);
            }
            if (state) {
                displayTextArray.push(state[0].split(":")[1]);
            }
            if (country) {
                displayTextArray.push(country[0].split(":")[1]);
            }
            var DisplayText = displayTextArray.join(",");
            //  var DisplayText = (county ? county[0].split(":")[1] + ", " : "") + (state  ? state[0].split(":")[1] + ", " : "") + (country ? county[0].split(":")[1] : "");
            $scope.selectedCountry = country ? country[0] : null;
            $scope.selectedState = state ? state[0] : null;
            $scope.selectedCounty = county ? county[0] : null;

            $scope.selectedLocation = DisplayText;
        }
        else {
            $scope.selectedLocation = "United States";
        }

        var searchQuery = (sText != "" ? sText + (sSector != "" ? " in " + sSector : "") : DisplayText);

        if (searchQuery != "") {
            var searchLoc = sLocation;
            dashboardService.GetLatestNews(searchQuery, sLocation).then(function (res) {
                res.forEach(function (newsItem) {

                    var regex1 = new RegExp("font", "g");

                    var regex2 = new RegExp("<br>", "g");

                    newsItem.Description = newsItem.Description.replace(regex1, "span").replace(regex2, "");
                    console.log("newsItem.Description", newsItem.Description);
                });

                $scope.latestNews = res;
            });
        }
    }

    if (parseInt(data1.sector) != 0) {


        $scope.sector = data1.sector;
        $scope.superRegion = data1.superRegion;
        $scope.sectorTxt = data1.sectorTxt;
        $scope.superRegionTxt = data1.superRegionTxt;
        $scope.attributeIds = data1.attributeIds;
        $scope.subSectorId = data1.subSectorId;
        $scope.subSectorTxt = data1.subSectorTxt;
        $scope.selectedStratumIds = data1.selectedStratumIds

        $("#c_tag").val(data1.sector);
    }
    var sectorModals = [{ Id: 1, modal: 'agrimodal', cssClass: 'agriculture', image: "snav-agrico.png" }, { Id: 2, modal: 'educationmodal', cssClass: 'education_box', image: "snav-eduico.png" }];

    $scope.myOption1 = {
        options: {
            //appendTo: "#inner-c-tags",
            html: true,
            focusOpen: false,
            onlySelectValid: true,
            minLength: 3,
            delay: 0,
            search: function (event, ui) {
                window.pageIndex = 0;
            },
            source: function (request, response) {

                dashboardService.GetSearchResultsFromAPI(request.term).then(function (res) {
                    var result = [];

                    //angular.forEach(res.responseEntity.searchResponse, function (item) {


                    //    var jsonObj = {
                    //        sector: item.sector,
                    //        subSector: item.subSector,
                    //        superRegion: item.superRegion,
                    //        sectorId: 1,
                    //        subSectorId: item.SubSectorId,
                    //        superRegionId: item.SuperRegionId,
                    //        AttrBucket: item.AttrBucket
                    //    }

                    //    staticSecFields = _.where(sectorModals, { Id: 1 });
                    //    jsonObj.cssClass = staticSecFields[0].cssClass;
                    //    jsonObj.image = staticSecFields[0].image;

                    //    result.push({
                    //        data: jsonObj,
                    //        value: item.suggestionString
                    //    });

                    //});

                    angular.forEach(res.responseEntity.searchResponse, function (item) {
                        var jsonObj = {
                            sector: item.sector,
                            subSector: item.subSector,
                            superRegion: item.superRegion,
                            sectorId: 1,
                            subSectorId: item.SubSectorId,
                            superRegionId: item.SuperRegionId,
                            AttrBucket: item.AttrBucket,
                            StratumName: item.stratumName,
                            SearchString: item.suggestionString
                        }
                        staticSecFields = _.where(sectorModals, { Id: 1 });
                        result.push({
                            data: jsonObj,
                            // label: $compile("<a>" + item.SubSector + ", <span class='label'> " + item.Sector + " in " + item.SuperRegion + "</span></a>")($scope),
                            label: $compile("<a class='" + staticSecFields[0].cssClass + "' style='background-image: url(../images/" + staticSecFields[0].image + ");background-repeat: no-repeat;background-position: 7px 7px;padding: 9px 20px 9px 45px;background-size:23px 23px;'>" + item.suggestionString + " in <span class='label'> <span style='font-weight:500'>" + item.subSector + "</span>,  " + item.sector + " in " + item.superRegion + "</span></a>")($scope),
                            value: item.suggestionString
                        });
                    });

                    if (!result.length) {
                        result.push({
                            label: 'not found',
                            value: ''
                        });
                    }
                    response(result);
                });
            },
            select: function (event, ui) {
                var data = ui.item.data;
                filterData = data;

                dashboardService.NewSearch(data).then(function (response) {

                    window.location.href = "/new/search";
                })

                $scope.sector = data.sectorId;
                $scope.superRegion = data.superRegionId;
                $scope.attributeIds = data.AttrBucket;
                $scope.subSectorId = data.subSectorId;
                $scope.subSectorTxt = data.subSector;
                $scope.sectorTxt = data.sector;
                $scope.superRegionTxt = data.superRegion;

                event.stopPropagation();
            },
        },
        methods: {},
    }

    /**************************************Filter POP UP ************************************/
    var selectedFilterLevels = [];
    var selectedAttrLevels = "";
    var selectedAtr1 = "", selectedAtr2 = "", selectedAttrIds1 = "", selectedAttrIds2 = "", selectedAttrIds3 = "";
    $scope.isAttr2 = false; $scope.isAttr3 = false;
    $scope.isShowPopup = false;

    $scope.activeNonLocationFilter = null;
    $scope.showFilterPopup = function (key, value) {
        $scope.nonLocationsFilter = [];
        activeNonLocationFilter = key;
        $scope.otherFilters = true;
        var originalFilter = JSON.parse(jsonXX);

        var rootJson = JSON.parse(jsonXX);
        console.log("rootJson", rootJson);
        var breadSingle = makebreadCumSingle({ stratumName: key }, myStratumList);

        breadSingle = breadSingle.levels.filter(function (item) {
            return item.stratumName == key;

        });

        //deleting parent 
        console.log("breadSingle", breadSingle);
        var getTreeNameRemove = getParentChildNamesRemove(breadSingle[0])

        getTreeNameRemove.filter(function (statumName) {

            delete rootJson[statumName];
        });

        var params = '{';
        params += '"searchText" : "' + sText + '",';
        params += '"filters" : ' + JSON.stringify(rootJson);



        params += '}';
        var jsonObj = JSON.parse(params);

        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";

        if (finalLocationObj) {
            jsonObj["locations"] = finalLocationObj;
        }
        else {
            if (locationJson) {
                jsonObj["locations"] = JSON.parse(locationJson);
            }
        }

        var stratumKeyVal = [];

        var levelVals = value.split(",").reverse();
        console.log("value", value);
        console.log("levelVals", levelVals);

        for (var i = 0; i < getTreeNameRemove.length; i++) {

            console.log("key ", getTreeNameRemove[i]);
            console.log("value ", originalFilter[getTreeNameRemove[i]]);

            if (originalFilter[getTreeNameRemove[i]]) {
                stratumKeyVal.push({ key: getTreeNameRemove[i], value: originalFilter[getTreeNameRemove[i]][0] });

            }

        }

        console.log("stratumKeyVal", stratumKeyVal);
        console.log("getTreeNameRemove", getTreeNameRemove);
        $scope.locLoader = true;
        dashboardService.GetFiltersData(jsonObj, $scope.reqlocationLevels).then(function (res) {
            $scope.locLoader = false;
            console.log("resposnse get", res);
            $scope.nonLocationsFilter.push({
                header: key,
                data: res.responseEntity.stratum[key],
                selected: stratumKeyVal.filter(function (item) {
                    return item.key == key
                })[0].value
            });
            console.log("selected ", key, stratumKeyVal[key])

            stratumKeyVal.forEach(function (item, index) {
                console.log("stratumKeyVal", item, index);




                if (stratumKeyVal[index + 1]) {
                    jsonObj.filters[item.key] = [item.value];
                    loadNextLevels(jsonObj, item.key, stratumKeyVal[index + 1].key, stratumKeyVal[index + 1].value);
                }

            });
        });




    }

    $scope.getNextLevelStratum = function (filter, item, index) {
        filter.selected = item;
        var filtersJson = JSON.parse(jsonXX);
        if (index < $scope.nonLocationsFilter.length - 1) {
            var splicedArray = $scope.nonLocationsFilter.splice(index + 1, $scope.nonLocationsFilter.length);
            splicedArray.forEach(function (item) {
                delete filtersJson[item.header];
            });
        }


        filtersJson[filter.header] = [item];
        var params = '{';
        params += '"searchText" : "' + sText + '",';
        params += '"filters" : ' + JSON.stringify(filtersJson);



        params += '}';
        var jsonObj = JSON.parse(params);

        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";

        if (finalLocationObj) {
            jsonObj["locations"] = finalLocationObj;
        }
        else {
            if (locationJson) {
                jsonObj["locations"] = JSON.parse(locationJson);
            }
        }
        console.info("Json Obj is ", jsonObj);
        var breadSingle = makebreadCumSingle({ stratumName: filter.header }, myStratumList);

        breadSingle = breadSingle.levels.filter(function (item) {
            return item.stratumName == filter.header;

        });
        console.log("breadSingle", breadSingle);
        if (breadSingle[0].children[0]) {
            console.log("breadSingle children ", breadSingle[0].children[0]);
            $scope.locLoader = true;
            dashboardService.GetFiltersData(jsonObj, $scope.reqlocationLevels).then(function (res) {
                console.log("reqObj res", res);
                $scope.locLoader = false;
                $scope.nonLocationsFilter.push({
                    header: breadSingle[0].children[0].stratumName,
                    data: res.responseEntity.stratum[breadSingle[0].children[0].stratumName],
                    selected: null
                });



            });
        }

    }


    function loadNextLevels(reqObj, key, stratumName, selectedVal) {
        var defer = $q.defer();
        $scope.locLoader = true;
        dashboardService.GetFiltersData(reqObj, $scope.reqlocationLevels).then(function (res) {
            $scope.locLoader = false;
            console.log("reqObj res", res);
            console.log(reqObj, key, stratumName);
            $scope.nonLocationsFilter.push({
                header: stratumName,
                data: res.responseEntity.stratum[stratumName],
                selected: selectedVal
            });

            defer.resolve();

        });


    }


    function getParentChildNamesRemove(breadSingle) {
        var arrayParentChild = [];
        arrayParentChild.push(breadSingle.stratumName);
        var processItem = breadSingle;
        console.log("processItem", processItem);
        while (processItem.children.length > 0) {
            console.log("processItem", processItem);
            arrayParentChild.push(processItem.children[0].stratumName);
            processItem = processItem.children[0];
        }
        return arrayParentChild;
    }


    function makebreadCumSingle(mainObj, list) {



        var newList = JSON.parse(JSON.stringify(list));

        var rootItem = mainObj;
        var breadItem = {
            levels: []
        }

        rootItem.children = [];
        var process = true;
        var processItem = rootItem;
        while (process) {
            breadItem.levels.push(processItem);
            var child = getChild(processItem.stratumName, newList);
            newList.splice(newList.indexOf(child), 1);

            if (child) {
                processItem.children.push(child);
                processItem = child;
                processItem.children = [];
            }
            else {
                process = false;
            }

        }



        return breadItem;

    }


    $scope.ClosePopup = function () {
        $scope.isShowPopup = false;
        $scope.otherFilters = false;
    }
    $scope.getAttrLevel2 = function (level, index) {

        $scope.selectedAttr1Index = level.Entry;
        $scope.attrLevel2 = [];
        $scope.attrLevel3 = [];

        var newFilters = JSON.parse(jsonXX);

        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        var tempList = [];
        tempList.push(level.Entry);

        newJson.filters[$scope.lvl1Header] = tempList;
        delete newJson.filters[$scope.lvl2Header];
        delete newJson.filters[$scope.lvl3Header];
        $scope.selectedAttr2Index = null;
        $scope.selectedAttr3Index = null;

        var locationObj = JSON.parse(locationJson);
        if (locationObj) {
            newJson["locations"] = locationObj;
        }

        dashboardService.GetAttributeLevel1(JSON.stringify(newJson)).then(function (response) {

            var child = $scope.lvl2Header;
            var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == child });

            var data = response.responseEntity.stratum[child];
            var list = [];
            for (var val in data) {
                list.push({
                    Entry: data[val] != "" ? data[val] : "",
                });
            }
            $scope.attrLevel2 = list;

        });
    }

    $scope.getAttrLevel3 = function (level, index) {
        console.log(level)



        $scope.selectedAttr2Index = level.Entry;
        $scope.attrLevel3 = [];

        var newFilters = JSON.parse(jsonXX);

        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        var tempList = [];
        tempList.push(level.Entry);
        newJson.filters[$scope.lvl2Header] = tempList;

        tempList = [];
        tempList.push($scope.selectedAttr1Index);
        newJson.filters[$scope.lvl1Header] = tempList;

        delete newJson.filters[$scope.lvl3Header];
        $scope.selectedAttr3Index = null;

        var locationObj = JSON.parse(locationJson);
        if (locationObj) {
            newJson["locations"] = locationObj;
        }

        dashboardService.GetAttributeLevel1(JSON.stringify(newJson)).then(function (response) {

            var child = $scope.lvl3Header;
            var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == child });

            var data = response.responseEntity.stratum[child];
            var list = [];
            for (var val in data) {
                list.push({
                    Entry: data[val] != "" ? data[val] : "",
                });
            }
            $scope.attrLevel3 = list;

        });

    }

    $scope.getAttrLevel3Active = function (level, index) {

        $scope.selectedAttr3Index = level.Entry;
    }

    $scope.selectActiveLevel = function (nonLocationsFilter) {
        var lastLevelArrayObj = JSON.parse(lastLevelArray);
        console.log("lastLevelArrayObj", lastLevelArrayObj);
        var newFilters = JSON.parse(jsonXX);

        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        if (nonLocationsFilter) {
            var breadSingle = makebreadCumSingle({ stratumName: activeNonLocationFilter }, myStratumList);

            breadSingle = breadSingle.levels.filter(function (item) {
                return item.stratumName == activeNonLocationFilter;

            });

            //deleting parent 
            console.log("breadSingle", breadSingle);
            var getTreeNameRemove = getParentChildNamesRemove(breadSingle[0])

            getTreeNameRemove.filter(function (statumName) {

                delete newJson.filters[statumName];
            });

            // insering new Filters
            var selectedVals = [];
            nonLocationsFilter.forEach(function (level) {
                if (level.selected) {
                    selectedVals.push(level.selected);
                    newJson.filters[level.header] = [level.selected];
                }
            });
            console.log("selectedVals", selectedVals);
            lastLevelArrayObj.forEach(function (item) {
                if (item.key == activeNonLocationFilter)
                    item.value = selectedVals.reverse().join(",");
            });


            console.warn("changed ", lastLevelArrayObj);
            lastLevelArray = JSON.stringify(lastLevelArrayObj);

        }
        console.log("finalLocationObj", finalLocationObj);
        if (finalLocationObj) {
            newJson["locations"] = finalLocationObj;
        }
        else {
            if (locationJson) {
                newJson["locations"] = JSON.parse(locationJson);
            }
        }
        $scope.otherFilters = false;
        console.log("new Filter is ", newJson);

        //var tempList = [];
        //tempList.push($scope.selectedAttr1Index);
        //newJson.filters[$scope.lvl1Header] = tempList;


        //if ($scope.selectedAttr2Index != null) {
        //    var tempList = [];
        //    tempList.push($scope.selectedAttr2Index);
        //    newJson.filters[$scope.lvl2Header] = tempList;
        //}
        //else {
        //    delete newJson.filters[$scope.lvl2Header];
        //}

        //if ($scope.selectedAttr3Index != null) {
        //    var tempList = [];
        //    tempList.push($scope.selectedAttr3Index);
        //    newJson.filters[$scope.lvl3Header] = tempList;
        //}
        //else {
        //    delete newJson.filters[$scope.lvl3Header];
        //}

        jsonXX = JSON.stringify(newJson.filters);
        console.log(jsonXX);

        //return false;
        GetAttributes(sector, superRegion, attributeIds, selectedStratumId, stratumId, RemainingStratumCount, locationIds);
        initfuncton();
        $scope.ClosePopup();

        return false;

        console.log(selectedFilterLevels);
        if (selectedFilterLevels.length < 2) {
            $scope.isShowPopup = false;
            $(".overlay-whbg").css("display", "none");
            return;
        }
        var tempCollectionFilterLevels = [];
        tempCollectionFilterLevels = $scope.collectionFilterLevels;

        var collectionFilterLevels = [];
        var rootLevel = _.where(selectedFilterLevels, { level: 0 });
        tempCollectionFilterLevels = _.filter(tempCollectionFilterLevels, function (o) { return o.StratumId != rootLevel[0].StratumId; });
        //console.log("tempCollectionFilterLevels",rootLevel, collectionFilterLevels, tempCollectionFilterLevels)

        for (i = 0; i < rootLevel.length; i++) {
            var stratumId = rootLevel[i].StratumId;
            var flag = true;
            var obj = rootLevel[i];
            obj.Levels = [];
            a = 0;
            tempStratumId = parseInt(stratumId);
            while (flag) {
                tempStratumId = parseInt(tempStratumId);
                tempArray = _.findWhere(selectedFilterLevels, { RefID: tempStratumId });
                //console.log("tempArray", tempArray)
                if (tempArray == undefined) {
                    flag = false;
                    break;
                }
                else {
                    tempArray.RootID = obj.StratumId;
                    obj.Levels.push(tempArray);

                    if (tempArray.StratumId == null) {
                        flag = false;
                    }
                    else {
                        tempStratumId = tempArray.StratumId;
                    }
                }
            }
            collectionFilterLevels.push(obj);
            // console.log("collectionFilterLevels", collectionFilterLevels)
        }

        tempCollectionFilterLevels.push(collectionFilterLevels[0]);

        $scope.collectionFilterLevels = tempCollectionFilterLevels;
        tempCollectionFilterLevels = [];
        setAttributeBucketIds();
        $scope.isShowPopup = false;
        $(".overlay-whbg").css("display", "none");

    }

    setAttributeBucketIds = function () {
        var tempCollectionFilterLevels = $scope.collectionFilterLevels;
        attrBuckets = "";
        selectedStratumIds = "";
        for (var i = 0; i < tempCollectionFilterLevels.length; i++) {
            len = tempCollectionFilterLevels[i].Levels.length;
            if (len > 0) {
                console.log(tempCollectionFilterLevels[i].Levels[len - 1].AttrBucket);
                attrBuckets += "," + tempCollectionFilterLevels[i].Levels[len - 1].AttrBucket;
                selectedStratumIds += "," + tempCollectionFilterLevels[i].Levels[len - 1].SelectedStratumIds;
            }
        }
        console.log(selectedStratumIds);
        attributeIds = attrBuckets;
        // console.log(attributeIds);
        $scope.attributeIds = attrBuckets;
        $scope.selectedStratumIds = selectedStratumIds;

        GetAttributes($scope.sector, $scope.superRegion, attrBuckets, selectedStratumIds, 0, 1, locationIds);
    }

    noDataFoundMsg = function (response) {
        if (response.length == 0) {
            $scope.loadingMsg = "No Data Found";
        }
        else {
            $scope.resultCount = response.length;
        }
    }

    deleteSelectedFilters = function (stratumId) {
        flag = true;
        console.log("deleteSelectedFilters", stratumId)
        while (flag) {
            tempStratumId = parseInt(stratumId);
            tempArray = _.findWhere(selectedFilterLevels, { RefID: tempStratumId });
            if (tempArray == undefined) {
                return;
            }
            selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.RefID != tempStratumId; });
            console.log("tempArray, selectedFilterLevels", tempArray, selectedFilterLevels);
            if (tempArray.StratumId == null) {
                flag = false;
            }
            else {
                tempStratumId = tempArray.RefID;
            }
        }

    }

    getRootLevel = function (level) {
        var root = _.findWhere($scope.collectionFilterLevels, { StratumId: level.RootID });
        return root;
    }

    $scope.getAllLocation = function () {
        $scope.isLocation = true;
        $scope.isShowPopup = true;

        $scope.isState = true;
        $scope.isCountry = true;
        $scope.isCounty = true;

        // Location
        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        var location = {};

        dashboardService.GetAttributeLevelFROMAPI(JSON.stringify(newJson)).then(function (response) {
            var locObj = response.responseEntity.locations;
            $scope.allCountries = locObj.Country[0].locations;
        });

        if ($scope.selectedCountry) {
            var tempList = [];
            tempList.push($scope.selectedCountry);
            location["Country"] = tempList;
            newJson["locations"] = location;
        }

        dashboardService.GetAttributeLevelFROMAPI(JSON.stringify(newJson)).then(function (response) {
            var locObj = response.responseEntity.locations;

            $scope.allStates = locObj.State[0].locations;
        });

        if ($scope.selectedState) {
            var tempList = [];
            tempList.push($scope.selectedState);
            location["State"] = tempList;
            newJson["locations"] = location;
        }

        dashboardService.GetAttributeLevelFROMAPI(JSON.stringify(newJson)).then(function (response) {
            var locObj = response.responseEntity.locations;
            $scope.allCounties = locObj.County[0].locations;
        });



    }
    /************************** BEGIN LOCATION *************************************/

    //$scope.locationLevel1 = [{ Id: 1, Country: "UNITED STATES" }];
    $scope.getCountries = function () {

        $scope.allCountries = [];
        $scope.isState = false;
        $scope.isCounty = false;
        $scope.allStates = [];
        $scope.allCounties = [];

        $scope.isCountry = true;

        $scope.selectedCountry = null;

        //Get From Filters

        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
        }

        params = params.substr(0, params.length - 1);
        params += '}}';
        var JsonObj = JSON.parse(params);
        JsonObj["location"] = true;
        JsonObj["reqAttList"] = [];
        searchService.GetAttributeLevel1(JSON.parse(params)).then(function (response) {

            var locObj = response.responseEntity.locations;

            $scope.allCountries = locObj.Country[0].locations;

        });


    }

    $scope.getStates = function (country) {

        $scope.isState = true;
        $scope.allStates = [];
        $scope.allCounties = [];

        $scope.selectedCountry = country;
        $scope.selectedState = null;
        $scope.selectedCounty = null;

        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        var location = {};

        if ($scope.selectedCountry) {
            var tempList = [];
            if ($scope.selectedCountry.indexOf(":") > -1)
                tempList.push($scope.selectedCountry);
            else
                tempList.push($scope.selectedCountry + ":" + $scope.selectedCountry);
            location["Country"] = tempList;
            newJson["locations"] = location;
        }

        dashboardService.GetAttributeLevelFROMAPI(JSON.stringify(newJson)).then(function (response) {
            var locObj = response.responseEntity.locations;
            $scope.allStates = locObj.State[0].locations;
        });

    }

    $scope.getCounty = function (state) {

        $scope.isCounty = true;
        $scope.allCounties = [];

        $scope.selectedState = state;
        $scope.selectedCounty = null;


        var newJson = {
            searchText: sText,
            filters: JSON.parse(jsonXX)
        };

        var location = {};

        if ($scope.selectedState) {
            var tempList = [];
            tempList.push($scope.selectedCountry);
            location["Country"] = tempList;
            tempList = [];
            tempList.push($scope.selectedState);
            location["State"] = tempList;
            newJson["locations"] = location;
        }

        dashboardService.GetAttributeLevelFROMAPI(JSON.stringify(newJson)).then(function (response) {
            var locObj = response.responseEntity.locations;
            $scope.allCounties = locObj.County[0].locations;
            //   $scope.allCounties = locObj.county.locationName;
        });

    }

    $scope.county = function (item) {
        $scope.selectedCounty = item;
    }

    $scope.selectLocation = function () {

        var finalLocationObj = {};




        //Check for Country
        if ($scope.selectedCountry) {
            console.log("$scope.selectedCountry", $scope.selectedCountry);
            var tempList = [];
            if ($scope.selectedCountry.indexOf(":") > -1)
                tempList.push($scope.selectedCountry);
            else
                tempList.push($scope.selectedCountry + ":" + $scope.selectedCountry);
            finalLocationObj["Country"] = tempList;
        }

        //Check for State
        if ($scope.selectedState) {
            var tempList = [];
            console.log("$scope.selectedState", $scope.selectedState);
            if ($scope.selectedState.indexOf(":") > -1)
                tempList.push($scope.selectedState);
            else
                tempList.push($scope.selectedCountry.split(":")[1] + ":" + $scope.selectedState);
            finalLocationObj["State"] = tempList;
        }

        //Check for County
        if ($scope.selectedCounty) {
            console.log("$scope.selectedCounty", $scope.selectedCounty);
            var tempList = [];
            if ($scope.selectedCounty.indexOf(":") > -1)
                tempList.push($scope.selectedCounty);
            else
                tempList.push($scope.selectedState.split(":")[1] + ":" + $scope.selectedCounty);

            finalLocationObj["County"] = tempList;
        }

        locationJson = JSON.stringify(finalLocationObj);
        console.info("finalLocationObj", finalLocationObj);
        //return false;
        GetAttributes(sector, superRegion, attributeIds, selectedStratumId, stratumId, RemainingStratumCount, locationIds);
        initfuncton();
        $scope.ClosePopup();

        return false;

        console.log($scope.Location);
        $scope.isShowPopup = false;
        attr = $scope.Location.AttrBucket;
        if (tempSelectedLocation.CountryId != 0) {
            $scope.Location = tempSelectedLocation;
            $scope.Location.AttrBucket = attr;
            $scope.sectorId = $scope.sector;
            $scope.superRegionId = $scope.superRegion;

            locationIds = $scope.Location.CountryId + ',' + $scope.Location.StateId + ',' + $scope.Location.CountyId;

            GetAttributes($scope.sector, $scope.superRegion, $scope.attributeIds, $scope.selectedStratumIds, 0, 1, locationIds);
        }
        console.log($scope.Location);
    }





    /************************** END LOCATION *************************************/
    /**************************************Filter POP UP ************************************/


    function getStratumName(stratumList, stratumData) {

        var filteredStratums = stratumList.filter(function (stratum) {
            return stratum.level <= 100;
        });

        var levelsArray = filteredStratums.map(function (stratum) {
            return stratum.level;
        });
        var maxLevelNumber = Math.max.apply(null, levelsArray);

        var stratumsWithHighLevel = filteredStratums.filter(function (stratum) {
            return stratum.level == maxLevelNumber;
        });

        if (stratumsWithHighLevel.length > 1) {

            //checking length of stratums stratumName
            var lengthsArray = stratumsWithHighLevel.map(function (stratum) {
                return stratumData[stratum.stratumName].length;
            });

            var maxLength = Math.max.apply(null, lengthsArray);

            var stratumWithHighLength = stratumsWithHighLevel.map(function (stratum) {
                return stratumData[stratum.stratumName].length == maxLength;
            });
            return stratumWithHighLength[0] || null;
        }
        else {
            return stratumsWithHighLevel[0] || null;
        }
    }



    $scope.ousideFn = function (parameter) {
        console.log("parameter", parameter);
    }



}]);

app.directive('chartSeriesModal', function ($compile, $parse, $http) {

    return {
        restrict: 'AE',

        link: function (scope, elem) {
            $('.modal-dialog').draggable({
                handle: ".modal-header"
            });
            scope.$watch("modalShow", function (nVal, oVal) {
                console.log("modalShow", nVal, oVal);
                if (nVal)
                    $(elem).modal("show");
            });

            $(elem).on('hidden.bs.modal', function () {
                // do something…

                scope.modalShow = false;
                scope.$apply();
            })
        }
    }
});
app.directive('test', function ($compile, $parse, $http) {

    return {
        restrict: 'AE',
        scope: {
            chartSeriesData: '=',
            divid: '@',
            sectorId: '=',
            attributes: '=',
            isFilter: '=',
            regionType: '=',
            detailId: '=',
            detail: '@',
            wholeData: '=',
            globalJsonObj: '='
        },
        templateUrl: '/Angular/directives/templates/dasboard-chart.html',
        controller: function ($scope) {
            $scope.seriesLimit = 6;
            $scope.selectedXaxis = "";
            $scope.selectedYaxis = [];
            $scope.selectedPivot = "";
            $scope.modeSelected = 0;
            $scope.modalShow = false;
            $scope.originalData = JSON.parse(JSON.stringify($scope.chartSeriesData));

            ///AddSeriesData


            //watchers

            $scope.$watch("modeSelected", function (nVal, oVal) {
                if (nVal != undefined) {

                    if (nVal == 1) {
                        var locationLevel = [];
                        for (var i = 0; i < $scope.chartSeriesData.length; i++) {
                            locationLevel.push($scope.chartSeriesData[i]["Location Level"]);
                        }
                        var count = {};
                        locationLevel.forEach(function (i) { count[i] = (count[i] || 0) + 1; });

                        var item = Object.keys(count).reduce(function (a, b) { return count[a] > count[b] ? a : b });
                        $scope.selectedXaxis = item;

                        $scope.Xaxis = locationLevel.unique();
                        filterData();
                        loadLocationSeries();
                        //loadChart(nVal);
                    }
                    else {
                        $scope.chartSeriesData = $scope.originalData;
                        var timeLevel = [];
                        for (var i = 0; i < $scope.chartSeriesData.length; i++) {
                            timeLevel.push($scope.chartSeriesData[i]["Time Level 2"]);
                        }
                        var count = {};
                        timeLevel.forEach(function (i) { count[i] = (count[i] || 0) + 1; });

                        var item = Object.keys(count).reduce(function (a, b) { return count[a] > count[b] ? a : b });
                        $scope.selectedXaxis = item;

                        $scope.Xaxis = timeLevel.unique();
                        loadUnits();
                        filterData();
                        loadChart(nVal);
                    }

                }
            });

            //series Filtered
            $scope.addSeriesData = $scope.wholeData.filter(function (item) {

                return myIndexOf($scope.chartSeriesData, item) == -1
            });

            //var buckets = GetBucketsNew($scope.addSeriesData);
            //console.log("buckets ", buckets);
            //var allChartDetails1 = [];
            //var bucketDetail = buckets.bucketDetail;
            //console.log("bucketDetail ", bucketDetail);
            //bucketDetail.forEach(function (bucketdet) {
            //    bucketdet.buckets.forEach(function (bucket) {
            //        var itemInfo = JSON.parse(bucket.key);
            //        console.log("itemInfo", itemInfo);

            //        var selectedKeys = Object.keys(buckets.topLevel);
            //        selectedKeys.forEach(function (key) {
            //            console.log("deleting keys ", key);
            //            delete itemInfo[key];
            //        });


            //        var copyMyStratum = JSON.parse(JSON.stringify(myStratumList));
            //        copyMyStratum.push({
            //            level: 50,
            //            parent: "NULL",
            //            stratumName: "country"
            //        }, {
            //            level: 51,
            //            parent: "country",
            //            stratumName: "state"
            //        }, {
            //            level: 52,
            //            parent: "state",
            //            stratumName: "county"
            //        });
            //        var arrayDifferent = makeString(itemInfo, copyMyStratum);
            //        allChartDetails1.push({ id: new IDGenerator().generate(), data: arrayDifferent.length > 0 ? arrayDifferent : ['SUMMARY'], meta: { seriesData: bucket.seriesIds, detail: bucketdet.detail } });

            //        console.log("arrayDifferent", arrayDifferent);
            //        var chartText = arrayDifferent.join(" | ") || "SUMMARY";


            //        var chartText = makeString(itemInfo, myStratumList).join(" | ") || "SUMMARY";
            //        console.log("chartText", chartText);
            //        console.log("bucketdet.detail", bucketdet.detail);
            //        console.log("maxStratum", maxStratum);
            //        if (!bucketdet.detail) {
            //            bucketdet.detail = maxStratum;
            //        }
            //    });
            //});


            //console.log("allChartDetails1", allChartDetails1);
            //var treeData = leftBarAlgorithm(allChartDetails1);
            ///
            $scope.showModal = function () {


                $scope.modalShow = true;
            }


            function loadUnits() {
                ///



                ///




                var locationLevel = [];

                $scope.selectedXaxis = "";
                $scope.selectedYaxis = [];
                $scope.selectedPivot = "";
                var unitdata = [];
                var timeLevel = [];

                var sourceData = [];
                for (var i = 0; i < $scope.chartSeriesData.length; i++) {
                    unitdata.push($scope.chartSeriesData[i]["0"]);
                    timeLevel.push($scope.chartSeriesData[i]["Time Level 2"]);
                    locationLevel.push($scope.chartSeriesData[i]["Location Level"]);
                    sourceData.push($scope.chartSeriesData[i]["Source of Data"]);
                }
                if ($scope.modeSelected == 1)
                    $scope.Xaxis = locationLevel.unique();
                else
                    $scope.Xaxis = timeLevel.unique();
                $scope.Yaxis = unitdata.unique();
                $scope.Pivot = sourceData.unique();

                ///selecting default values which has highest data 


                var unitsObj = { "0": [], "Time Level 2": [], "Location Level": [], "Source of Data": [] };
                $scope.chartSeriesData.forEach(function (item) {
                    Object.keys(unitsObj).forEach(function (key) {
                        unitsObj[key].push(item[key]);

                    });

                });

                var maxElemUnit = {};

                Object.keys(unitsObj).forEach(function (key) {
                    var count = {};
                    unitsObj[key].forEach(function (i) { count[i] = (count[i] || 0) + 1; });
                    var item = Object.keys(count).reduce(function (a, b) { return count[a] > count[b] ? a : b });

                    maxElemUnit[key] = item;
                });


                Object.keys(maxElemUnit).forEach(function (key) {

                    if (key == "0")
                        $scope.selectedYaxis.push(maxElemUnit[key]);
                    else if (key == "Time Level 2") {
                        if ($scope.modeSelected == 0) {
                            $scope.selectedXaxis = maxElemUnit[key];
                        }
                    }
                    else if (key == "Source of Data")
                        $scope.selectedPivot = maxElemUnit[key];
                    else if (key == "Location Level") {
                        if ($scope.modeSelected == 1) {
                            $scope.selectedXaxis = maxElemUnit[key];
                        }
                    }

                });
                console.log("$scope.selectedYaxis", $scope.selectedYaxis);
                //////
            }
            loadUnits();



            filterData();

            $scope.toShow = function (series) {
                $scope.tobeShowed.filter(function (seriesItem) {
                    if (seriesItem.seriesId == series.seriesId)
                        return true;
                    else
                        return false;
                });
                if ($scope.tobeShowed.length > 0) {
                    return true;
                }
                else
                    return false;
            }


            $scope.removeSeries = function (series) {

                series.show = !series.show;

                loadChart($scope.modeSelected);
            }

            function loadChart(locationType) {
                var filteredData = $scope.tobeShowed.filter(function (seriesItem) {
                    return true;
                });


                console.log("allFiltered Data is ", filteredData);
                GetChartData($scope.divid, $scope.sectorId, null, "", false, locationType, null, filteredData, $scope.detail, $scope.selectedYaxis, $scope.selectedXaxis);

            }


            $scope.changeDp = function (changedValue, selectedItem) {

                var getter = $parse(selectedItem);
                var setter = getter.assign;
                if (selectedItem == "selectedYaxis") {
                    var prevValue = getter($scope);

                    if (prevValue.indexOf(changedValue) > -1)
                        prevValue.splice(prevValue.indexOf(changedValue), 1);
                    else
                        prevValue.push(changedValue);
                    setter($scope, prevValue);
                }
                else {
                    setter($scope, changedValue);

                }


                filterData();
                loadChart($scope.modeSelected);
            }

            $scope.selectedRows = [];

            $scope.selectSeriesRow = function (seriesRow) {
                if ($scope.selectedRows.indexOf(seriesRow) == -1)
                    $scope.selectedRows.push(seriesRow);
                else
                    $scope.selectedRows.splice($scope.selectedRows.indexOf(seriesRow), 1);


                $scope.chartSeriesData = $scope.originalData;
                $scope.chartSeriesData = $scope.chartSeriesData.concat($scope.selectedRows);

                loadUnits();

                filterData();
                loadChart($scope.modeSelected);
            }



            $scope.filterSecId = function (items) {

                var result = {};
                angular.forEach(items, function (value, key) {

                    if (key != 'country' && key != 'state' && key != 'county' && key != 'dbName') {
                        result[key] = value;
                    }
                });

                return result;
            }




            function filterData() {
                $scope.tobeShowed = []

                $scope.chartSeriesData.forEach(function (series) {

                    var timeorlocation = ($scope.modeSelected == 1) ? "Location Level" : "Time Level 2";

                    if ($scope.selectedYaxis.indexOf(series["0"]) > -1 && series[timeorlocation] == $scope.selectedXaxis && series["Source of Data"] == $scope.selectedPivot) {
                        var copySeries = JSON.parse(JSON.stringify(series));
                        copySeries.show = true;
                        $scope.tobeShowed.push(copySeries);
                    }
                });
                console.log("filterData", $scope.chartSeriesData);
            }


            function loadLocationSeries() {

                var globalJson = JSON.parse($scope.globalJsonObj);

                var locOb = globalJson.locations;
                var locLevels = globalJson.locationLevels;
                var locationSelected = $scope.selectedXaxis;

                if (locationSelected == "STATE") {
                    delete locOb["State"];
                    delete locOb["County"];
                    delete locLevels["State"];
                    delete locLevels["County"];
                }
                if (locationSelected == "COUNTY") {

                    delete locOb["County"];

                    delete locLevels["County"];
                }
                if (locationSelected == "COUNTRY") {
                    delete locOb["Country"];
                    delete locOb["State"];
                    delete locOb["County"];
                    delete locLevels["State"];
                    delete locLevels["County"];
                    delete locLevels["Country"];
                }
                globalJson.locations = locOb;
                globalJson.locationLevels = locLevels;
                console.log("globalJson", globalJson);
                var req = {
                    method: 'POST',
                    url: 'http://54.71.24.240:9090/rest/zdaly/query-results',
                    data: JSON.stringify(globalJson)
                }
                var $currentChart = $("#" + $scope.divid);

                $currentChart.data("isload", true);
                var treeId = "#tree" + $("#chart-" + $scope.divid).data("tree");
                $(treeId).hide();
                $(treeId).parent().find(".tree-dp").hide();
                $("#chart-" + $scope.divid).show();
                $("#chart-" + $scope.divid).html($('#loader').html());

                $http(req).success(function (response) {

                    var results = response.responseEntity.results;
                    var dataTable = GetSeriesIdTable(results);
                    var filtered = dataTable.wholeData;
                    //var filtered = dataTable.wholeData.filter(function (item) {
                    //    return (item[$scope.detail]) ? true : false;

                    //});


                    if ($scope.detail == "county" || $scope.detail == "state") {

                        var newdetail = getStratumName(JSON.stringify(myStratumList), myStratum);

                    }
                    $scope.chartSeriesData = filtered;
                    console.log("$scope.chartSeriesData", $scope.chartSeriesData);
                    loadUnits();
                    filterData();
                    loadChart($scope.modeSelected);
                }).error(function (data) {
                    console.log("error", data);

                });
            }


            function myIndexOf(arr, o) {

                for (var i = 0; i < arr.length; i++) {
                    if (arr[i].seriesId == o.seriesId) {
                        return i;
                    }
                }

                return -1;
            }


        },

        link: function (scope, element, attrs) {

            GetChartData(scope.divid, scope.sectorId, null, "", false, 0, null, scope.chartSeriesData, scope.detail);



        }

    }

});

app.factory('dashboardService', ['$http', '$q', function ($http, $q) {

    var self = this;
    // var baseURL = "http://localhost:50138/api/"; //ngAuthSettings.apiServiceBaseUri;
    // self.AppBaseUrl = baseURL;
    /******************************************************************************************************************************/
    self.GetSearchResult = function (query) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetSearchResult',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "query": query }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocData = function (params, reqLocationLevels) {
        var defer = $q.defer();

        params["location"] = true;
        params["reqAttList"] = "";
        if (reqLocationLevels)
            params["locationLevels"] = reqLocationLevels;


        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetFiltersData = function (params, reqLocationLevels) {
        var defer = $q.defer();

        params["location"] = true;
        params["reqAttList"] = "";
        params["locationLevels"] = reqLocationLevels;

        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetAttributeLevel1 = function (params) {
        var defer = $q.defer();

        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.NewSearch = function (searchItem) {
        //console.log(searchItem);
        //return false;
        var defer = $q.defer();
        $http({
            url: '/New/SearchFilter',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: searchItem,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    /********************************************************LOCATION********************************************************************/
    self.GetAllLocation = function (locationObj) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAllLocation',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: locationObj,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetCountries = function (sector, superRegion, attributeIds) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCountries',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetStates = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetStates',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetCounties = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCounties',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    /********************************************************LOCATION********************************************************************/
    self.GetSearchResultsFromAPI = function (searchString) {
        var defer = $q.defer();

        searchString = searchString.toLowerCase();
        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/wilcard-search/' + searchString,
            method: "GET",
            headers: { 'Content-Type': 'application/json;charset=UTF-8', }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {

            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAttributeLevelFROMAPI = function (params) {
        var defer = $q.defer();

        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.RedirectToDashboard = function (sector, superRegion, selectedFilters, defautAttrs, searchResult, selectedFilterLevels, selectedLocation, sText, filterJsonString) {
        var defer = $q.defer();
        $http({
            url: '/New/dashboardFilter',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "selectionsAttrs": selectedFilters, "attributeIds": defautAttrs, "searchResult": searchResult, "selectedFilterLevels": selectedFilterLevels, "Location": selectedLocation, "sText": sText, "FilteredJsonString": filterJsonString },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLatestNews = function (searchQuery, country) {
        var defer = $q.defer();
        $http({
            url: '/New/GetLatestNews',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "searchQuery": searchQuery, "country": country },
        }).success(function (data, status, headers, config) {

            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    return self;
}]);