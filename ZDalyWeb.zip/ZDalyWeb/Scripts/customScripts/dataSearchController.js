﻿/// <reference path="D:\Projects\Zdaly\ZdalySolution\ZDalySolution\ZDalyWeb\Angular/partials/test/test1.html" />
/// <reference path="D:\Projects\Zdaly\ZdalySolution\ZDalySolution\ZDalyWeb\Angular/partials/test/test1.html" />
angular.module('underscore', []).factory('_', ['$window', function ($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);

//var app = angular.module('app', ['underscore', 'ui.autocomplete','ngRoute']);
var app = angular.module('app', ['underscore', 'ui.autocomplete']);

app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.useXDomain = true;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];
}
]);


app.directive('positionLast', function () {
    return {
        scope: true,
        link: function (scope, $element, attrs) {
            //if (scope.$last)
            {
                console.log(scope)
                // if jQuery is present use this, else adjust as appropriate
                $element.css("color", 'red');
                // $element.css("top", $scope.lastY + 'px');
            }
        }
    }
});

app.filter('checkIfEmpty', function () {

    return function (original, replacement) {
        if (original != "") {
            return original;
        }
        else {
            return replacement;
        }
    }

});
app.filter('replacePipe', function () {

    return function (original) {
        var newOrig = original.split("|");
        newOrig = newOrig.filter(function (item) {
            return (item) ? true : false;

        }).map(function (item) {
            return capitalizeFirstLetter(item.toLowerCase());
        });
        return newOrig.join(", ");
    }

});


function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}
app.controller('searchController', ['$scope', '$parse', '$compile', 'searchService', '_', '$timeout', function ($scope, $parse, $compile, searchService, _, $timeout) {
    console.log("search trl initialize ");
    $scope.locationLevel1 = []; $scope.locationLevel2 = []; $scope.locationLevel3 = [];
    $scope.attrLevel1 = []; $scope.attrLevel2 = []; $scope.attrLevel3 = [];
    $scope.selectedStateIndex = -1; $scope.selectedCountryIndex = -1; $scope.selectedCountyIndex = -1;
    $scope.selectedLocation = ""; $scope.temSelectedLocation = {};
    $scope.Filtersloading = false;
    /*** Search Text Param from Index Autocomplete select**/
    $scope.sector = 0;
    $scope.superRegion;
    $scope.sectorTxt = "";
    $scope.superRegionTxt = "";
    $scope.attributeids = ""
    $scope.subSectorId;
    $scope.subSector;
    $scope.entryId = 1;
    $scope.lastLevels = [];
    $scope.stratumList = null;
    /**  Search Text ***/

    $scope.regionId = 0; $scope.stratumId = 1;

    $scope.isLocation = false;
    $scope.isState = false; $scope.isCountry = false; $scope.isCounty = false; $scope.isPopupLocation = false;
    $scope.isPopupIndustry = false; $scope.isPopupOccupations = false;
    $scope.isAttr2 = false; $scope.isAttr3 = false;
    $scope.Commodity = {};
    $scope.Filters = [];
    $scope.selectedFilters = [];
    selectedFilters = [];
    var filters = [];
    var filterData = null;
    var selectedAttrBucketIds = "";
    var filterSelectionAttrData = []; // stratumId,selectedStratumIds,selectedAttrBucket
    $scope.overlay = false;
    $scope.Entry = "";
    $scope.AllSectors = [];
    $scope.superRegions = [];
    $scope.resultCount = 1200;
    $scope.selectedSector = {};
    $scope.selectedSuperRegion = {};
    $scope.currentSelectedFilterData = {};

    $scope.isSearchFilter = false;
    $scope.isSearchResult = false;
    $scope.searchResults = [];

    var selectedFilterLevels = [];

    var searchResult = {};
    var finalFilters = [];
    var finalFilterObj = {};
    var finalLocationObj = {};
    ///////////////////////////////////  SERACH REDIRECT 
    var data1 = searchFilterData;
    data1.sector = data1.sector.replace(/&amp;/g, '&');
    data1.superRegion = data1.superRegion.replace(/&amp;/g, '&');
    data1.subSector = data1.subSector.replace(/&amp;/g, '&');
    data1.sText = data1.sText.replace(/&amp;/g, '&');
    $scope.TOPSELECTIONS = [];
    console.log("searchFilterData", searchFilterData);
    $scope.selectedFilter = null;


    $scope.pushToAry = function (name, val) {

        if (name == "Loading.." || typeof name == 'undefined' || val == null) {
            return false;
        }

        var tempList = [];
        tempList.push(val);
        finalFilterObj[name] = tempList;

    }

    if (data1.SectorId != 0) {

        $scope.sector = data1.SectorId;
        $scope.superRegion = data1.SuperRegionId;
        $scope.sectorTxt = data1.sector.replace(/&amp;/g, '&');
        $scope.superRegionTxt = data1.superRegion.replace(/&amp;/g, '&');
        $scope.attributeIds = data1.AttrBucket;
        $scope.subSectorId = data1.subSectorId;
        $scope.subSector = data1.subSector.replace(/&amp;/g, '&');
        $("#c_tag").val($scope.sector);
        $scope.sText = data1.sText.replace(/&amp;/g, '&');
        console.log("$scope.sText", $scope.sText.replace(/&amp;/g, '&'));
        $scope.stratumName = data1.stratumName;
        console.log(data1.sText);
        $scope.Filtersloading = true;
        $scope.isSearchFilter = true;
        $scope.isSearchResult = false;

        $scope.pushToAry("Sector", data1.sector);
        $scope.pushToAry("Sub-Sector", data1.subSector);
        // $scope.pushToAry(data1.stratumName, data1.sText);
        //  finalLocationObj["Country"] = '["null:"' + data1.superRegion + ']';
        //   console.warn("this executes");

        ////Jaswinder code
        console.log("data1.superRegion", data1.superRegion);
        if (data1.superRegion) {
            var locationObj = {
                Country: [data1.superRegion + ":" + data1.superRegion]
            }
        }
        else {
            var locationObj = {
                Country: ["null:United States"]
            }
        }
        //////
        searchService.GetFilterTypes($scope.sectorTxt, $scope.superRegion, $scope.subSector, 0, $scope.entryId, $scope.sText, $scope.stratumName, locationObj).then(function (response) {
            console.warn("populating stratum", response.responseEntity.stratumList);
            if (!$scope.stratumList || $scope.stratumList.length == 0 || response.responseEntity.stratumList.length > 0) {
                $scope.stratumList = response.responseEntity.stratumList;
            }

            var pData = _.filter(response.responseEntity.stratumList, function (o) { return o.level < 100; });
            //var pData = response.responseEntity.stratumList;
            console.log("pData", pData);
            var origData = response.responseEntity.stratum;

            var redifenedRes = [];
            var index = 1;
            for (var i = 0; i < pData.length; i++) {

                if (pData[i].parent == "NULL" || pData[i].parent == "Sub-Sector") {

                    if (pData[i].stratumName != "Sector") {

                        console.log("filters", pData[i].stratumName);
                        var cStratum = $scope.checkForFilter(origData, pData[i].stratumName, pData);

                        if (cStratum != "") {
                            redifenedRes.push({
                                Id: index,
                                Stratum: cStratum
                            });
                            index++;
                        }
                    }
                }
            }

            redifenedRes.push({
                Id: 0,
                Stratum: "Location"
            });
            console.log("$scope.TOPSELECTIONSNew, response.responseEntity.stratumList", $scope.TOPSELECTIONSNew, response.responseEntity.stratumList);
            if ($scope.TOPSELECTIONSNew) {
                var op = makeString($scope.TOPSELECTIONSNew, response.responseEntity.stratumList);
                op.forEach(function (item) {

                    var stratumObj = { Stratum: item.stratum, Id: Math.random(), text: item.text, AttrBucket: "", selectedStratumIds: "" };
                    $scope.selectedFilters.push(stratumObj);
                    console.warn("Pushing", stratumObj);
                });
            }

            //$scope.TOPSELECTIONS.forEach(function () {

            //});

            $scope.Filters = redifenedRes;
            filters = response.responseEntity.stratumList;
            filterData = response.responseEntity;
            $scope.Filtersloading = false;
        });
    }
    else {
        //console.log("sector 00", data1.sector);
        if (data1.sector) {

            $scope.isSearchResult = false;
            searchService.GetSearchResultsFromAPI(data1.sector).then(function (res) {

                var result = [];
                if (res) {

                    angular.forEach(res.responseEntity.searchResponse, function (item) {
                        var jsonObj = {
                            sector: item.sector,
                            subSector: item.subSector,
                            superRegion: item.superRegion,
                            sectorId: 1,
                            subSectorId: item.SubSectorId,
                            superRegionId: item.SuperRegionId,
                            AttrBucket: item.AttrBucket,
                            stratumName: item.stratumName
                        }

                        staticSecFields = _.where(sectorModals, { Id: 1 });
                        jsonObj.cssClass = staticSecFields[0].cssClass;
                        jsonObj.image = staticSecFields[0].image;

                        result.push({
                            data: jsonObj,
                            value: item.suggestionString
                        });
                    });

                }
                $scope.isLoading = false;
                $scope.searchResults = result;
                $scope.isSearchResult = true;
            }, function () {
                $scope.isLoading = false;
            });
        }
    }



    ///////////////////nEW lOCATION cODE//////////////
    $scope.prevLocSelected = [];
    $scope.locationLevels = [];
    $scope.locationSelected = null;

    $scope.selectedLocationLevels = null;
    $scope.$watch("isSearchFilter", function (nVal, oVal) {
        if(nVal != undefined)
        {
            if ($scope.isSearchFilter) {
                OnInitLocationCheck();
            }
        }
    });
    

    function OnInitLocationCheck() {
        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key.replace(/&amp;/g, '&') + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);
        params += '}}';


        var jsonObj = JSON.parse(params);
        searchService.GetLocData(jsonObj).then(function (data) {
            $scope.locLoader = false;
            var locations = data.responseEntity.locations;
            console.log("locations", locations);
           
            if (Object.keys(locations).length == 1 && Object.keys(locations)[0].toLowerCase()!="country") {

                var locName = Object.keys(locations)[0];
                var locItem = locations[locName][0];
                console.log("loc item is ", locItem);
                if (locItem.locations.length == 1) {
                    var locParent = locItem.locationParent;
                    var locVal = locItem.locations[0];
                    var locationObj = {};
                    locationObj[Object.keys(locations)[0]] = [locParent + ":" + locVal];
                    finalLocationObj = locationObj;

                    var locationLevel = {};
                    locationLevel[Object.keys(locations)[0]]=1

                    $scope.reqlocationLevels = locationLevel;

                    console.log("locationObj", locationObj);
                    console.log("loc", locations[0]);

                    var textArray = [];
                    console.log("finalLocationObj", finalLocationObj);

                    Object.keys(finalLocationObj).forEach(function (key) {
                        textArray.push(finalLocationObj[key][0].split(":")[1]);
                    });
                    console.log("textArray", textArray);
                    $scope.selectedFilters.push({ Stratum: "Location", Id: 0, text: textArray.reverse().join(","), AttrBucket: "", selectedStratumIds: "" });

                    var index = $scope.Filters.indexOf($scope.locationSelected);
                    $scope.Filters.splice(index, 1);
                    $scope.selectedLocationLevels = $scope.locationLevels;

                }

                
            }
            

          
        });
    }




    $scope.getLocationFilter = function (passedEventObject) {
        var top = $(passedEventObject.currentTarget).offset().top;
        var subTop = $('#filters_container').offset().top;

        $(".popup-pointer").css({ top: (top - subTop) + 'px' });
        $("#filters_container").show();
        $scope.locLoader = true;
        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key.replace(/&amp;/g, '&') + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);
        params += '}}';


        var jsonObj = JSON.parse(params);
        searchService.GetLocData(jsonObj).then(function (data) {
            $scope.locLoader = false;
            var locations = data.responseEntity.locations;
            if (Object.keys(locations).length == 1) {
                var key = Object.keys(locations)[0];
                var locationData = [];
                locations[key].forEach(function (location) {
                    locationData = locationData.concat(location.locations);
                });


                //var locationData = locations[key].map(function (location) {
                //    return location.locations.join(",");

                //});
                console.log("locationData", locationData);
                $scope.locationLevels.push({
                    headerText: key,
                    data: locationData
                });
            }
            else {
                $scope.locationLevels.push({
                    headerText: "SelectLevel",
                    data: Object.keys(locations)
                });
            }

            console.log("Location Data ", data);
        });

    }
    $scope.locationCounter = 0;

    $scope.closeLocationPopup = function (isNullify) {
        console.log("isNullify", isNullify);

        if (isNullify)
        {
            finalLocationObj = {};
            $scope.reqlocationLevels = null;
        }
           
        else {
            var textArray = [];
            console.log("finalLocationObj", finalLocationObj);

            Object.keys(finalLocationObj).forEach(function (key) {
                textArray.push(finalLocationObj[key][0].split(":")[1]);
            });
            console.log("textArray", textArray);
            $scope.selectedFilters.push({ Stratum: "Location", Id: 0, text: textArray.reverse().join(","), AttrBucket: "", selectedStratumIds: "" });

            var index = $scope.Filters.indexOf($scope.locationSelected);
            $scope.Filters.splice(index, 1);
            $scope.selectedLocationLevels = $scope.locationLevels;
        }
        $scope.locationLevels = [];
        $scope.locationSelected = null;
        $scope.selectedFilter = null;

    }
     
    $scope.getNextLevel = function (header, selectedItem, level, levelIndex) {
        console.log("levelIndex", levelIndex);
        if (selectedItem == level.selectedItem || $scope.locLoader) {

            return false;
        }
          
      
        //if (header != "SelectLevel") {
        //    selected
        //}


        var newSelection = { header: header, selectedItem: selectedItem };




        console.log("$scope.locationLevels.length-1", $scope.locationCounter);
        if (levelIndex < $scope.locationCounter) {
            var splicedLevels = $scope.locationLevels.splice(levelIndex + 1, $scope.locationLevels.length);

            $scope.prevLocSelected.splice(levelIndex, $scope.prevLocSelected.length);
            $scope.locationCounter = levelIndex;
        }
        
        $scope.prevLocSelected.push(newSelection);

        
        console.log("$scope.prevLocSelected", $scope.prevLocSelected);
        $scope.currentLevelIndex = levelIndex;

        level.selectedItem = selectedItem;

        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key.replace(/&amp;/g, '&') + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);
        params += '}}';


        var jsonObj = JSON.parse(params);

        var prevSelectedLocs = $scope.prevLocSelected.filter(function (prevLoc) {
            return (prevLoc.header != "SelectLevel");

        });
        var locationObj = {};

        var locTemp = {};

        prevSelectedLocs.forEach(function (locItem, index) {
            if (index == 0) {
                locationObj[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
                locTemp[locItem.header] = [locItem.selectedItem + ":" + locItem.selectedItem];
                
            }
            else {
                locationObj[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];

                locTemp[locItem.header] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                
                if (selectedItem.toLowerCase() == "overall") {
                    var prevUnselected = $scope.locationLevels.filter(function (locLevel) {
                        return (locLevel.headerText == "SelectLevel")

                    });
					   if (prevUnselected.length != 0) {
                    var lastPrevSelected = prevUnselected[prevUnselected.length - 1];
                    lastPrevSelected.data.forEach(function (levelText) {
                        locationObj[levelText] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                    });

                    console.log("lastPrevSelected", lastPrevSelected);
					   }
                }

            }
        });
        console.log("locationObj", locationObj);
        finalLocationObj = locationObj;
        jsonObj["locations"] = locationObj;
        var locationLevel = {};
        Object.keys(locTemp).forEach(function (key, index) {
            locationLevel[key] = index + 1;
        });
      var wildcardSelected=  Object.keys(locationObj).filter(function (key) {
            var locTempKeys = Object.keys(locationLevel);
              return (locTempKeys.indexOf(key)==-1)
      });
      console.log("wildcardSelected", wildcardSelected);
      wildcardSelected.forEach(function (key) {
          console.log("wildcardSelected key", key);
          locationLevel[key] =Object.keys(locTemp).length;
          console.log("locationLevel", locationLevel);
      });


      jsonObj["locationLevels"] = locationLevel;
      $scope.reqlocationLevels = locationLevel;
        console.log("jsonObj", jsonObj);

        if (header == "SelectLevel") {
            $scope.locLoader = true;
            searchService.GetLocData(jsonObj).then(function (data) {
                var locations = data.responseEntity.locations;

                var locationData = [];
                locations[selectedItem].forEach(function (location) {
                    locationData = locationData.concat(location.locations);
                });

                console.log("locationDataIn loop", locationData);
                $scope.locationLevels.push({
                    headerText: selectedItem,
                    data: locationData
                });
                $scope.locLoader = false;
                //if (Object.keys(locations).length == 1) {
                //    var key = Object.keys(locations)[0];
                //    var locationData = locations[key].map(function (location) {
                //        return location.locations.join(",");

                //    });
                //    console.log("locationData", locationData);
                //    $scope.locationLevels.push({
                //        headerText: key,
                //        data: locationData
                //    });
                //}
                //else {
                //    $scope.locationLevels.push({
                //        headerText: "SelectLevel",
                //        data: Object.keys(locations)
                //    });
                //}

                //console.log("Location Data ", data);
                console.log("scroll width");
                console.log($(".row-horizon")[0].scrollWidth);
                setTimeout(function () {
                    $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 900);
                }, 200);

                
            });
        }

        else {
            $scope.locLoader = true;

            searchService.GetLocData(jsonObj).then(function (data) {
                $scope.locLoader = false;
                var locations = data.responseEntity.locations;
                if (Object.keys(locations).length == 1) {
                    var key = Object.keys(locations)[0];
                   var prevSelcted= $scope.prevLocSelected.map(function (prevSelected) {
                        if (prevSelected.header.toLowerCase() == key.toLowerCase()) {
                            return true;
                        }
                    });
                   if (locations[key].length > 0 && prevSelcted.length==0) {
                        var locationData = locations[key].map(function (location) {
                            return location.locations.join(",");

                        });
                        console.log("locationData", locationData);
                        $scope.locationLevels.push({
                            headerText: key,
                            data: locationData
                        });
                    }
                  
                }
                else {
                    console.log("$scope.prevLocSelected", $scope.prevLocSelected);
                    var nonEmpty = Object.keys(locations).filter(function (key) {
                        return locations[key].length > 0;
                    });

                    var showSlections = nonEmpty.filter(function (key) {
                        var found = true;
                        $scope.prevLocSelected.forEach(function (prevSelected) {
                            console.log("prevSelected", prevSelected);
                            console.log("key", key);
                            if (prevSelected.header.toLowerCase() == key.toLowerCase()) {
                                found = false;
                            }
                        });

                        return found;
                    });
                    if (showSlections.length == 1) {


                        var locationData = [];
                        locations[showSlections[0]].forEach(function (location) {
                            locationData = locationData.concat(location.locations);
                        });
                        //var showData = locations[showSlections[0]];
                        console.log("showData", locationData);
                        $scope.locationLevels.push({
                            headerText: showSlections[0],
                            data: locationData
                        });
                    }


                    else if (showSlections.length > 1) {
                        $scope.locationLevels.push({
                            headerText: "SelectLevel",
                            data: showSlections
                        });
                    }
                    else {
                        //$scope.prevLocSelected.pop(newSelection);
                    }

                }
                console.log("scroll width");
                console.log($(".row-horizon")[0].scrollWidth);
                setTimeout(function () {
                    $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 800);

                }, 200);

                console.log("Location Data ", data);
            });
        }

        $scope.locationCounter++;
        
    }








    ///////////////////////////////////////
    $scope.SelectedStratumFilterIds = "";
    $scope.searchNotFound = null;
    $scope.myOption1 = {
        options: {
            //appendTo: "#inner-c-tags",
            html: true,
            focusOpen: false,
            onlySelectValid: true,
            minLength: 3,
            delay: 600,
            search: function (event, ui) {
                window.pageIndex = 0;
            },
            source: function (request, response) {
                if ($scope.isSearchFilter) {

                    $scope.isSearchFilter = false;
                }
                $scope.isSearchResult = false;
                $scope.TOPSELECTIONSNew = {};
                finalFilterObj = {};
                $scope.selectedFilters = [];
                console.info("text changed ", request.term);
                // $scope.isSearchResult = true;              
                searchService.GetSearchResultsFromAPI(request.term).then(function (res) {
                    var result = [];
                    if (res) {
                        $scope.isSearchResult = true;
                        angular.forEach(res.responseEntity.searchResponse, function (item) {


                            var jsonObj = {
                                sector: item.sector,
                                subSector: item.subSector,
                                superRegion: item.superRegion,
                                sectorId: 1,
                                subSectorId: item.SubSectorId,
                                superRegionId: item.SuperRegionId,
                                AttrBucket: item.AttrBucket,
                                stratumName: item.stratumName
                            }

                            staticSecFields = _.where(sectorModals, { Id: 1 });
                            jsonObj.cssClass = staticSecFields[0].cssClass;
                            jsonObj.image = staticSecFields[0].image;

                            result.push({
                                data: jsonObj,
                                value: item.suggestionString
                            });

                        });
                    }
                    console.log(res);

                    if (!$scope.isSearchFilter) {
                        $scope.searchResults = result;
                    }

                    //console.log("SearchResult", result, res)
                    response([])
                    //response(result);
                });

            },
            select: function (event, ui) {
                $scope.isSearchResult = true;
                //var data = ui.item.data;
                //searchResult = data;
                //console.log(ui.item);
                //$scope.sector = data.sectorId;
                //$scope.superRegion = data.superRegionId;
                //$scope.attributeIds = data.AttrBucket;
                //$scope.subSectorId = data.subSectorId;
                //$scope.subSector = data.subSector;
                //$scope.sectorTxt = data.sector;
                //$scope.superRegionTxt = data.superRegion;
                // GetFilters();
                //if ($scope.SearchType.toLowerCase() != "location") {
                //    var str = $(ui.item.label).text().split(/in/)[1];
                //    str = str.toString().substring(0, str.lastIndexOf(","));
                //    str = str + "@#$" + value;

                //    $scope.ActiveSelectedCommodity(str, level, event);
                //}
                //else {
                //    var str = $(ui.item.label).text();
                //    $scope.ActiveSelectedSearch(str, level, event);
                //}
                //event.stopPropagation();
            },
        },
        methods: {},
    }

    $scope.getFilterBySearchResult = function (saerchObj, sText) {

        var data = saerchObj;
        console.log(sText);
        searchResult = data;
        $scope.sector = data.sectorId;
        $scope.superRegion = data.superRegionId;
        $scope.attributeIds = data.AttrBucket;
        $scope.subSectorId = data.subSectorId;
        $scope.subSector = data.subSector;
        $scope.sectorTxt = data.sector;
        $scope.superRegionTxt = data.superRegion;
        $scope.sText = sText;
        $scope.stratumName = data.stratumName;

        $scope.pushToAry("Sector", data.sector);
        $scope.pushToAry("Sub-Sector", data.subSector);
        // $scope.pushToAry(data.stratumName, sText);

        GetFilters();
        $scope.isSearchFilter = true;
        $scope.isSearchResult = false;
    }



    var sectorModals = [{ Id: 1, modal: 'agrimodal', cssClass: 'agriculture', image: "snav-agrico.png" }, { Id: 2, modal: 'educationmodal', cssClass: 'education_box', image: "snav-eduico.png" }];

    //$scope.Commodity = { Entry: "Fruits and Nuts", LevelId: 1 }

    // Initial Call Get Commodity

    // Get Sectors all
    searchService.GetAllSectors().then(function (response) {
        //console.log(response);
        sector = {};
        sectors = [];
        angular.forEach(response, function (value, index) {
            //console.log(value)
            id = value.Id;
            staticSecFields = _.where(sectorModals, { Id: id });
            //console.log(staticSecFields[0].cssClass)
            sectors.push({ Id: value.Id, Name: value.Name, modal: staticSecFields[0].modal, cssClass: staticSecFields[0].cssClass })
        });

        $scope.AllSectors = sectors;
        //console.log($scope.AllSectors)
    });

    $scope.getSuperRegion = function (sector) {
        $scope.selectedSecor = sector;
        // Reson: getting Duplicate records from DB
        $scope.superRegions = [{ SuperRegionId: 1, SuperRegion: 'United States' }, { SuperRegionId: 2, SuperRegion: 'India' }];
    }
    $scope.selectSupeRegion = function (region) {
        $("#superRegionModal").modal("hide");
        $scope.selectedSuperRegion = region;
    }

    //searchService.GetAttributeLevel1($scope.stratumId, 1, $scope.attributeIds).then(function (response) {
    //    console.log(response);
    //    $scope.Commodity = response[0];
    //});

    GetFilters = function () {
        console.log("in Get Filters ");
        $scope.selectedFilters = [];
        $scope.Filtersloading = true;
        $scope.Filters = [];

        for (var i = 0; i < $scope.TOPSELECTIONS.length; i++) {
            $scope.removeFromAry($scope.TOPSELECTIONS[i].stratum);
        }

        $scope.TOPSELECTIONS = [];
        searchService.GetFilterTypes($scope.sectorTxt, $scope.superRegion, $scope.subSector, 0, $scope.entryId, $scope.sText, $scope.stratumName).then(function (response) {
            console.warn("populating stratum", response.responseEntity.stratumList);
            if (!$scope.stratumList || response.responseEntity.stratumList.length > 0) {
                $scope.stratumList = response.responseEntity.stratumList;
            }

            $scope.topLevelStratums = [];
            var pData = _.filter(response.responseEntity.stratumList, function (o) { return o.level < 100; });
            console.log(response.responseEntity);
            var origData = response.responseEntity.stratum;

            var redifenedRes = [];
            var index = 1;
            for (var i = 0; i < pData.length; i++) {

                if (pData[i].parent == "NULL" || pData[i].parent == "Sub-Sector") {

                    console.log("pData[i] in", pData[i]);
                    if (pData[i].stratumName != "Sector") {

                        var cStratum = $scope.checkForFilter(origData, pData[i].stratumName, pData);

                        if (cStratum != "") {
                            redifenedRes.push({
                                Id: index,
                                Stratum: cStratum
                            });
                            index++;
                        }

                    }
                }
            }


            //Push Static Location
            redifenedRes.push({
                Id: 0,
                Stratum: "Location"
            });

            ////Addtional Check for location
            //var lObj = response.responseEntity.locations;
            //lObj.country.location
            //    //$scope.Country = 

            if ($scope.TOPSELECTIONSNew) {
                var op = makeString($scope.TOPSELECTIONSNew, response.responseEntity.stratumList);
                op.forEach(function (item) {

                    var stratumObj = { Stratum: item.stratum, Id: Math.random(), text: item.text, AttrBucket: "", selectedStratumIds: "" };
                    $scope.selectedFilters.push(stratumObj);

                });
            }


            $scope.Filters = redifenedRes;
            filters = response.responseEntity.stratumList;
            filterData = response.responseEntity;

            $scope.Filtersloading = false;
        });
    }

    //searchService.GetCountries($scope.sector, $scope.superRegion, $scope.attributeIds).then(function (response) {
    //    console.log(response);
    //    $scope.locationLevel1 = response;
    //})

    // END Initial Call

    $scope.selectFilterType = function (filter) {

    }
    $scope.selectedStratumIds = 0; $scope.remainingStratumCount = 1;
    $scope.selectedFilterIndex = -1;
    $scope.loadingMsg = "";
    // first Level 1
    $scope.getFilterData = function (filter, index, passedEventObject) {
        $scope.selectedFilter = filter;
        if (filter.Id == 0) {
            $scope.locationSelected = filter;
            $scope.getLocationFilter(passedEventObject);
            return false;
        }



        console.log(passedEventObject);
        $scope.selectedAttr2Index = -1; $scope.selectedAttr1Index = -1; $scope.selectedAttr3Index = -1;
        $("#filters_container").show();

        var top = $(passedEventObject.currentTarget).offset().top;
        var subTop = $('#filters_container').offset().top;

        $(".popup-pointer").css({ top: (top - subTop) + 'px' });

        $scope.overlay = true;
        $scope.selectedFilterIndex = filter.Id;

        if (filter.Id === 0) { } // Location
        else
        {
            if (selectedFilterLevels.length > 0) {
                selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== filter.Id; });

                deleteSelectedFilters(filter.Id);
            }
            selectedFilterLevels.push({ StratumId: filter.Id, HeaderName: filter.Stratum, Entry: '', SelectedStratumIds: filter.Id, AttrBucket: $scope.attributeIds, RefID: 0, level: 0 })
        }

        console.log("filter", filter)

        $scope.loadingMsg = "Loading. . .";
        if (filter.Id == 0)//Location
        {
            $scope.getCountries();
        }
        else {
            $scope.attrLevel1 = [];
            $scope.isAttr2 = false; $scope.isAttr3 = false;
            $scope.stratumId = filter.Id;
            $scope.selectedStratumIds = $scope.stratumId;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { ';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key.replace(/&amp;/g, '&') + '" : ["' + finalFilterObj[key] + '"],';
                }

            }

            params = params.substr(0, params.length - 1);
            params += '}}';


            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }
          
            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {

                var child = filter.Stratum;
                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == child });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: filter.Stratum,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel1 = list;
                $scope.level1Header = filter.Stratum;

            });


        }
    }

    function noDataFoundMsg(response) {
        if (response.length == 0) {
            $scope.loadingMsg = "No Data Found";
        }
        else {
            $scope.resultCount = response.length;
        }
    }

    $scope.selectedAttr1Index = -1; $scope.selectedAttr2Index = -1; $scope.selectedAttr3Index = -1;
    var selectedAttrLevels = "";
    var selectedAtr1 = "", selectedAtr2 = "", selectedAtr3 = "", selectedAtr4 = "", selectedAtr5 = "", selectedAtr6 = "", selectedAtr7 = "", selectedAtr8 = "", selectedAtr9 = "", selectedAtr10 = "", selectedAtr11 = "", selectedAttrIds1 = "", selectedAttrIds2 = "", selectedAttrIds3 = "", selectedAttrIds4 = "", selectedAttrIds5 = "", selectedAttrIds6 = "", selectedAttrIds7 = "", selectedAttrIds8 = "", selectedAttrIds9 = "", selectedAttrIds10 = "", selectedAttrIds11 = "";

    $scope.getAttrLevel2 = function (level, index) {
        $scope.level1Value = level.Entry;
        console.log("level.Child", level.Child);
        if (level.Child == "NONE") {
            $scope.selectedAttr1Index = index;
            return false;
        }
        $scope.level2Header = "Loading..";
        $scope.level1Value = level.Entry;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 1;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        selectedAtr1 = level.Entry;
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
        selectedAttrLevels = selectedAtr1;
        selectedAttrBucketIds = level.AttrBucket;
        selectedAttrIds1 = selectedAttrBucketIds;
        $scope.selectedAttr2Index = -1; $scope.selectedAttr1Index = -1;
        $scope.selectedAttr3Index = -1;
        $scope.selectedAttr1Index = index; $scope.isAttr2 = true;

        $scope.loadingMsg = "Loading. . .";
        $scope.attrLevel2 = [];
        $scope.attrLevel3 = [];
        $scope.level3Value = null;
        $scope.level2Value = null;
        console.log("startum id ", level.StratumId);
        if (level.StratumId != null) {
            $scope.selectedStratumIds = level.SelectedStratumIds;//_.uniq(level.SelectedStratumIds.split(',')).join(',');
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }
            jsonObj["location"] = true;
            jsonObj["reqAttList"] = "";
            console.log("Json Obj ", jsonObj);
            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                console.log("attr leve 1 ", response);
                var child = level.Child;
                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Child });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel2 = list;
                $scope.level2Header = child;

            });
        }
        else {
            $scope.attrLevel2 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        //$scope.attrLevel2 = [{ Id: 1, Attribute1: "Field Crop2" }, { Id: 2, Attribute1: "Economy2" }, { Id: 3, Attribute1: "Agricultre2" }];
    }

    $scope.getAttrLevel3 = function (level, index) {
        console.log("selecting level 2 ", level);
        $scope.level2Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr2Index = index;
            return false;
        }
        $scope.level3Header = "Loading..";


        console.log("$scope.level2Value", $scope.level2Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 2;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr2Index = -1;
        $scope.selectedAttr3Index = -1;
        $scope.selectedAttr2Index = index;

        console.log(level);

        $scope.attrLevel3 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel3 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr2 = level.Entry;
            selectedAttrLevels = selectedAtr2 + ", " + selectedAttrLevels;
            selectedAttrIds2 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr3 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel3 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level3Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel3 = list;
                $scope.level3Header = child;

            });
        }
        // $scope.attrLevel3 = [{ Id: 1, Attribute1: "Field Crop2" }, { Id: 2, Attribute1: "Economy2" }, { Id: 3, Attribute1: "Agricultre2" }];
    }


    $scope.getAttrLevel4 = function (level, index) {
        console.log("selecting level 3 ", level);
        $scope.level3Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr3Index = index;
            return false;
        }
        $scope.level4Header = "Loading..";


        console.log("$scope.level3Value", $scope.level3Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 3;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr3Index = -1;
        $scope.selectedAttr4Index = -1;
        $scope.selectedAttr3Index = index;

        console.log(level);

        $scope.attrLevel4 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel4 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr3 = level.Entry;
            selectedAttrLevels = selectedAtr3 + ", " + selectedAttrLevels;
            selectedAttrIds3 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr4 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel4 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level4Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel4 = list;
                $scope.level4Header = child;

            });
        }
        // $scope.attrLevel4 = [{ Id: 1, Attribute1: "Field Crop3" }, { Id: 3, Attribute1: "Economy3" }, { Id: 4, Attribute1: "Agricultre3" }];
    }




    $scope.getAttrLevel5 = function (level, index) {
        console.log("selecting level 4 ", level);
        $scope.level4Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr4Index = index;
            return false;
        }
        $scope.level5Header = "Loading..";


        console.log("$scope.level4Value", $scope.level4Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 4;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr4Index = -1;
        $scope.selectedAttr5Index = -1;
        $scope.selectedAttr4Index = index;

        console.log(level);

        $scope.attrLevel5 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel5 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr4 = level.Entry;
            selectedAttrLevels = selectedAtr4 + ", " + selectedAttrLevels;
            selectedAttrIds4 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr5 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel5 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level5Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel5 = list;
                $scope.level5Header = child;

            });
        }
        // $scope.attrLevel5 = [{ Id: 1, Attribute1: "Field Crop4" }, { Id: 4, Attribute1: "Economy4" }, { Id: 5, Attribute1: "Agricultre4" }];
    }

    $scope.getAttrLevel6 = function (level, index) {
        console.log("selecting level 5 ", level);
        $scope.level5Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr5Index = index;
            return false;
        }
        $scope.level6Header = "Loading..";


        console.log("$scope.level5Value", $scope.level5Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 5;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr5Index = -1;
        $scope.selectedAttr6Index = -1;
        $scope.selectedAttr5Index = index;

        console.log(level);

        $scope.attrLevel6 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel6 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr5 = level.Entry;
            selectedAttrLevels = selectedAtr5 + ", " + selectedAttrLevels;
            selectedAttrIds5 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr6 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel6 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level6Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel6 = list;
                $scope.level6Header = child;

            });
        }
        // $scope.attrLevel6 = [{ Id: 1, Attribute1: "Field Crop5" }, { Id: 5, Attribute1: "Economy5" }, { Id: 6, Attribute1: "Agricultre5" }];
    }




    $scope.getAttrLevel7 = function (level, index) {
        console.log("selecting level 6 ", level);
        $scope.level6Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr6Index = index;
            return false;
        }
        $scope.level7Header = "Loading..";


        console.log("$scope.level6Value", $scope.level6Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 6;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr6Index = -1;
        $scope.selectedAttr7Index = -1;
        $scope.selectedAttr6Index = index;

        console.log(level);

        $scope.attrLevel7 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel7 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr6 = level.Entry;
            selectedAttrLevels = selectedAtr6 + ", " + selectedAttrLevels;
            selectedAttrIds6 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr7 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel7 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level7Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel7 = list;
                $scope.level7Header = child;

            });
        }
        // $scope.attrLevel7 = [{ Id: 1, Attribute1: "Field Crop6" }, { Id: 6, Attribute1: "Economy6" }, { Id: 7, Attribute1: "Agricultre6" }];
    }


    $scope.getAttrLevel8 = function (level, index) {
        console.log("selecting level 7 ", level);
        $scope.level7Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr7Index = index;
            return false;
        }
        $scope.level8Header = "Loading..";


        console.log("$scope.level7Value", $scope.level7Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 7;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr7Index = -1;
        $scope.selectedAttr8Index = -1;
        $scope.selectedAttr7Index = index;

        console.log(level);

        $scope.attrLevel8 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel8 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr7 = level.Entry;
            selectedAttrLevels = selectedAtr7 + ", " + selectedAttrLevels;
            selectedAttrIds7 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr8 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel8 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level8Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel8 = list;
                $scope.level8Header = child;

            });
        }
        // $scope.attrLevel8 = [{ Id: 1, Attribute1: "Field Crop7" }, { Id: 7, Attribute1: "Economy7" }, { Id: 8, Attribute1: "Agricultre7" }];
    }


    $scope.getAttrLevel9 = function (level, index) {
        console.log("selecting level 8 ", level);
        $scope.level8Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr8Index = index;
            return false;
        }
        $scope.level9Header = "Loading..";


        console.log("$scope.level8Value", $scope.level8Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 8;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr8Index = -1;
        $scope.selectedAttr9Index = -1;
        $scope.selectedAttr8Index = index;

        console.log(level);

        $scope.attrLevel9 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel9 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr8 = level.Entry;
            selectedAttrLevels = selectedAtr8 + ", " + selectedAttrLevels;
            selectedAttrIds8 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr9 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel9 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level9Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel9 = list;
                $scope.level9Header = child;

            });
        }
        // $scope.attrLevel9 = [{ Id: 1, Attribute1: "Field Crop8" }, { Id: 8, Attribute1: "Economy8" }, { Id: 9, Attribute1: "Agricultre8" }];
    }

    $scope.getAttrLevel10 = function (level, index) {
        console.log("selecting level 9 ", level);
        $scope.level9Value = level.Entry;
        if (level.Child == "NONE") {
            $scope.selectedAttr9Index = index;
            return false;
        }
        $scope.level10Header = "Loading..";


        console.log("$scope.level9Value", $scope.level9Value);
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 9;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
        $scope.selectedAttr9Index = -1;
        $scope.selectedAttr10Index = -1;
        $scope.selectedAttr9Index = index;

        console.log(level);

        $scope.attrLevel10 = [];
        if (level.StratumId < 0) {
            $scope.attrLevel10 = [{ Id: 1, Entry: "", StratumId: 0 }]
        }
        else {
            selectedAtr9 = level.Entry;
            selectedAttrLevels = selectedAtr9 + ", " + selectedAttrLevels;
            selectedAttrIds9 = level.AttrBucket;
            selectedAttrBucketIds = level.AttrBucket;
            $scope.SelectedStratumFilterIds = level.SelectedStratumIds;//_.uniq(($scope.SelectedStratumFilterIds + "," + level.SelectedStratumIds).split(',')).join(',');
            $scope.isAttr10 = true;
            $scope.loadingMsg = "Loading. . .";

            $scope.selectedStratumIds = level.SelectedStratumIds;
            $scope.remainingStratumCount = level.RemainingStratumCount;

            $scope.SelectedAttrs = level.AttrBucket;
            $scope.resultCount = level.AttrCount;

            var params = '{';
            params += '"searchText" : "' + $scope.sText + '",';
            params += '"filters" : { "' + level.Parent + '" : ["' + level.Entry + '"],';

            for (var key in finalFilterObj) {
                if (key) {
                    params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
                }

            }
            params = params.substr(0, params.length - 1);
            params += '}}';

            var jsonObj = JSON.parse(params);

            if (!$.isEmptyObject(finalLocationObj)) {
                jsonObj["locations"] = finalLocationObj;
            }

            searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
                var child = level.Child;
                if (response.responseEntity.stratum == null) {
                    $scope.attrLevel10 = [{ Id: 1, Entry: "Overall", StratumId: 0 }];
                    $scope.level10Header = child;
                    return true;

                }



                var childData = _.filter(response.responseEntity.stratumList, function (o) { return o.parent == level.Parent });

                var data = response.responseEntity.stratum[child];
                var list = [];
                for (var val in data) {
                    list.push({
                        StratumId: val,
                        Entry: data[val] != "" ? data[val] : "",
                        Parent: child,
                        Child: childData.length > 0 ? childData[0].stratumName : "NONE",
                        Id: val
                    });
                }
                $scope.attrLevel10 = list;
                $scope.level10Header = child;

            });
        }
        // $scope.attrLevel10 = [{ Id: 1, Attribute1: "Field Crop9" }, { Id: 9, Attribute1: "Economy9" }, { Id: 10, Attribute1: "Agricultre9" }];
    }

    $scope.getAttrLevel3Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr2 + ", " + selectedAtr1;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level3Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr3Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 3;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }


    $scope.getAttrLevel4Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level4Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr4Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 4;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }

    $scope.getAttrLevel5Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level5Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr5Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 5;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }

    $scope.getAttrLevel6Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr5 + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level6Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr6Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 6;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }

    $scope.getAttrLevel7Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr6 + ", " + selectedAtr5 + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level7Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr7Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 7;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }

    $scope.getAttrLevel8Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr7 + ", " + selectedAtr6 + ", " + selectedAtr5 + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level8Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr8Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 8;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }

    $scope.getAttrLevel9Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr8 + ", " + selectedAtr7 + ", " + selectedAtr6 + ", " + selectedAtr5 + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level9Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr9Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 9;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }


    $scope.getAttrLevel10Active = function (level, index) {
        selectedAttrLevels = level.Entry + ", " + selectedAtr9 + ", " + selectedAtr8 + ", " + selectedAtr7 + ", " + selectedAtr6 + ", " + selectedAtr5 + ", " + selectedAtr4 + ", " + selectedAtr3 + ", " + selectedAtr2 + ", " + selectedAtr1;;
        selectedAttrBucketIds = level.AttrBucket;
        $scope.level10Value = level.Entry;
        //console.log("$scope.SelectedStratumFilterIds", $scope.SelectedStratumFilterIds)
        $scope.SelectedStratumFilterIds = level.SelectedStratumIds;
        $scope.selectedAttr10Index = index;
        selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.StratumId !== level.StratumId; });
        //level.RefID = parseInt(level.SelectedStratumIds.substring(level.SelectedStratumIds.lastIndexOf(',') + 1));
        level.level = 10;
        deleteSelectedFilters(level.StratumId);
        selectedFilterLevels.push(level);
    }


    $scope.selectActiveLevel = function (filter) {



        ///
        console.log($scope.level1Header, $scope.level1Value);
        console.log($scope.level2Header, $scope.level2Value);
        console.log($scope.level3Header, $scope.level3Value);


        $scope.pushToAry($scope.level1Header, $scope.level1Value);
        $scope.pushToAry($scope.level2Header, $scope.level2Value);
        $scope.pushToAry($scope.level3Header, $scope.level3Value);
        $scope.pushToAry($scope.level4Header, $scope.level4Value);
        $scope.pushToAry($scope.level5Header, $scope.level5Value);
        $scope.pushToAry($scope.level6Header, $scope.level6Value);
        $scope.pushToAry($scope.level7Header, $scope.level7Value);
        $scope.pushToAry($scope.level8Header, $scope.level8Value);
        $scope.pushToAry($scope.level9Header, $scope.level9Value);
        $scope.pushToAry($scope.level10Header, $scope.level10Value);
        //logic for lastlevel stratum obj

        var DisplayText = ($scope.level10Value ? $scope.level10Value + ", " : "") + ($scope.level9Value ? $scope.level9Value + ", " : "") + ($scope.level8Value ? $scope.level8Value + ", " : "") + ($scope.level7Value ? $scope.level7Value + ", " : "") + ($scope.level6Value ? $scope.level6Value + ", " : "") + ($scope.level5Value ? $scope.level5Value + ", " : "") + ($scope.level4Value ? $scope.level4Value + ", " : "") + ($scope.level3Value ? $scope.level3Value + ", " : "") + ($scope.level2Value ? $scope.level2Value + ", " : "") + ($scope.level1Value ? $scope.level1Value : "");
        console.log(DisplayText);
        var isExist = false;
        if (filter.Id == 0) {

            //Check for Country
            if ($scope.selectedCountry) {
                var tempList = [];
                tempList.push($scope.selectedCountry + ":" + $scope.selectedCountry);
                finalLocationObj["Country"] = tempList;
            }
            //else {
            //    delete finalLocationObj["Country"];
            //}

            //Check for State
            if ($scope.selectedState) {
                var tempList = [];
                tempList.push($scope.selectedCountry + ":" + $scope.selectedState);
                finalLocationObj["State"] = tempList;
            }
            else {
                delete finalLocationObj["State"];
            }

            //Check for County
            if ($scope.selectedCounty) {
                var tempList = [];
                tempList.push($scope.selectedState + ":" + $scope.selectedCounty);
                finalLocationObj["County"] = tempList;
            }
            else {
                delete finalLocationObj["County"];
            }

            DisplayText = ($scope.selectedCounty ? $scope.selectedCounty + ", " : "") + ($scope.selectedState ? $scope.selectedState + ", " : "") + ($scope.selectedCountry ? $scope.selectedCountry : "");

            $scope.selectedFilters.push({ Stratum: "Location", Id: filter.Id, text: DisplayText, AttrBucket: "", selectedStratumIds: "" });




            console.log(finalLocationObj);
        }
        else {


            console.log("in else part ");



            console.log("$scope.selectedFilters", $scope.selectedFilters);
            angular.forEach($scope.selectedFilters, function (value, key) {
                if (value.Id == filter.Id) {
                    isExist = true;
                    value.text = DisplayText;
                }
            });
            if (!isExist) {
                var stratumObj = { Stratum: filter.Stratum, Id: filter.Id, text: DisplayText, AttrBucket: selectedAttrBucketIds, selectedStratumIds: $scope.SelectedStratumFilterIds };
                $scope.selectedFilters.push(stratumObj);
                var valuePush = "";
                var levelName = "";
                if ($scope.level3Value) {
                    valuePush = $scope.level3Value;
                    levelName = "level3Value";
                }
                else if ($scope.level2Value) {
                    valuePush = $scope.level2Value;
                    levelName = "level2Value";
                }
                else if ($scope.level1Value) {
                    valuePush = $scope.level1Value;
                    levelName = "level1Value";
                }
                //   var valuePush = $scope.level3Value || $scope.level2Value || $scope.level1Value;



                //  $scope.lastLevels.push({ stratumObj: stratumObj, value: valuePush });
                var numberFromSelected = levelName.match(/\d+/);
                console.log("numberFromSelected", numberFromSelected);
                var stringModelName = "level" + numberFromSelected + "Header";
                console.log("stringModelName", stringModelName);
                var getter = $parse(stringModelName);
                var valueHeader = getter($scope);
                console.log("valueHeader", valueHeader)
                //$scope.lastLevels.push({ stratumObj: stratumObj, key: valueHeader, value: valuePush });
            }
        }
        // console.log("selectedAttrBucketIds", selectedAttrBucketIds, $scope.SelectedStratumFilterIds, $scope.selectedFilters);
        var tempFilters = [];
        $scope.selectedFilterIndex = -1;
        //console.log(filter);
        //console.log(filters);
        //for (i = 0; i < filters.length; i++) {
        //    if (filters[i].Id != filter.Id) {
        //        tempFilters.push(filter[i]);
        //    }
        //}
        //clearing all filters
        $scope.level1Value = null;
        $scope.level3Value = null;
        $scope.level2Value = null;
        $scope.level4Value = null;
        $scope.level5Value = null;
        $scope.level6Value = null;
        $scope.level7Value = null;
        $scope.level8Value = null;
        $scope.level9Value = null;
        $scope.level10Value = null;
        ////
        var index = $scope.Filters.indexOf(filter);
        $scope.Filters.splice(index, 1);
        $scope.checkForSingleLevels();
        $scope.overlay = false;
        // $scope.Filters = tempFilters;
        $("#filters_container").hide();

    }
    $scope.updateSeletedFilter = function (filter) {
        // console.log("updateSeletedFilter", filter)

        $scope.lastLevels = $scope.lastLevels.filter(function (lastLevel) {
            return lastLevel.stratumObj != filter;
        });


        var index = $scope.selectedFilters.indexOf(filter);

        $scope.selectedFilters.splice(index, 1);
        $scope.Filters.push(filter);

        if (filter.Id == 0) {
            finalLocationObj = {};
            $scope.locationLevels = [];
            $scope.selectedLocationLevels = null;
        }

        var mainParent = filter.Stratum;
        var nextParent = mainParent;
        do {
            $scope.removeFromAry(nextParent);
            var childData = _.filter(filterData.stratumList, function (o) { return o.parent == nextParent });
            if (childData == null) {
                nextParent == null;
            }
            else {
                nextParent = childData[0].stratumName;
            }
        } while (nextParent != null);
        // console.log("selectedAttrBucketIds", $scope.selectedFilters)
    }
    //$scope.$watch('SelectedStratumFilterIds', function () {
    //    $scope.SelectedStratumFilterIds=_.uniq($scope.SelectedStratumFilterIds);
    //});

    deleteSelectedFilters = function (stratumId) {
        flag = true;

        while (flag) {
            tempStratumId = parseInt(stratumId);
            tempArray = _.findWhere(selectedFilterLevels, { RefID: tempStratumId });
            if (tempArray == undefined) {
                return;
            }
            selectedFilterLevels = _.filter(selectedFilterLevels, function (o) { return o.RefID != tempStratumId; });
            console.log("tempArray, selectedFilterLevels", tempArray, selectedFilterLevels);
            if (tempArray.StratumId == null) {
                flag = false;
            }
            else {
                tempStratumId = tempArray.RefID;
            }
        }

    }

    /************************** BEGIN LOCATION *************************************/

    //$scope.locationLevel1 = [{ Id: 1, Country: "UNITED STATES" }];

    $scope.getCountries = function () {

        $scope.allCountries = [];
        $scope.isState = false;
        $scope.isCounty = false;
        $scope.allStates = [];
        $scope.allCounties = [];

        $scope.isCountry = true;

        $scope.selectedCountry = null;

        //Get From Filters

        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
            }

        }
        ///Jitender Code
        params = params.substr(0, params.length - 1);
        params += '},' +
            '"locations":{' +
               '"Country":["' + $scope.superRegionTxt + ':' + $scope.superRegionTxt +
            '"]}' +
            '}';

        console.log("params ", params);
        ///
        //searchService.GetAttributeLevel1(JSON.parse(params)).then(function (response) {
        //    console.log("response.responseEntity", response.responseEntity);
        //    //var locObj = response.responseEntity.locations;

        //    //$scope.allCountries = locObj.country.locationName;

        //});

        $scope.allCountries = [$scope.superRegionTxt]
    }

    $scope.getStates = function (country) {

        $scope.isState = true;
        $scope.allStates = [];
        $scope.allCounties = [];

        $scope.selectedCountry = country;
        $scope.selectedState = null;
        $scope.selectedCounty = null;
        //Get From Filters

        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';
        console.log("finalFilterObj", finalFilterObj);
        delete finalFilterObj["null"];
        console.log("finalFilterObj", finalFilterObj);
        for (var key in finalFilterObj) {
            console.log("key ", key);

            if (key) {
                console.log("key ", key);
                params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);

        params += '},' +
           '"locations":{' +
              '"Country":["' + $scope.superRegionTxt + ':' + $scope.superRegionTxt +
           '"]}' +
           '}';
        var tempList = [];
        tempList.push(country);

        var locations = {
            Country: tempList
        }

        var jsonObj = JSON.parse(params);
        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";
        console.log("Json Obj", jsonObj);
        console.log("string Json ", JSON.stringify(jsonObj));
        //jsonObj["locations"] = locations;
        // console.log("jsonObj", JSON.stringify(jsonObj));
        searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
            console.log(" response.responseEntity", response.responseEntity);
            //var locObj = response.responseEntity.locations;
            if (response.responseEntity.locations.State) {
                console.log("all states ", response.responseEntity.locations.State[0].locations);

                $scope.allStates = response.responseEntity.locations.State[0].locations;
            }
            else {
                $scope.allStates = null;
            }

        });

    }

    $scope.getCounty = function (state) {

        $scope.isCounty = true;
        $scope.allCounties = [];

        $scope.selectedState = state;
        $scope.selectedCounty = null;


        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);
        params += '},' +
           '"locations":{' +
              '"Country":["' + $scope.superRegionTxt + ':' + $scope.superRegionTxt + '"],' +
              '"State":["' + $scope.superRegionTxt + ":" + state +
           '"]}' +
           '}';
        var jsonObj = JSON.parse(params);
        jsonObj["location"] = true;
        jsonObj["reqAttList"] = "";
        //var locations = {};

        //var tempList = [];
        //tempList.push($scope.selectedCountry);
        //locations["Country"] = tempList;

        //tempList = [];
        //tempList.push($scope.selectedState);
        //locations["State"] = tempList;

        //var jsonObj = JSON.parse(params);
        //jsonObj["locations"] = locations;

        searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {

            //var locObj = response.responseEntity.locations;

            //$scope.allCounties = locObj.county.locationName;
            if (response.responseEntity.locations.County) {
                console.log(" response.responseEntity", response.responseEntity.locations.County[0].locations);
                //var locObj = response.responseEntity.locations;
                var filteredCounties = response.responseEntity.locations.County.filter(function (county) {
                    return county.locationParent == state;

                });
                console.log("filteredCounties", filteredCounties);
                $scope.allCounties = filteredCounties[0].locations;
            }
            else {
                $scope.allCounties = null;
            }


        });
    }

    $scope.county = function (item) {
        $scope.selectedCounty = item;
    }

    $scope.selectLocation = function () {

        $scope.isLocation = true;
        $scope.isPopupLocation = false;
        if ($scope.tempSelectedLocation.State != '' && $scope.tempSelectedLocation.County != '') {
            $scope.selectedLocation = $scope.tempSelectedLocation.Country + ", " + $scope.tempSelectedLocation.State + ", " + $scope.tempSelectedLocation.County;
        }
        else if ($scope.tempSelectedLocation.State != '') {
            $scope.selectedLocation = $scope.tempSelectedLocation.Country + ", " + $scope.tempSelectedLocation.State;
        }
        else {
            $scope.selectedLocation = $scope.tempSelectedLocation.Country;
        }
    }

    $scope.ClosePopup = function () {
        $scope.selectedFilterIndex = -1;
        $scope.selectedFilter = null;
        $scope.isPopupLocation = false;
        $scope.isPopupIndustry = false;
        $scope.isPopupOccupations = false;
        $scope.overlay = false;
        $("#filters_container").hide();
    }



    /************************** END LOCATION *************************************/

    /************************** START INDUSTRY ****************************************/
    $scope.getIndustries = function () {
        $scope.isPopupLocation = false;
        $scope.isPopupIndustry = true; $scope.isPopupOccupations = false;
    }
    $scope.getOccupations = function () {
        $scope.isPopupLocation = false;
        $scope.isPopupIndustry = false;
        $scope.isPopupOccupations = true;
    }
    /************************** END INDUSTRY *************************************/


    $scope.RedirectToDashboard = function () {
        defaultAttrIds = "";
        if ($scope.selectedFilters.length == 1) {
            if ($scope.selectedFilters[0].Id == 0) {
                defaultAttrIds = $scope.attributeIds;
            }
        }
        /////
        //$scope.selectedFilters.map(function (filter) {
        //      var filterParts=filter.split(":")
        //});



        /////


        console.log("$scope.sectorTxt", $scope.sectorTxt);
        console.log("$scope.superRegion", $scope.superRegion);
        console.log("$scope.selectedFilters", $scope.selectedFilters);
        console.log("defaultAttrIds", defaultAttrIds);
        console.log("searchResult", searchResult);
        console.log("selectedFilterLevels", selectedFilterLevels);
        console.log("$scope.tempSelectedLocation", $scope.tempSelectedLocation);
        console.log("$scope.sText", $scope.sText);
        console.log("JSON.stringify(finalFilterObj)", JSON.stringify(finalFilterObj));
        console.log("$scope.subSector", $scope.subSector);
        console.log("JSON.stringify(finalLocationObj)", JSON.stringify(finalLocationObj));
        console.log($scope.sectorTxt, $scope.superRegion, $scope.selectedFilters, defaultAttrIds, searchResult, selectedFilterLevels, $scope.tempSelectedLocation, $scope.sText, JSON.stringify(finalFilterObj), $scope.subSector, JSON.stringify(finalLocationObj));

        //defaultAttrIds = $scope.attributeIds;

        console.log(" $scope.lastLevels", $scope.lastLevels);
        var lastLevelsArray = $scope.selectedFilters.map(function (filter) {
            return { value: filter.text, key: filter.Stratum };

        });
        $scope.lastLevels.push({});
        console.info("$scope.stratumList", $scope.stratumList);
        console.log("$scope.reqlocationLevels", $scope.reqlocationLevels);
        searchService.RedirectToDashboard($scope.sectorTxt, $scope.superRegion, $scope.selectedFilters, defaultAttrIds, searchResult, selectedFilterLevels, $scope.tempSelectedLocation, $scope.sText, JSON.stringify(finalFilterObj), $scope.subSector, JSON.stringify(finalLocationObj), lastLevelsArray, $scope.stratumList, $scope.selectedLocationLevels, $scope.prevLocSelected, $scope.reqlocationLevels).then(function (response) {
            window.location.href = "/new/dashboard";
        });
    }



    $scope.removeFromAry = function (name) {
        delete finalFilterObj[name];
    }

    $scope.checkForFilter = function (data, stratum, listOfStratums) {

        var cStratum = stratum;
        console.log("checkForFilter called", data, stratum, listOfStratums, data[cStratum].length);
        var count = data[cStratum].length;
        if (count == 1) {
            //var stratumObj = { Stratum: stratum, Id: Math.random(), text: data[cStratum][0], AttrBucket:"" , selectedStratumIds: "" };
            //$scope.selectedFilters.push(stratumObj);
            if (!$scope.TOPSELECTIONSNew) {
                $scope.TOPSELECTIONSNew = {};
            }
            else {
                $scope.TOPSELECTIONSNew[stratum] = data[cStratum][0];
            }
            console.log("check for filter ", $scope.TOPSELECTIONSNew);
            $scope.TOPSELECTIONS.push({ stratum: stratum, value: data[cStratum][0] });
            $scope.pushToAry(stratum, data[cStratum][0]);
            cStratum = _.filter(listOfStratums, function (o) { return o.parent == stratum });
            if (cStratum.length) {
                return $scope.checkForFilter(data, cStratum[0].stratumName, listOfStratums);
            }
            else {
                return "";
            }

        }
        else {
            return cStratum;
        }
    }

    $scope.checkForSingleLevels = function () {

        console.log("Inside checkForSingleLevels");
        var params = '{';
        params += '"searchText" : "' + $scope.sText + '",';
        params += '"filters" : { ';

        for (var key in finalFilterObj) {
            if (key) {
                params += '"' + key.replace(/&amp;/g, '&') + '" : ["' + finalFilterObj[key] + '"],';
            }

        }

        params = params.substr(0, params.length - 1);
        params += '}}';


        var jsonObj = JSON.parse(params);
        if (!$.isEmptyObject(finalLocationObj)) {
            jsonObj["locations"] = finalLocationObj;
        }

        searchService.GetAttributeLevel1(jsonObj, $scope.reqLocationLevels).then(function (response) {
            console.log(response);
            var pData = _.filter(response.responseEntity.stratumList, function (o) { return o.level < 100; });
            var aF = $scope.Filters;
            var resST = response.responseEntity.stratum;
            console.log(aF);

            var toRemoveFIlters = [];

            for (var i = 0; i < aF.length; i++) {
                if (resST[aF[i].Stratum].length == 1) {
                    $scope.checkForFilter(resST, aF[i].Stratum, pData);

                    var xxx = {};
                    xxx[aF[i].Stratum] = resST[aF[i].Stratum][0];
                    var op = makeString(xxx, response.responseEntity.stratumList);
                    console.log(op);
                    var stratumObj = { Stratum: aF[i].Stratum, Id: Math.random(), text: resST[aF[i].Stratum][0], AttrBucket: "", selectedStratumIds: "" };
                    $scope.selectedFilters.push(stratumObj);

                    toRemoveFIlters.push(aF[i]);
                }
            }


            for (var i = 0; i < toRemoveFIlters.length; i++) {
                var index = $scope.Filters.indexOf(toRemoveFIlters[i]);
                $scope.Filters.splice(index, 1);
            }




        });

    }

    ///////Jitender
    function makeString(inputObj, stratumList) {
        var keys = Object.keys(inputObj);

        var stratums = stratumList.filter(function (stratum) {
            return keys.indexOf(stratum.stratumName) > -1;
        });
        console.log("stratums", stratums);
        var mains = GetParentChildRelation(stratums);
        var allTextnde = [];
        mains.forEach(function (main) {
            var textItem = getStratumNamesParentChild(main).map(function (key) {
                return inputObj[key];
            }).reverse().join(",");
            allTextnde.push({ stratum: main.stratumName, text: textItem });
        });

        console.log("allTextnde", allTextnde);
        return allTextnde;
    }

    function getStratumNamesParentChild(item) {
        var orderArray = [];

        var processItem = item;
        orderArray.push(processItem.stratumName);
        while (processItem.children.length > 0) {
            processItem = processItem.children[0];
            orderArray.push(processItem.stratumName);

        }


        return orderArray;
    }


    function GetParentChildRelation(stratumList) {
        var mainObj = [];
        var mainBreadList = [];
        for (var i = 0; i < stratumList.length; i++) {
            var find = false;
            for (var j = 0; j < stratumList.length; j++) {
                if (stratumList[i].parent == stratumList[j].stratumName) {
                    find = true;
                }


            }
            if (!find) {
                mainObj.push(stratumList[i]);
            }
        }
        mainObj.forEach(function (rootItem) {
            var breadItem = {
                levels: []
            }

            rootItem.children = [];
            var process = true;
            var processItem = rootItem;
            var newStratumList = JSON.parse(JSON.stringify(stratumList));

            while (process) {
                breadItem.levels.push(processItem);
                console.log("processItem", processItem);
                var child = getChild(processItem.stratumName, newStratumList);
                console.log("child ", child);
                newStratumList.splice(newStratumList.indexOf(child), 1);

                if (child) {
                    processItem.children.push(child);
                    processItem = child;
                    processItem.children = [];
                }
                else {
                    process = false;
                }

            }
            mainBreadList.push(breadItem)
        });

        return mainObj;


    }
    function getChild(parentElemName, list) {
        console.log("parentElemName", parentElemName);
        console.log("list", list);
        var child = list.filter(function (item) {
            //console.log("item parent", item.parent);
            //console.log("Elem Name ", parentElemName);
            //console.log("result ", item.parent == parentElemName);
            return item.parent == parentElemName;


        });
        console.log("child ", child);
        if (child.length > 0)
            return child[0];
        else
            return null;
    }




}]);

app.factory('searchService', ['$http', '$q', function ($http, $q) {
    var self = this;
    var allPrevRequests = [];

    self.GetLocData = function (params) {
        var defer = $q.defer();

        params["location"] = true;
        params["reqAttList"] = "";
        console.log("params ", JSON.stringify(params));
        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }


    self.GetCountries = function (sector, superRegion, attributeIds) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCountries',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetStates = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetStates',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetCounties = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCounties',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAttributeLevel1 = function (params,locationLevels) {
        var defer = $q.defer();

        params["location"] = true;
        params["reqAttList"] = "";
        if (locationLevels)
            params["locationLevels"] = locationLevels;
       
        console.log("params ", JSON.stringify(params));
        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetFilterTypes = function (sector, superRegion, subSector, regionId, entryId, string, stratumName, location) {
        var defer = $q.defer();

        var sectorList = [];
        sectorList.push(sector);

        var subSectorList = [];
        subSectorList.push(subSector);

        var sText = [];
        sText.push(string);

        var filter = {
            Sector: sectorList,
            "Sub-Sector": subSectorList
        }

        // filter[stratumName] = sText;

        var params = {
            searchText: string,
            filters: filter,
            // locations:location
            location: true,
            reqAttList: ""
        }
        if (location) {
            params["locations"] = location;
        }
        console.log(params);
        console.log("params ", JSON.stringify(params));
        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetFilterLevel1 = function (stratumId, attributeIds, regionId) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAttributeLevel1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "stratumId": stratumId, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetFilterNLevel = function (levelId, regionId, attributeIds) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAttributeNLevel',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "levelId": levelId, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAllSectors = function () {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAllSectors',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSearchResult = function (query) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetSearchResult',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "query": query }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.RedirectToDashboard = function (sector, superRegion, selectedFilters, defautAttrs, searchResult, selectedFilterLevels, selectedLocation, sText, filterJsonString, subSector, filterLocationString, lastLevelArray, stratumList, locationLevels, previousLocation, reqlocationLevels) {
        var defer = $q.defer();
        console.log("locationLevels", locationLevels);
        $http({
            url: '/New/dashboardFilter',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sectorText": sector, "superRegion": superRegion, "selectionsAttrs": selectedFilters, "attributeIds": defautAttrs, "searchResult": searchResult, "selectedFilterLevels": selectedFilterLevels, "Location": selectedLocation, "sText": sText, "FilteredJsonString": filterJsonString, "SubSector": subSector, "FilterLocationString": filterLocationString, "stratumList": JSON.stringify(stratumList), "lastLevelArray": JSON.stringify(lastLevelArray), "locationLevels": JSON.stringify(locationLevels), "prevLocSelected": JSON.stringify(previousLocation), "reqLocationLevels":JSON.stringify( reqlocationLevels) },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSearchResultsFromAPI = function (searchString) {
        var defer = $q.defer();
        delete $http.defaults.headers.common['X-Requested-With'];
        self.CancelAllRequests();
        $http({
            url: 'http://54.71.24.240:9090/rest/zdaly/wilcard-search/' + searchString,
            method: "GET",
            headers: { 'Content-Type': 'application/json;charset=UTF-8', }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            console.log(status);
            return defer.reject(failedResponse);
        });
        allPrevRequests.push(defer);
        return defer.promise;
    }
    self.CancelAllRequests = function () {
        allPrevRequests.forEach(function (prevReq) {
            prevReq.resolve();
        });
        allPrevRequests = [];
    }
    return self;

}]);

/*
app.config(function ($routeProvider) {
    $routeProvider
    .when("/new", {
        templateUrl: "../../Angular/partials/test/test1.html"
    })
    .when("/test1", {
        templateUrl: "test1.html"
    })
    .when("/test2", {
        templateUrl: "test2.html"
    })
    .when("/test3", {
        templateUrl: "test3.html"
    });

});
*/