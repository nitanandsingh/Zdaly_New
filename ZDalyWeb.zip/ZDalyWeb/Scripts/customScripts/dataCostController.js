﻿/**
 * Let's you use underscore as a service from a controller.
 * Got the idea from: http://stackoverflow.com/questions/14968297/use-underscore-inside-controllers
 * @author: Andres Aguilar https://github.com/andresesfm
 */
angular.module('underscore', []).factory('_', ['$window', function ($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);



var app = angular.module('app', ['underscore']);

app.controller('datacostController', ['$scope', '$compile', 'dataCostService', '_', function ($scope, $compile, dataCostService, _) {

    var dataCost = { RecordCount: 0, TotalCost: 0.0, GUID: 0, UserCredit: 0, ChargeableData: 0.0 };

    $scope.AllSectors = [];
    $scope.sectors = [];

    $scope.AllsuperRegions = [];
    $scope.superRegions = [];

    $scope.ListAllSubSector = [];
    $scope.ListSubSector = [];
    $scope.selectedSubSectors = [];

    $scope.ListAllSubSource = [];
    $scope.ListSubSource = [];
    $scope.selectedSubSource = [];

    $scope.ListAllCommodity1 = [];
    $scope.ListCommodity1 = [];
    $scope.selectedCommodity1 = [];

    $scope.ListAllCommodity2 = [];
    $scope.ListCommodity2 = [];
    $scope.selectedCommodity2 = [];

    $scope.ListAllCommodity3 = [];
    $scope.ListCommodity3 = [];
    $scope.selectedCommodity3 = [];

    $scope.ListAllAttribute1 = [];
    $scope.ListAttribute1 = [];
    $scope.selectedAttribute1 = [];

    $scope.ListAllAttribute2 = [];
    $scope.ListAttribute2 = [];
    $scope.selectedAttribute2 = [];

    $scope.ListAllGeoGraphicLevel = [];
    $scope.ListGeoGraphicLevel = [];
    $scope.selectedGeoGraphicLevel = [];

    $scope.ListAllTimeLevel = [];
    $scope.ListTimeLevel = [];
    $scope.selectedTimeLevel = [];

    $scope.ListAllCountry = [];
    $scope.ListCountry = [];
    $scope.selectedCountry = [];

    $scope.ListAllCounty = [];
    $scope.ListCounty = [];
    $scope.county = [];

    $scope.ListAllState = [];
    $scope.ListState = [];
    $scope.state = [];

    $scope.startDate = "";
    $scope.endDate = "";

    $scope.selectedSubSectorMuted = true;
    $scope.selectedSubSourceMuted = true;
    $scope.selectedCommodity1Muted = true;
    $scope.selectedGeoGraphicLevelMuted = true;
    $scope.selectedTimeLevelMuted = true;

    $scope.selectedDataCost = dataCost;

    //$scope.Allthemes = [];
    //$scope.themes = [];

    $scope.sectorID = 0;
    $scope.sectorName = "";
    $scope.superRegionName = "";
    $scope.subSectorID = 0;
    $scope.Tier1ID = 0;

    $scope.CommodityIndex;
    $scope.SubCommodityIndex;

    dataCostService.GetSectors().then(function (response) {
        $scope.AllSectors = response;
        $scope.sectors = angular.copy($scope.AllSectors);
        $scope.sectors = _.uniq($scope.sectors, function (sector) { return sector.SectorName; });
    });

    dataCostService.GetSuperRegion().then(function (response) {
        $scope.AllsuperRegions = response;
        $scope.superRegions = angular.copy($scope.AllsuperRegions);
        $scope.superRegions = _.uniq($scope.superRegions, function (sector) { return sector.SectorName; });
    });

    $scope.GetSector = function (selectedItem) {
        //$scope.ClearRegionSelection();
        $scope.updateSingleSelectionInfo($scope.sectors, false);
        $scope.sectorName = selectedItem.Sectorname;
        selectedItem.selected = true;
        //$scope.AllsuperRegions = _.where($scope.AllSectors, { SectorName: $scope.sectorName });
        $scope.sectors = angular.copy($scope.AllSectors);
        $scope.RefreshListBasedonSectorAndSuperRegion(selectedItem);
    }

    $scope.GetSuperRegion = function (selectedItem) {
        //$scope.ClearRegionSelection();
        $scope.updateSingleSelectionInfo($scope.superRegions, false);
        $scope.superRegionName = selectedItem.SuperRegion;
        selectedItem.selected = true;
        //$scope.AllsuperRegions = _.where($scope.AllSectors, { SectorName: $scope.sectorName });
        $scope.superRegions = angular.copy($scope.AllsuperRegions);
        $scope.RefreshListBasedonSectorAndSuperRegion(selectedItem);
    }

    $scope.RefreshListBasedonSectorAndSuperRegion = function (selectedItem) {
        if ($scope.sectorName && $scope.superRegionName && $scope.sectorName != null && $scope.superRegionName != null) {
            $scope.GetTimeLevelBasedonSectorAndSuperRegion(selectedItem);
            $scope.GetSubSectorBasedonSectorAndSuperRegion(selectedItem);
            $scope.GetCommodityBasedonSectorAndSuperRegion(selectedItem);
            $scope.GetGeographicalDataBasedonSectorAndSuperRegion(selectedItem);
            $scope.GetSourceDataBasedonSectorAndSuperRegion(selectedItem);

        }
    }

    // GetSubSectorBasedonSectorAndSuperRegion  GetCommodityBasedonSectorAndSuperRegion  GetGeographicalDataBasedonSectorAndSuperRegion GetSourceDataBasedonSectorAndSuperRegion
    $scope.GetSubSectorBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetSubSectorBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllSubSector = response;
            $scope.ListSubSector = angular.copy($scope.ListAllSubSector);
        });
    }

    $scope.GetCommodityBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetCommodityBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllCommodity1 = response;
            $scope.ListCommodity1 = angular.copy($scope.ListAllCommodity1);
        });
    }

    $scope.GetGeographicalDataBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetGeographicalDataBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllGeoGraphicLevel = response;
            $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
        });
    }

    $scope.GetSourceDataBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetSourceDataBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllSubSource = response;
            $scope.ListSubSource = angular.copy($scope.ListAllSubSource);
        });
    }

    $scope.GetTimeLevelBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetTimeLevelBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllTimeLevel = response;
            $scope.ListTimeLevel = angular.copy($scope.ListAllTimeLevel);
        });
    }

    $scope.GetDataBasedonSectorAndSuperRegion = function (selectedItem) {
        dataCostService.GetDataBasedonSectorAndSuperRegion($scope.sectorName, $scope.superRegionName).then(function (response) {
            $scope.ListAllSubSector = response.ListSubSector;
            $scope.ListAllSubSource = response.ListSubSource;
            $scope.ListAllCommodity1 = response.ListCommodity1;
            $scope.ListAllGeoGraphicLevel = response.ListGeoGraphicLevel;
            $scope.ListAllTimeLevel = response.ListTimeLevel;

            $scope.ListSubSector = angular.copy($scope.ListAllSubSector);
            $scope.ListSubSource = angular.copy($scope.ListAllSubSource);
            $scope.ListCommodity1 = angular.copy($scope.ListAllCommodity1);
            $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
            $scope.ListTimeLevel = angular.copy($scope.ListAllTimeLevel);
        });
    }

    $scope.GetDataForVersion1Selection = function () {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "ListSubSectorId": $scope.selectedSubSectors };

        dataCostService.GetDataForVersion1Selection(_filter).then(function (response) {
            $scope.ListAllSubSector = response.ListSubSector;
            $scope.ListAllSubSource = response.ListSubSource;
            $scope.ListAllCommodity1 = response.ListCommodity1;
            $scope.ListAllGeoGraphicLevel = response.ListGeoGraphicLevel;
            $scope.ListAllTimeLevel = response.ListTimeLevel;

            $scope.ListSubSector = angular.copy($scope.ListAllSubSector);
            $scope.ListSubSource = angular.copy($scope.ListAllSubSource);
            $scope.ListCommodity1 = angular.copy($scope.ListAllCommodity1);
            $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
            $scope.ListTimeLevel = angular.copy($scope.ListAllTimeLevel);
        });
    }

    $scope.updateSingleSelectionInfo = function (list, value) {
        _.each(list, function (sector) {
            sector.selected = value;
        });
    }

    $scope.RefreshList = function (section) {
        if (section == 'sectors') {
            $scope.updateSingleSelectionInfo($scope.sectors, undefined);
            //$scope.ClearRegionSelection();
        }
        else (section == 'superRegion')
        $scope.updateSingleSelectionInfo($scope.superRegions, undefined);
    }

    $scope.UpdateLists = function (selectedItem, item) {
        //if (selectedItem.selected == true) {
            
        //}      

        if (item == 'subSector') {
            $scope.updateSubsector(selectedItem);
        }
        else if (item == 'subCommodity1') {
            $scope.UpdateCommodity1(selectedItem);
        }
        else if (item == 'subCommodity2') {
            $scope.UpdateCommodity2(selectedItem);
        }
        else if (item == 'subCommodity3') {
            $scope.UpdateCommodity3(selectedItem);
        }
        else if (item == 'attribute1') {
            $scope.UpdateAttribute1(selectedItem);
        }
        else if (item == 'attribute2') {
            $scope.UpdateAttribute2(selectedItem);
        }
        else if (item == 'subSource') {
            $scope.UpdateSource(selectedItem);
        }
        else if (item == 'geoGraphicLevel') {
            $scope.UpdateGeoGraphicLevel(selectedItem);
        }
        else if (item == 'timeLevel') {
            $scope.UpdateTimeLevel(selectedItem);
        }
        else if (item == 'state') {
            $scope.UpdateState(selectedItem);
        }
        else if (item == 'country') {
            $scope.UpdateCountry(selectedItem);
        }
        else if (item == 'county') {
            $scope.UpdateCounty(selectedItem);
        }

        if (item == 'subSector') {
            $scope.GetCommodity1V1(selectedItem);
            $scope.GetCommodity2V1(selectedItem);
            $scope.GetCommodity3V1(selectedItem);
            if ($scope.selectedCommodity1.lengh > 0) {
                $scope.GetAttributes1V1(selectedItem);
            }
            if ($scope.selectedCommodity2.lengh > 0) {
                $scope.GetAttributes2V1(selectedItem);
            }

            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'subCommodity1') {
            $scope.GetCommodity2V1(selectedItem);
            $scope.GetCommodity3V1(selectedItem);
            if ($scope.selectedCommodity1.lengh > 0) {
                $scope.GetAttributes1V1(selectedItem);
            }
            if ($scope.selectedCommodity2.lengh > 0) {
                $scope.GetAttributes2V1(selectedItem);
            }

            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'subCommodity2') {
            $scope.GetCommodity3V1(selectedItem);
            if ($scope.selectedCommodity1.lengh > 0) {
                $scope.GetAttributes1V1(selectedItem);
            }
            if ($scope.selectedCommodity2.lengh > 0) {
                $scope.GetAttributes2V1(selectedItem);
            }

            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'subCommodity3') {
            if ($scope.selectedCommodity1.lengh > 0) {
                $scope.GetAttributes1V1(selectedItem);
            }
            if ($scope.selectedCommodity2.lengh > 0) {
                $scope.GetAttributes2V1(selectedItem);
            }

            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'attribute1') {
            if ($scope.selectedCommodity2.lengh > 0) {
                $scope.GetAttributes2V1(selectedItem);
            }

            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'attribute2') {
            $scope.GetSourceV1(selectedItem);
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'subSource') {
            $scope.GetLocation_v1(selectedItem);
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'geoGraphicLevel') {
            $scope.GetCountriesListv1(selectedItem);
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }     
        else if (item == 'state') {
            $scope.GetCountyListv1(selectedItem);
        }
        else if (item == 'country') {
            $scope.GetStateListv1(selectedItem);
            $scope.GetCountyListv1(selectedItem);
        }       
    }

    $scope.updateSubsector = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedSubSectors.push(selectedItem.Subsector_Id) :
        $scope.selectedSubSectors.splice($scope.selectedSubSectors.indexOf(selectedItem.Subsector_Id), 1);
        $scope.selectedSubSectors.length > 0 ? $scope.selectedSubSectorMuted = false : $scope.selectedSubSectorMuted = true;
        $(".dismiss5").fadeOut();

        if (!selectedItem.selected)
            $scope.DeselectSelection('subSector', selectedItem);
    }

    $scope.UpdateCommodity1 = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedCommodity1.push(selectedItem.Tier1_Id) :
        $scope.selectedCommodity1.splice($scope.selectedCommodity1.indexOf(selectedItem.Tier1_Id), 1);
        $scope.selectedCommodity1.length > 0 ? $scope.selectedCommodity1Muted = false : $scope.selectedCommodity1Muted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateCommodity2 = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedCommodity1.push(selectedItem.Tier2_Id) :
        $scope.selectedCommodity2.splice($scope.selectedCommodity2.indexOf(selectedItem.Tier2_Id), 1);
        $scope.selectedCommodity2.length > 0 ? $scope.selectedCommodity1Muted = false : $scope.selectedCommodity1Muted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateCommodity3 = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedCommodity1.push(selectedItem.Tier3_Id) :
        $scope.selectedCommodity3.splice($scope.selectedCommodity3.indexOf(selectedItem.Tier3_Id), 1);
        $scope.selectedCommodity3.length > 0 ? $scope.selectedCommodity1Muted = false : $scope.selectedCommodity1Muted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateAttribute1 = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedAttribute1.push(selectedItem.Tier1_Attr_Id) :
        $scope.selectedAttribute1.splice($scope.selectedAttribute1.indexOf(selectedItem.Tier1_Attr_Id
), 1);
        $scope.selectedAttribute1.length > 0 ? $scope.selectedAttribute1Muted = false : $scope.selectedAttribute1Muted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateAttribute2 = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedAttribute2.push(selectedItem.Tier2_Attr_Id) :
        $scope.selectedAttribute2.splice($scope.selectedAttribute2.indexOf(selectedItem.Tier2_Attr_Id
), 1);
        $scope.selectedAttribute2.length > 0 ? $scope.selectedAttribute2Muted = false : $scope.selectedAttribute2Muted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateSource = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedSubSource.push(selectedItem.Source_Id) :
        $scope.selectedSubSource.splice($scope.selectedSubSource.indexOf(selectedItem.Source_Id), 1);
        $scope.selectedSubSource.length > 0 ? $scope.selectedSubSourceMuted = false : $scope.selectedSubSourceMuted = true;
    }

    $scope.UpdateGeoGraphicLevel = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedGeoGraphicLevel.push(selectedItem.LocationLevel) :
        $scope.selectedGeoGraphicLevel.splice($scope.selectedGeoGraphicLevel.indexOf(selectedItem.LocationLevel), 1);
        $scope.selectedGeoGraphicLevel.length > 0 ? $scope.selectedGeoGraphicLevelMuted = false : $scope.selectedGeoGraphicLevelMuted = true;
    }
    $scope.UpdateTimeLevel = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedTimeLevel.push(selectedItem.TimeLevel_Id) :
        $scope.selectedTimeLevel.splice($scope.selectedTimeLevel.indexOf(selectedItem.TimeLevel_Id), 1);
        $scope.selectedTimeLevel.length > 0 ? $scope.selectedTimeLevelMuted = false : $scope.selectedTimeLevelMuted = true;
    }

    $scope.UpdateState = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.state.push(selectedItem.State_Id) :
        $scope.state.splice($scope.state.indexOf(selectedItem.State_Id), 1);
        $scope.state.length > 0 ? $scope.selectedStateMuted = false : $scope.selectedStateMuted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateCountry = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.selectedCountry.push(selectedItem.Country_Id) :
        $scope.selectedCountry.splice($scope.selectedCountry.indexOf(selectedItem.Country_Id), 1);
        $scope.selectedCountry.length > 0 ? $scope.countryMuted = false : $scope.countryMuted = true;
        $(".dismiss5").fadeOut();
    }

    $scope.UpdateCounty = function (selectedItem) {
        selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
        selectedItem.selected ? $scope.county.push(selectedItem.County_Id) :
        $scope.county.splice($scope.county.indexOf(selectedItem.County_Id), 1);
        $scope.county.length > 0 ? $scope.countyMuted = false : $scope.countyMuted = true;
        $(".dismiss5").fadeOut();
    }

    /*************************************************************************************************************************************************************************************/
    /***************************************************************************** v1 methods ********************************************************************************************/

    $scope.GetCommodity1V1 = function (selectedItem) {
        dataCostService.GetCommodity1V1($scope.sectorName, $scope.superRegionName, $scope.selectedSubSectors, $scope.selectedTimeLevel, $scope.selectedGeoGraphicLevel, $scope.selectedCommodity1, $scope.selectedCountry,
            $scope.county, $scope.state).then(function (response) {
                $scope.ListAllCommodity1 = response;
                $scope.ListCommodity1 = angular.copy($scope.ListAllCommodity1);
            });
    }

    $scope.GetCommodity2V1 = function (selectedItem) {
        dataCostService.GetCommodity2V1($scope.sectorName, $scope.superRegionName, $scope.selectedSubSectors, $scope.selectedTimeLevel, $scope.selectedGeoGraphicLevel, $scope.selectedCommodity1, $scope.selectedCountry,
            $scope.county, $scope.state).then(function (response) {
                $scope.ListAllCommodity2 = response;
                $scope.ListCommodity2 = angular.copy($scope.ListAllCommodity2);
            });
    }

    $scope.GetCommodity3V1 = function (selectedItem) {
        dataCostService.GetCommodity3V1($scope.sectorName, $scope.superRegionName, $scope.selectedSubSectors, $scope.selectedTimeLevel, $scope.selectedGeoGraphicLevel, $scope.selectedCommodity1, $scope.selectedCountry,
            $scope.county, $scope.state).then(function (response) {
                $scope.ListAllCommodity3 = response;
                $scope.ListCommodity3 = angular.copy($scope.ListAllCommodity3);
            });
    }

    $scope.GetAttributes1V1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetAttributes1V1(_filter).then(function (response) {
            $scope.ListAllAttributes1 = response;
            $scope.ListAttributes1 = angular.copy($scope.ListAllAttributes1);
        });
    }

    $scope.GetAttributes2V1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetAttributes2V1(_filter).then(function (response) {
            $scope.ListAllAttributes2 = response;
            $scope.ListAttributes2 = angular.copy($scope.ListAllAttributes2);
        });
    }

    $scope.GetSourceV1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetSourceV1(_filter).then(function (response) {
            $scope.ListAllSubSource = response;
            $scope.ListSubSource = angular.copy($scope.ListAllSubSource);
            //$scope.ListAllSource = response;
            //$scope.ListSource = angular.copy($scope.ListAllSource);
        });
    }

    $scope.GetLocation_v1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetLocation_v1(_filter).then(function (response) {
            $scope.ListAllGeoGraphicLevel = response;
            $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
        });
    }

    //$scope.GetLocation_v1 = function (selectedItem) {
    //    var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.subSector_Id, "timeLevel_Id": $scope.timeLevel_Id, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.country_Id, "county_Id": $scope.county_Id, "state_Id": $scope.state_Id };
    //    dataCostService.GetLocation_v1(_filter).then(function (response) {
    //        $scope.ListAllGeoGraphicLevel = response;
    //        $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
    //    });
    //}

    //ListAllCountries
    $scope.GetCountriesListv1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetCountriesListv1(_filter).then(function (response) {
            $scope.ListAllCountry = response;
            $scope.ListCountry = angular.copy($scope.ListAllCountries);
        });
    }

    //ListAllCountries
    $scope.GetStateListv1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetStateListv1(_filter).then(function (response) {
            $scope.ListAllState = response;
            $scope.ListState = angular.copy($scope.ListAllStates);
        });
    }

    //ListCounties
    $scope.GetCountyListv1 = function (selectedItem) {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state };
        dataCostService.GetCountyListv1(_filter).then(function (response) {
            $scope.ListAllCounty = response;
            $scope.ListCounty = angular.copy($scope.ListAllCounty);
        });
    }

    /**************************************************/

    $scope.ShowSelectedData = function (section) {
        if (section == 'subSector') {
            $scope.ListSubSector = _.where($scope.ListSubSector, { selected: true });
            $scope.GetDataForVersion1Selection();
        }
        else if (section == 'subSource') {
            $scope.ListSubSource = _.where($scope.ListSubSource, { selected: true });
        }
        else if (section == 'subCommodity1') {
            $scope.ListCommodity1 = _.where($scope.ListCommodity1, { selected: true });
        }
        else if (section == 'geoGraphicLevel') {
            $scope.ListGeoGraphicLevel = _.where($scope.ListGeoGraphicLevel, { selected: true });
        }
        else if (section == 'timeLevel') {
            $scope.ListTimeLevel = _.where($scope.ListTimeLevel, { selected: true });
        }
    }

    $scope.DeselectSelection = function (section, selectedItem) {
        if (section == 'subSector') {
            $scope.ListSubSector = angular.copy($scope.ListAllSubSector);
            $scope.selectedSubSectors.indexOf(selectedItem.Subsector_Id).selected = false;
            //$scope.selectedSubSectors = [];
            //$scope.selectedSubSectorMuted = true;
        }
        else if (section == 'subSource') {
            $scope.ListSubSource = angular.copy($scope.ListAllSubSource);
            $scope.selectedSubSource = [];
            $scope.selectedSubSourceMuted = true;
        }
        else if (section == 'subCommodity1') {
            $scope.ListCommodity1 = angular.copy($scope.ListAllCommodity1);
            $scope.selectedCommodity1 = [];
            $scope.selectedCommodity1Muted = true;

        }
        else if (section == 'subCommodity2') {
            $scope.ListCommodity2 = angular.copy($scope.ListAllCommodity2);
            $scope.selectedCommodity2 = [];
            $scope.selectedCommodity1Muted = true;

        }
        else if (section == 'subCommodity3') {
            $scope.ListCommodity3 = angular.copy($scope.ListAllCommodity3);
            $scope.selectedCommodity3 = [];
            $scope.selectedCommodity1Muted = true;

        }
        else if (section == 'attribute1') {
            $scope.ListAttributes1 = angular.copy($scope.ListAllAttributes1);
            $scope.selectedAttribute1 = [];
            $scope.selectedAttribute1Muted = true;

        }
        else if (section == 'attribute2') {
            $scope.ListAttributes2 = angular.copy($scope.ListAllAttributes2);
            $scope.selectedAttribute2 = [];
            $scope.selectedAttribute2Muted = true;
        }
        else if (section == 'geoGraphicLevel') {
            $scope.ListGeoGraphicLevel = angular.copy($scope.ListAllGeoGraphicLevel);
            $scope.selectedGeoGraphicLevel = [];
            $scope.selectedGeoGraphicLevelMuted = true;

        } else if (section == 'country') {
            $scope.ListCountry = angular.copy($scope.ListAllCountry);
            $scope.selectedCountry = [];
            $scope.selectedCountryMuted = true;
        }
        else if (section == 'state') {
            $scope.ListState = angular.copy($scope.ListAllState);
            $scope.state = [];
            $scope.stateMuted = true;
        }
        else if (section == 'county') {
            $scope.ListCounty = angular.copy($scope.ListAllCounty);
            $scope.county = [];
            $scope.selectedCountyMuted = true;
        }
        else if (section == 'timeLevel') {
            $scope.ListTimeLevel = angular.copy($scope.ListAllTimeLevel);
            $scope.selectedTimeLevel = [];
            $scope.selectedTimeLevelMuted = true;
        }
    }

    $scope.GetDataSelectionCost = function () {
        var _filter = { "SectorName": $scope.sectorName, "SuperRegionName": $scope.superRegionName, "subSector_Id": $scope.selectedSubSectors, "timeLevel_Id": $scope.selectedTimeLevel, "locationLevelName": $scope.selectedGeoGraphicLevel, "c_Tier1_Id": $scope.selectedCommodity1, "source_Id": $scope.selectedSubSource, "country_Id": $scope.selectedCountry, "county_Id": $scope.county, "state_Id": $scope.state, "startDate": $scope.startDate, "endDate": $scope.endDate };
          dataCostService.GetDataSelectionCost(_filter).then(function (response) {
            $scope.selectedDataCost = response;
            $scope.selectedDataCost.ChargeableData = response[0].RecordCount - response[0].UserCredit;
        });
    }

    //$scope.showSelectedThemes = function (value) {
    //    if (value)
    //        $scope.themes = _.where($scope.Allthemes, { selected: true });
    //    else
    //        $scope.themes = $scope.Allthemes;
    //}

    //$scope.GetCommodity = function (selectedItem) {
    //    $scope.subSectorID = selectedItem.Subsector_Id;
    //    selectedItem.selected ? selectedItem.selected = false : selectedItem.selected = true;
    //    dataCostService.GetCommoditiesBySubSectorID($scope.subSectorID).then(function (response) {
    //        $scope.commodities = [];
    //        $scope.subCommodities = [];
    //        $scope.commodities = response;
    //    });
    //}



    //$scope.GetSubCommodity = function (Tier1ID, $index) {
    //    $scope.Tier1ID = Tier1ID;
    //    $scope.CommodityIndex = $index;
    //    dataCostService.GetSubCommodity($scope.subSectorID, $scope.Tier1ID).then(function (response) {
    //        $scope.subCommodities = [];
    //        $scope.subCommodities = response;
    //    });
    //}
    //$scope.GetGeoArea = function (Tier2ID, $index) {
    //    $scope.SubCommodityIndex = $index;
    //}


    $scope.ClearRegionSelection = function () {

        $scope.superRegions = [];
        $scope.AllsuperRegions = [];

        //$scope.sectorID = 0;
        //$scope.sectorName = "";
        //$scope.regionName = "";
        //$scope.subSectorID = 0;
        //$scope.Tier1ID = 0;

        //$scope.SectorIndex = -1;
        //$scope.IndustryIndex = -1;
        //$scope.ThemeIndex = -1;
        //$scope.CommodityIndex = -1;
        //$scope.SubCommodityIndex = -1;

    }




}]);

app.factory('dataCostService', ['$http', '$q', function ($http, $q) {

    var self = this;
    var baseURL = "http://74.63.228.198:88/api/"; //ngAuthSettings.apiServiceBaseUri;
    self.AppBaseUrl = baseURL;
    /******************************************************************************************************************************/
    self.GetSectors = function () {
        var defer = $q.defer();
        $http({
            //url: baseURL + 'Authentication/LoginAndGenToken',
            url: '/api/Common/GetSectors',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    /////Get Super Region
    self.GetSuperRegion = function () {
        var defer = $q.defer();
        $http({
            //url: baseURL + 'Authentication/LoginAndGenToken',
            url: '/api/Common/GetSuperRegion',
            method: "GET",
            data: JSON.stringify({ "superRegion": '' }),
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }


    //self.GetThemesBySectorID = function (sectorID) {
    //    var defer = $q.defer();
    //    $http({
    //        url: baseURL + 'Common/GetThemesBySectorID/' + sectorID,
    //        method: "GET",
    //        headers: { 'Content-Type': 'application/json', },
    //    }).success(function (data, status, headers, config) {
    //        return defer.resolve(data);
    //    }).error(function (failedResponse, status, headers, config) {
    //        return defer.reject(failedResponse);
    //    });

    //    return defer.promise;
    //}

    //self.GetCommoditiesBySubSectorID = function (subSectorID) {
    //    var defer = $q.defer();
    //    $http({
    //        url: baseURL + 'Common/GetCommoditiesBySubSectorID/' + subSectorID,
    //        method: "GET",
    //        headers: { 'Content-Type': 'application/json', },
    //    }).success(function (data, status, headers, config) {
    //        return defer.resolve(data);
    //    }).error(function (failedResponse, status, headers, config) {
    //        return defer.reject(failedResponse);
    //    });

    //    return defer.promise;
    //}

    //self.GetSubCommodity = function (subSectorID, TierID) {
    //    var defer = $q.defer();
    //    $http({
    //        url: baseURL + 'Common/GetSubCommoditiesBySubSectorID',
    //        method: "POST",
    //        headers: { 'Content-Type': 'application/json', },
    //        data: JSON.stringify({ "SubSectorID": subSectorID, "Tier1_ID": TierID })
    //    }).success(function (data, status, headers, config) {
    //        return defer.resolve(data);
    //    }).error(function (failedResponse, status, headers, config) {
    //        return defer.reject(failedResponse);
    //    });

    //    return defer.promise;
    //}

    self.GetSubSectorBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSubSectorBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCommodityBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommodityBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetGeographicalDataBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetGeographicalDataBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSourceDataBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSourceDataBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetTimeLevelBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetTimeLevelBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetDataBasedonSectorAndSuperRegion = function (SectorName, SuperRegionName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetDataBasedonSectorAndSuperRegion',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetDataForVersion1Selection = function (_filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetDataForVersion1Selection',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify(_filter)
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetDataSelectionCost = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSearchDataCost',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id, "StartDate": filter.startDate, "endDate": filter.endDate })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    /**************************** V1 methods ************************************/

    self.GetSubSectorV1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSubSectorBasedonSectorAndSuperRegion_V1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName, "ListSubSectorId": subSector_Id, "ListTimeLevelId": timeLevel_Id, "LocationLevelName": locationLevelName, "ListCTier1Id": c_Tier1_Id, "ListSourceId": source_Id, "ListCountryId": country_Id, "ListCountyId": county_Id, "ListStateId": state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Commodity1 v1
    self.GetCommodity1V1 = function (SectorName, SuperRegionName, subSector_Id, timeLevel_Id, locationLevelName, c_Tier1_Id, source_Id, country_Id, county_Id, state_Id) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommodity1V1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName, "ListSubSectorId": subSector_Id, "ListTimeLevelId": timeLevel_Id, "LocationLevelName": locationLevelName, "ListCTier1Id": c_Tier1_Id, "ListSourceId": source_Id, "ListCountryId": country_Id, "ListCountyId": county_Id, "ListStateId": state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //commodity2_v1
    self.GetCommodity2V1 = function (SectorName, SuperRegionName, subSector_Id, timeLevel_Id, locationLevelName, c_Tier1_Id, source_Id, country_Id, county_Id, state_Id) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommodity2V1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName, "ListSubSectorId": subSector_Id, "ListTimeLevelId": timeLevel_Id, "LocationLevelName": locationLevelName, "ListCTier1Id": c_Tier1_Id, "ListSourceId": source_Id, "ListCountryId": country_Id, "ListCountyId": county_Id, "ListStateId": state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Commodity3_v1
    //
    self.GetCommodity3V1 = function (SectorName, SuperRegionName, subSector_Id, timeLevel_Id, locationLevelName, c_Tier1_Id, source_Id, country_Id, county_Id, state_Id) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommodity3V1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": SectorName, "SuperRegionName": SuperRegionName, "ListSubSectorId": subSector_Id, "ListTimeLevelId": timeLevel_Id, "LocationLevelName": locationLevelName, "ListCTier1Id": c_Tier1_Id, "ListSourceId": source_Id, "ListCountryId": country_Id, "ListCountyId": county_Id, "ListStateId": state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Attribute1_v1
    //GetAttributes1
    self.GetAttributes1V1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetAttributes1V1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    //Attribute2_v1    
    self.GetAttributes2V1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetAttributes2V1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Source_v1    
    self.GetSourceV1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSourceV1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Geographiclevel_V1
    self.GetLocation_v1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocationV1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //Country_v1
    self.GetCountriesListv1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCountriesListv1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //State_v1
    self.GetStateListv1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetStateListv1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    //county_v1
    self.GetCountyListv1 = function (filter) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCountiesListV1',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: JSON.stringify({ "SectorName": filter.SectorName, "SuperRegionName": filter.SuperRegionName, "ListSubSectorId": filter.subSector_Id, "ListTimeLevelId": filter.timeLevel_Id, "LocationLevelName": filter.locationLevelName, "ListCTier1Id": filter.c_Tier1_Id, "ListSourceId": filter.source_Id, "ListCountryId": filter.country_Id, "ListCountyId": filter.county_Id, "ListStateId": filter.state_Id })
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });
        return defer.promise;
    }

    return self;
}]);
