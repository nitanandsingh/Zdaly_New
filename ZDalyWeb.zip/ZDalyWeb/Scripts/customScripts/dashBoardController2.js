﻿/**
 * Let's you use underscore as a service from a controller.
 * Got the idea from: http://stackoverflow.com/questions/14968297/use-underscore-inside-controllers
 * @author: Andres Aguilar https://github.com/andresesfm
 */
angular.module('underscore', []).factory('_', ['$window', function ($window) {
    return $window._; // assumes underscore has already been loaded on the page
}]);

var app = angular.module('app', ['underscore', 'ui.autocomplete', 'infinite-scroll']);
app.directive('ngUpdateHidden', function () {
    return function (scope, el, attr) {
        var model = attr['ngModel'];
        scope.$watch(model, function (nv) {
            el.val(nv);
            //console.log(nv)
        });
    };
})
app.controller('dashboardController', ['$scope', '$compile', 'dashboardService', '_', '$timeout', function ($scope, $compile, dashboardService, _, $timeout) {

    $scope.AllSectors = [];
    $scope.sectors = [];
    $scope.themes = [];
    $scope.superRegions = [];
    $scope.commodities = [];
    $scope.subCommodities = [];
    $scope.subSectors = [];
    $scope.sectorDetails = [];
    $scope.countries = [];
    $scope.states = [];
    $scope.counties = [];
    $scope.AllCommodities = [];
    $scope.selectedData = {
        sector: {
            sectorName: "",
            superRegion: "",
            SubsectorName: "",
            SubsectorID: "",
        },
        commodity1: {
            Tier1_Id: "",
            Tier1_Commodity: "",
        },
        commodity2: {
            Tier2_Id: "",
            Tier2_Commodity: "",
        },
        commodity3: {
            Tier3_Id: "",
            Tier3_Commodity: "",
        },
        location: {
            LocationLevel: "",
        },
        country: {
            Country_Id: "",
            Country: "",
        },
        state: {
            State_Id: "",
            State: "",
        },
        county: {
            County_Id: "",
            County: "",
        },
    }

    $scope.IsLeftMenuOpen = false;
    $scope.SearchType = "COMMODITY";
    $scope.sectorID = 0;
    $scope.sectorName = "";
    $scope.regionName = "";
    $scope.subSectorID = 0;
    $scope.Tier1ID = 0;
    $scope.Tier2ID = 0;
    $scope.Tier3ID = 0;
    $scope.CountryID = 0;
    $scope.StateID = 0;
    $scope.CountyID = 0;
    $scope.SelectedCommodity = "";
    $scope.IsCommoditySelected = false;
    $scope.SelectedMap = "";

    $scope.TimeLevels = [{ TimeLevel_id: 1, Frequency: "Annual" }, { TimeLevel_id: 2, Frequency: "Monthly" }, { TimeLevel_id: 4, Frequency: "Season" }, { TimeLevel_id: 5, Frequency: "Weekly" }, { TimeLevel_id: 3, Frequency: "Point in Time" }];
    $scope.TimeLevelsSelectedOption = $scope.TimeLevels[1].TimeLevel_id;
    // $scope.SectorIndex;
    // $scope.IndustryIndex;
    // $scope.ThemeIndex;
    // $scope.CommodityIndex;
    // $scope.SubCommodityIndex;

    dashboardService.GetSectors().then(function (response) {
        $scope.AllSectors = response;
        $scope.sectors = _.uniq($scope.AllSectors, function (sector) { return sector.Sectorname; });
        $scope.superRegions = $scope.GetSuperRegion("", "");
        $scope.GetSectorDetails("");
    });

    $scope.GetSuperRegion = function (sectorName, $index) {
        if (sectorName != "") {
            $scope.ClearSelection();
            $scope.SectorIndex = $index;
            $scope.sectorName = sectorName;
            $scope.selectedData.sector.sectorName = sectorName;
        }

        dashboardService.GetSuperRegion(sectorName).then(function (response) {
            $scope.superRegions = response; //_.where($scope.AllSectors, { SectorName: sectorName });
        });
        $(".right-part").fadeOut();
    }

    $scope.GetSectorDetails = function (sectorName) {
        dashboardService.GetSectorDetails(sectorName).then(function (response) {
            $scope.sectorDetails = response;
        });
    }

    $scope.GetSubSectors = function (superRegion, $event) {
        if ($scope.sectorName == undefined || $scope.sectorName == "" || $scope.sectorName == null) {
            $event.stopPropagation();
            $('.left-part').show();
        } else {
            $scope.selectedData.sector.superRegion = superRegion;
            $scope.superRegion = superRegion;
            dashboardService.GetSubSectors($scope.sectorName, superRegion).then(function (response) {
                $scope.subSectors = response;
                $(".dismiss4, .dismiss5, .dismiss6, .dismiss7, .dismiss8").fadeOut();
                $(".br-commodity, .br-location").parent().fadeOut();
                var cls = $('.slct-type-dropdown li.active').attr('id');
                $scope.industryClass = cls.trim() + "-h";
                if ($($event.target).parent().parents('.mainmega-popup').length > 0) {
                    $scope.IsLeftMenuOpen = true;
                    $(".mainmega-popup").find(".right-part").removeClass("col-lg-7").addClass("col-lg-12");
                    $(".mainmega-popup").find("#Breadcrumb2").fadeIn();
                }
                else {
                    $scope.IsLeftMenuOpen = false;
                }
            });
            $scope.GetLocationLevel();
        }
    }

    $scope.GetCommodity = function (subSector, $event) {
        $scope.bIndustry = subSector.SubsectorName;
        $scope.selectedData.sector.SubsectorName = subSector.SubsectorName;
        $scope.selectedData.sector.SubsectorID = subSector.Subsector_Id;
        $(".br-commodity").parent().fadeIn();
        $("#Industry, .br-commodity").fadeIn();
        $scope.Tier1ID = 0;
        $scope.subSectorID = subSector.Subsector_Id;
        dashboardService.GetCommoditiesBySubSectorID($scope.subSectorID).then(function (response) {
            $scope.commodities = response;
            $(".dismiss5, .left-part").fadeOut();
            if (response.length == 0) {
                $event.stopPropagation();
                $(".dismiss4").fadeOut();
            }
            else {
                $('.dismiss4').fadeIn();
            }
        });
        $("#Commodity, .dismiss6, .dismiss7, .dismiss8").fadeOut();
        $scope.GetLocationLevel();
    }

    $scope.GetCommodityH = function (subSector, $event) {
        $scope.subSectorID = subSector.Subsector_Id;
        dashboardService.GetCommoditiesBySubSectorID($scope.subSectorID).then(function (response) {
            $scope.commodities = response;
            if ($scope.selectedData.sector.SubsectorName == "") {
                $(".dismiss5, .dismiss9").fadeOut();
            }

            if (response.length == 0) {
                $event.stopPropagation();
                $(".dismiss4").fadeOut();
            }
            else {
                $('.dismiss4').fadeIn();
            }
        });
        $("#Commodity").fadeOut();
    }

    //$scope.GetCommodityO = function (subSectorName) {
    //    var subSector = _.where($scope.subSectors, { SubsectorName: subSectorName });

    //    $scope.bIndustry = subSector.SubsectorName;
    //    $scope.selectedData.sector.SubsectorName = subSector.SubsectorName;
    //    $scope.selectedData.sector.SubsectorID = subSector.Subsector_Id;
    //    $(".br-commodity").parent().fadeIn();
    //    $("#Industry, .br-commodity").fadeIn();
    //    $scope.Tier1ID = 0;
    //    $scope.subSectorID = subSector.Subsector_Id;
    //    dashboardService.GetCommoditiesBySubSectorID($scope.subSectorID).then(function (response) {
    //        $scope.commodities = response;
    //        $(".dismiss5, .left-part").fadeOut();
    //        if (response.length == 0) {
    //            $event.stopPropagation();
    //            $(".dismiss4").fadeOut();
    //        }
    //        else {
    //            $('.dismiss4').fadeIn();
    //        }
    //    });
    //    $("#Commodity, .dismiss6, .dismiss7, .dismiss8").fadeOut();
    //    $scope.GetLocationLevel();
    //}

    $scope.GetSubCommodity = function (subCommodity, $event) {
        $scope.bCommodity = subCommodity.Tier1_Commodity;

        if (subCommodity.Tier2_count == 0) {
            $event.stopPropagation();
            $(".dismiss5").fadeOut();
            $("#Commodity").fadeIn();
            var cls = $('.slct-type-dropdown li.active').attr('id');
            $($event.currentTarget).siblings().removeClass('active').attr('id', '');
            $($event.currentTarget).siblings().removeClass(cls.trim());
            $($event.currentTarget).addClass(cls.trim());
            $($event.currentTarget).addClass('active').attr('id', 'active');
        }
        else {

            $scope.selectedData.commodity1.Tier1_Id = subCommodity.Tier1_Id;
            $scope.selectedData.commodity1.Tier1_Commodity = subCommodity.Tier1_Commodity;
            $scope.Tier1ID = subCommodity.Tier1_Id;

            $(".dismiss5, #Commodity").fadeIn();
            $(".selcomopen_second").show();
            dashboardService.GetSubCommodity($scope.subSectorID, $scope.Tier1ID).then(function (response) {
                $scope.subCommodities = response;
            });
        }
        $scope.GetLocationLevel();
    }

    $scope.GetSubCommodityH = function (subCommodity, $event) {
        if (subCommodity.Tier2_count == 0) {
            $event.stopPropagation();
            $(".dismiss5").fadeOut();
        }
        else {
            $scope.Tier1ID = subCommodity.Tier1_Id;
            $(".dismiss5").fadeIn();
            $("#SubCommodity").fadeOut();
            dashboardService.GetSubCommodity($scope.subSectorID, $scope.Tier1ID).then(function (response) {
                $scope.subCommodities = response;
            });
        }
    }

    $scope.GetClickTimeLevel = function (a) {
        //console.log("fff");
        //console.log(a)
    }
    // $scope.GetSubCommodityO = function ($event) {
    //     if ($scope.selectedData.sector.SubsectorID != "" && $scope.selectedData.sector.SubsectorID) {
    //         dashboardService.GetSubCommodity($scope.selectedData.sector.SubsectorID, $scope.selectedData.commodity1.Tier1_Id).then(function (response) {
    //             $scope.commodities = response;
    //         });
    //     }
    //     else {
    //         $(".dismiss5").fadeOut();
    //     }
    // }

    $scope.GetGeoArea = function (Tier2ID, $index) {
        $scope.SubCommodityIndex = $index;
    }

    $scope.GetTier2ID = function (subCommodity) {
        $scope.selectedData.commodity2.Tier2_Id = subCommodity.Tier2_Id;
        $scope.selectedData.commodity2.Tier2_Commodity = subCommodity.Tier2_Commodity;
        $scope.Tier2ID = subCommodity.Tier2_Id;
        $scope.bSubCommodity = subCommodity.Tier2_Commodity;
        $("#SubCommodity").fadeIn();
        $scope.GetLocationLevel();
    }

    $scope.GetTier3ID = function (sc) {
        $scope.selectedData.commodity3.Tier3_Id = sc.Tier3_Id;
        $scope.selectedData.commodity3.Tier3_Commodity = sc.Tier3_Commodity;
        $scope.Tier3ID = sc.Tier3_Id;
        $scope.GetLocationLevel();
    }

    $scope.GetLocationLevel = function () {
        //dashboardService.GetLocationLevel().then(function (response) {
        //    $scope.locationlevel = response;
        //});

        dashboardService.GetLocationLevel_v1($scope.sectorName, $scope.superRegion, $scope.subSectorID, $scope.Tier1ID, $scope.Tier2ID, $scope.Tier3ID).then(function (response) {
            $scope.locationlevel = response;
        });
    }

    $scope.GetCountries = function (locationLevel, $event) {
        var SSID = $scope.subSectorID;
        var T1ID = $scope.Tier1ID;
        var T2ID = $scope.Tier2ID;
        var T3ID = $scope.Tier3ID;
        $scope.locationLevel = locationLevel.LocationLevel;
        $scope.bGeoLevel = locationLevel.LocationLevel;
        $scope.selectedData.location.LocationLevel = locationLevel.LocationLevel,
        $("#GeoLevel").fadeIn();
        dashboardService.GetCountries_v1(SSID, T1ID, T2ID, T3ID, $scope.locationLevel).then(function (response) {
            var c = _.uniq(response, function (cn) { return cn.Country; });
            $scope.countries = c;
            if (c.length == 0) {
                $event.stopPropagation();
                $(".dismiss6").fadeOut();
            }
            else {
                $(".dismiss6").fadeIn();
            }
        });
    }

    $scope.GetStates = function (country, $event) {
        $scope.CountryID = country.Country_Id;
        $scope.bCountry = country.Country;
        $scope.selectedData.country.Country_Id = country.Country_Id;
        $scope.selectedData.country.Country = country.Country;
        var SSID = $scope.subSectorID;
        var T1ID = $scope.Tier1ID;
        var T2ID = $scope.Tier2ID;
        var T3ID = $scope.Tier3ID;
        $(".br-location").parent().fadeIn();
        dashboardService.GetStates($scope.CountryID, SSID, T1ID, T2ID, T3ID).then(function (response) {
            $scope.states = response;
            if (response.length == 0) {
                $event.stopPropagation();
                $(".dismiss7").fadeOut();
            }
        });
    }

    $scope.GetCounties = function (state, $event) {
        var CID = $scope.CountryID;
        $scope.bState = state.State;
        $scope.selectedData.state.State_Id = state.State_Id;
        $scope.selectedData.state.State = state.State;

        var SSID = $scope.subSectorID;
        var T1ID = $scope.Tier1ID;
        var T2ID = $scope.Tier2ID;
        var T3ID = $scope.Tier3ID;
        dashboardService.GetCounties(CID, state.State_Id, SSID, T1ID, T2ID, T3ID).then(function (response) {
            var cont = _.uniq(response, function (cnt) { return cnt.County; });
            $scope.counties = cont;
            if (response.length == 0) {
                $event.stopPropagation();
                $(".dismiss8").fadeOut();
            }
        });
    }

    $scope.CountiesBR = function (county, $event) {
        $scope.bCounty = county.County;
        $scope.selectedData.county.Country_Id = county.County_Id;
        $scope.selectedData.county.Country = county.County;
        //$scope.GetAttributes1({
        //    sector: {
        //        SectorName: $scope.sectorName,
        //        SuperRegion: $scope.superRegion,
        //    },
        //    SubSector: {
        //        Subsector_Id: $scope.subSectorID,
        //    },
        //    commodity1: {
        //        Tier1_Id : $scope.Tier1ID,
        //    },
        //    commodity2: {
        //        Tier2_Id: $scope.Tier2ID,
        //    },
        //    commodity3: {
        //        Tier3_Id: $scope.Tier3ID,
        //    },
        //    Countries: {
        //        Country_Id : $scope.CountryID
        //    },
        //    States: {
        //        State_Id :$scope.StateID
        //    },
        //    Counties: {
        //        County_Id: $scope.CountyID
        //    }
        //});
    }

    $scope.UpdateBreadCum = function (text, level) {
        $scope.bSectorName = $(".slct-type-dropdown li.active a span.sector-name").text();
        $scope.breadCumTextSR = text;
        $(".left-part").fadeOut();
        $("#Breadcrumb").fadeIn();
    }

    $scope.ChangeContents = function () {
        if ($scope.IsLeftMenuOpen) {
            $scope.content1 = "#content-11";
            $scope.content2 = "#content-22";
            $scope.content3 = "#content-33";
            $scope.content4 = "#content-44";
            $scope.content5 = "#content-55";
            $scope.content6 = "#content-66";
            $scope.content7 = "#content-77";
            $scope.content8 = "#content-88";
        }
        else {
            $scope.content1 = "#content-1";
            $scope.content2 = "#content-2";
            $scope.content3 = "#content-3";
            $scope.content4 = "#content-4";
            $scope.content5 = "#content-5";
            $scope.content6 = "#content-6";
            $scope.content7 = "#content-7";
            $scope.content8 = "#content-8";
        }
    }

    $scope.ChangeSearchPlaceholder = function ($event) {
        var tab = "";
        if ($($event.target).prop('nodeName').toLowerCase() == "button") {
            tab = $(".com-loc-tabs").find("li:not(.active)")[0].innerText.trim();
        }
        else {
            tab = ($event.target).text;
        }

        $scope.SearchType = tab.toUpperCase();
    }

    $scope.ClearBreadcrumb = function () {
        $scope.bCommodity = "";
        $scope.bIndustry = "";
        $scope.bSubCommodity = "";
        $(".br-commodity, .br-commodity li").parent().hide();
    }

    $scope.GetAttributes1 = function (Zdata) {
        dashboardService.GetAttributes1(Zdata).then(function (response) {
            $scope.Attributes1 = response;
        });
    }

    var global = false;
    $scope.myOption = {
        options: {
            appendTo: "#ui-c-tags",
            html: true,
            focusOpen: false,
            onlySelectValid: true,
            minLength: 2,
            delay: 0,
            search: function (event, ui) {
                window.pageIndex = 0;
            },
            source: function (request, response) {
                dashboardService.GetCommodities(request.term, "", "").then(function (res) {
                    $scope.AllCommodities = res;
                    var result = [];
                    angular.forEach($scope.AllCommodities, function (s) {
                        result.push({
                            label: $compile('<a class="ui-menu-add"><span class="label"> <span style="color:#000000" class="txt-commodity" tierid=' + s.Tier + '>' + s.Commodity + ' in </span><span style="color:#10a9e5">' + s.SubsectorName + ', ' + s.SuperRegion + '</span></span></a>')($scope),
                            value: s.Commodity
                        });
                    });
                    if (!result.length) {
                        result.push({
                            label: 'not found',
                            value: ''
                        });
                    }
                    response(result);
                });
            },
            select: function (event, ui) {
                var commodity = ui.item.value; // .split(",")[0];
                var level = $(ui.item.label).find('.txt-commodity').attr('tierid');
                $scope.SelectedCommodity = commodity;
                //console.log(level)
                event.stopPropagation();
            },
        },
        methods: {},
    }

    $scope.myOption1 = {
        options: {
            //appendTo: "#inner-c-tags",
            html: true,
            focusOpen: false,
            onlySelectValid: true,
            minLength: 2,
            delay: 0,
            search: function (event, ui) {
                window.pageIndex = 0;
            },
            source: function (request, response) {
                if ($scope.SearchType.toLowerCase() == "location") {

                    var SSID = $scope.subSectorID;
                    var T1ID = $scope.Tier1ID;
                    var T2ID = $scope.Tier2ID;
                    var T3ID = $scope.Tier3ID;

                    dashboardService.GetLocation_v1(request.term, $scope.sectorName, $scope.superRegion, SSID, T1ID, T2ID, T3ID).then(function (res) {
                        $scope.AllLocation = res;
                        var result = [];
                        angular.forEach($scope.AllLocation, function (s) {
                            var str = "";
                            if (s.Tier == "1") {
                                str = s.SubsectorName + ', ' + s.SuperRegion;
                            }
                            else if (s.Tier == "2") {
                                str = s.Country;
                            }
                            else if (s.Tier == "3") {
                                str = s.State + ', ' + s.Country;
                            }

                            result.push({
                                label: $compile('<a class="ui-menu-add"><span class="label"> <span style="color:#000000" class="txt-commodity" tierid=' + s.Tier + '>' + s.LocationName + ' in </span><span style="color:#10a9e5">' + str + '</span></span></a>')($scope),
                                value: s.LocationName
                            });
                        });

                        if (!result.length) {
                            result.push({
                                label: 'not found',
                                value: ''
                            });
                        }
                        response(result);
                    });
                }
                else {
                    dashboardService.GetCommodities(request.term, $scope.sectorName, $scope.superRegion).then(function (res) {
                        $scope.AllCommodities = res;
                        var result = [];
                        angular.forEach($scope.AllCommodities, function (s) {
                            result.push({
                                label: $compile('<a class="ui-menu-add"><span class="label"> <span style="color:#000000" class="txt-commodity" tierid=' + s.Tier + '>' + s.Commodity + ' in </span><span style="color:#10a9e5">' + s.SubsectorName + ', ' + s.SuperRegion + '</span></span></a>')($scope),
                                value: s.Commodity
                            });
                        });
                        if (!result.length) {
                            result.push({
                                label: 'not found',
                                value: ''
                            });
                        }
                        response(result);
                    });
                }
            },
            select: function (event, ui) {
                var value = ui.item.value;
                var level = $(ui.item.label).find('.txt-commodity').attr('tierid');

                if ($scope.SearchType.toLowerCase() != "location") {
                    var str = $(ui.item.label).text().split(/in/)[1];
                    str = str.toString().substring(0, str.lastIndexOf(","));
                    str = str + "@#$" + value;

                    $scope.ActiveSelectedCommodity(str, level, event);
                }
                else {
                    var str = $(ui.item.label).text();
                    $scope.ActiveSelectedLocation(str, level, event);
                }
                event.stopPropagation();
            },
        },
        methods: {},
    }

    $scope.ActiveSelectedCommodity = function (data, level, event) {
        $scope.ChangeContents();

        var industry = data.split("@#$")[0];
        var commodity = data.split("@#$")[1];
        var subcommodity = "";
        var active = ""; //$scope.industryClass.replace("-h", "");



        $($scope.content1).find("li").each(function () {
            if ($(this).find("span").text().toLowerCase().trim() == industry.toLowerCase().trim()) {
                $(this).trigger("click");
            }
        });

        $scope.$apply();
        setTimeout(function () {
            if (parseInt(level) >= 1) {
                $($scope.content2).find("li").each(function () {
                    if ($(this).find("span").text().trim().toLowerCase() == commodity.trim().toLowerCase()) {
                        $(this).trigger("click");
                    }
                });
            }

            var com = "";
            dashboardService.GetCommoditiesByTier(level, commodity).then(function (response) {
                if (response != null) {
                    com = response[0].Tier1_Commodity;
                }
            });

            setTimeout(function () {
                if (com != "") {
                    $($scope.content2).find("li").each(function () {
                        if ($(this).find("span").text().trim().toLowerCase() == com.trim().toLowerCase()) {
                            $(this).trigger("click");
                        }
                    });

                    $scope.$apply();

                    setTimeout(function () {
                        $($scope.content3).find("li").each(function () {
                            if ($(this).find("span").text().trim().toLowerCase() == commodity.trim().toLowerCase()) {
                                $(this).trigger("click");
                            }
                        });
                    }, 400);
                }
            }, 400)
        }, 400);

        return false;
    }

    $scope.ActiveSelectedLocation = function (data, level, event) {
        var value = data.split(/in/)[1].trim();
        var commodity = data.split(/in/)[0].trim();
        var state = "";

        var active = $scope.industryClass.replace("-h", "");
        var locations;

        if (parseInt(level) == 2) {
            locations = _.where($scope.AllLocation, { LocationName: commodity, State: commodity });
        }
        else if (parseInt(level) == 3) {
            state = value.split(/,/)[0].trim();
            locations = _.where($scope.AllLocation, { LocationName: commodity, State: state });
        }
        else {
            locations = _.where($scope.AllLocation, { LocationName: commodity });
        }

        $($scope.content8).find("li").each(function () {
            if ($(this).find("span").text().toLowerCase().trim() == locations[0].LocationLevel.toLowerCase().trim()) {
                $(this).trigger("click");
            }
        });

        $scope.$apply();
        setTimeout(function () {
            if (parseInt(level) >= 1) {
                $($scope.content4).find("li").each(function () {
                    if ($(this).find("span").text().trim().toLowerCase() == locations[0].Country.trim().toLowerCase()) {
                        $(this).trigger("click");
                    }
                });
            }

            $scope.$apply();
            setTimeout(function () {
                $($scope.content5).find("li").each(function () {
                    if ($(this).find("span").text().trim().toLowerCase() == locations[0].State.trim().toLowerCase()) {
                        $(this).trigger("click");
                    }
                });
                $scope.$apply();

                setTimeout(function () {
                    $($scope.content6).find("li").each(function () {
                        if ($(this).find("span").text().trim().toLowerCase() == locations[0].County.trim().toLowerCase()) {
                            $(this).trigger("click");
                        }
                    });
                }, 400);
            }, 400);
        }, 400);

        return false;
    }

    $scope.mapitemselected = function (item) {
        $scope.mapselectedItem = item;
        $scope.SelectedMap = item;
        //alert($scope.SelectedCommodity);
        //alert(item.MapName);
    }

    $scope.GetMaps = function (commodity, $event) {
        //$scope.SelectedCommodity.CommodityID = commodity.CommodityID;
        dashboardService.GetMaps(214).then(function (response) {
            $scope.maps = response;
            //if (response.length == 0) {
            //    $event.stopPropagation();
            //    $(".dismiss9").fadeOut();
            //}
        });
    }

    $scope.ClearSelection = function () {
        $scope.themes = [];
        $scope.superRegions = [];
        $scope.commodities = [];
        $scope.subCommodities = [];
        $scope.sectorID = 0;
        $scope.sectorName = "";
        $scope.regionName = "";
        $scope.subSectorID = 0;
        $scope.Tier1ID = null;
        $scope.SectorIndex = -1;
        $scope.IndustryIndex = -1;
        $scope.ThemeIndex = -1;
        $scope.CommodityIndex = -1;
        $scope.SubCommodityIndex = -1;
    }

    $scope.temptimeLevelID = 0;
    //Code for Charting
    //static values for development purposes
    $scope.tempCommodityID = 76;
    $scope.tempLocationID = 3364;
    var commodityID = $scope.tempCommodityID;
    var locationID = $scope.tempLocationID;
    $scope.SelectedCommodity = 'CORN';
    var offset = 2;
    var size = 2;
    var loadMoreData = true;
    $scope.SelectChange = function () {
        //console.log(33)
    }
    $scope.busy = false;
    $scope.$watch('SelectedCommodity', function () {
        //console.log($scope.SelectedCommodity);
    });
    //Watch event on two temporary textboxes for CommodityID and LocationID
    $scope.loadAgain = function () {

        commodityID = $scope.tempCommodityID;
        locationID = $scope.tempLocationID;
        offset = 0;
        size = 2;
        $('#childChartDiv').html("");       
        $scope.GetAttributesForRibbonAndSubMenu();
        $scope.GetDataForTopTwoCharts();
        loadMoreData = true;
        $scope.loadMore();
    }
    //$scope.firstChart

    var chartTimeLevelDropdown = "";
    var chartLocationLevelDropdown = "";
    //Get Data for top two charts by commodity ID and location ID
    $scope.GetDataForTopTwoCharts = function () {
        dashboardService.GetTopChartsData(locationID, commodityID, offset, size).then(function (response) {

            if (response.length != 0) {
                for (var i = 0; i < response.length; i++) {
                    chartTimeLevelDropdown = "<option value='0'>Time Level</option>"; chartLocationLevelDropdown = "<option value='0'>TIME</option>";
                    chartUnitsDropdown = "<option value='0'>Units</option>";
                    chartSourcesDropdown = "<option value='0'>Sources</option>";

                    minMaxyear = response[i].MinMaxYear;

                    //Time level
                    angular.forEach(response[i].TimeLevelFrequency, function (value, index) {
                        if (parseInt(response[i].TimeLevelID) == value.TimeLevel_id)
                            chartTimeLevelDropdown = chartTimeLevelDropdown + "<option selected value='" + value.TimeLevel_id + "'>" + value.Frequency + "</option>";
                        else
                            chartTimeLevelDropdown = chartTimeLevelDropdown + "<option value='" + value.TimeLevel_id + "'>" + value.Frequency + "</option>";
                    });

                    //Location level
                    angular.forEach(response[i].LocationLevel, function (value, index) {
                        chartLocationLevelDropdown = chartLocationLevelDropdown + "<option value='" + value + "'>" + value + "</option>";
                    });
                   
                    //Units
                    angular.forEach(response[i].Units, function (value, index) {
                        if (parseInt(response[i].UnitID) == value.UnitId)
                            chartUnitsDropdown = chartUnitsDropdown + "<option selected value='" + value.UnitId + "'>" + value.Unit + "</option>";
                        else
                            chartUnitsDropdown = chartUnitsDropdown + "<option value='" + value.UnitId + "'>" + value.Unit + "</option>";
                    });
                    
                    //Sources
                    angular.forEach(response[i].Sources, function (value, index) {
                        if (parseInt(response[i].SourceID) == value.SourceId)
                            chartSourcesDropdown = chartSourcesDropdown + "<option selected value='" + value.SourceId + "'>" + value.Source + "</option>";
                        else
                            chartSourcesDropdown = chartSourcesDropdown + "<option value='" + value.SourceId + "'>" + value.Source + "</option>";
                    });

                    var attrIds123 = response[i].Attribute1_ID + '-' + response[i].Attribute2_ID + '-' + response[i].Attribute3_ID;
                    var id = "chartdiv" + (i + 1);
                    var unit = response[i].UnitID;
                    var label = response[i].ChartName;
                    var chart_type_id = response[i].ChartTypeID;
                    var chartType = "column";
                    if (i == 0) {
                        $scope.firstChart = label;
                        $scope.firstChartAttr3 = response[i].Attribute3;
                        $scope.firstID = response[i].Attribute_ID;
                        var hdValue = { commodityId: commodityID, locationId: locationID, unit: unit, chatTypeId: chart_type_id, attrId: response[i].Attribute_ID, timelevelId: parseInt(response[i].TimeLevelID), sourceId: parseInt(response[i].SourceID), MaxYear: response[i].MaxYear, StartYear: response[i].MinYear, EndYear: response[i].MaxYear, State: response[i].State.split(' ').join("-"), MinMaxYear: minMaxyear, AttrIds123: attrIds123, StartDate: response[i].StartDate, EndDate: response[i].EndDate };
                        $scope.FirstHdValue = hdValue;
                    }
                    else {
                        $scope.secondChart = label;
                        $scope.secondID = response[i].Attribute_ID;
                        $scope.secondChartAttr3 = response[i].Attribute3;
                        var hdValue = { commodityId: commodityID, locationId: locationID, unit: unit, chatTypeId: chart_type_id, attrId: response[i].Attribute_ID, timelevelId: parseInt(response[i].TimeLevelID), sourceId: parseInt(response[i].SourceID), MaxYear: response[i].MaxYear, StartYear: response[i].MinYear, EndYear: response[i].MaxYear, State: response[i].State.split(' ').join("-"), MinMaxYear: minMaxyear, AttrIds123: attrIds123, StartDate: response[i].StartDate, EndDate: response[i].EndDate };
                        $scope.SecondHdValue = hdValue;
                    }

                    if (chart_type_id == 2) {
                        chartType = 'smoothedLine'
                    }

                    $("#dp-time-chartdiv" + (i + 1)).html(chartTimeLevelDropdown);
                    $("#level-chartdiv" + (i + 1)).html(chartLocationLevelDropdown);
                    $("#units-dp-chartdiv" + (i + 1)).html(chartUnitsDropdown);
                    $("#sources-dp-chartdiv" + (i + 1)).html(chartSourcesDropdown);


                    if (chart_type_id == 1) {
                        $("#chart-type-chartdiv" + (i + 1)).val("column");
                    }
                    else if (chart_type_id == 2) {
                        $("#chart-type-chartdiv" + (i + 1)).val("line");
                    }
                    else {
                        $("#chart-type-chartdiv" + (i + 1)).val("stack");
                    }


                    /***************************START Slider DateTime**************************/
                   
                    minYear = minMaxyear.split('-')[0];
                    maxYear = minMaxyear.split('-')[1];
                    $("#slider-" + id).dateRangeSlider({
                        defaultValues: {
                            min: new Date(response[i].StartDate),
                            max: new Date(response[i].EndDate)
                        },
                        bounds: {
                            min: new Date(minYear, 0, 1),
                            max: new Date(maxYear - 1, 12, 31)
                        },
                        range: {
                            min: { months: 11 },
                            //max: { years: 10 }
                        }                      
                    });
                    if (parseInt(response[i].TimeLevelID) == 1) {
                        $("#slider-" + id).dateRangeSlider({
                            step: { years: 1 },
                            range: {
                                min: { months: 11 },
                                //max: { years: 10 }
                            }
                        });
                    }
                    else if (parseInt(response[i].TimeLevelID) == 2 || parseInt(response[i].TimeLevelID) == 3) {
                        $("#slider-" + id).dateRangeSlider({
                            step: { months: 1 },
                            range: {
                                min: { months: 1 },
                                //max: { years: 10 }
                            }
                        });
                    }

                    else if (parseInt(response[i].TimeLevelID) == 5) {
                        $("#slider-" + id).dateRangeSlider({
                            step: { weeks: 1 }, range: {
                                min: { weeks: 1 },
                                //max: { years: 10 }
                            }
                        });
                    }
                    /***************************END Slider DateTime**************************/
                    console.log("TOPCHART",response[i].DetailIDList);
                    BindChart(response[i].ChartData, unit, id, response[i].DetailIDList, response[i].DetailIDList);

                }
            }

        });
    }

    //A side reveal plugin to show large number of records for particular chart
    $scope.ShowAllData = function (chartID) {

        $('#sliderChartDiv').html("");
        $('#slider').slideReveal("show");
        //Ajax to get data by chartID
        dashboardService.GetChartByChartID(chartID, 2000, 2016).then(function (response) {
            BindSliderChart(response[0].SingleChartData, response[0].Unit);
        });
    }
    var attributesChartIDs = [];
    //Dynamic binding of ribbon according to commodity ID and location ID
    $scope.GetAttributesForRibbonAndSubMenu = function () {
        attributesChartIDs = [];
        $('#verscroll1').html("<center><h4 style='color:#000'>Loading . . .</h4></center>");
        //Ajax to fetch list of Attributes
        dashboardService.GetAttributesByLocation(locationID, commodityID).then(function (response) {
            console.log("Accordian", response);
            $("#childChartDiv").html("");

            if (response.Attribute1.length != 0) {
                $scope.Attributes1 = response.Attribute1;
                $scope.Attributes2 = response.Attribute2;
                $scope.Attributes3 = response.Attribute3;
                
                $scope.firstRibbonAttribute = response.Attribute1[0].Value;
                $scope.ribbonAttribute2 = response.Attribute2[0].Value;
                var content = "";

                for (var i = 0; i < response.Attribute1.length; i++) {
                    if (i == 0)
                        content += '<div class="navbox active"> <a id="' + response.Attribute1[i].ID + '"> <span class="h2">' + response.Attribute1[i].Value + '</span> </a> </div>';
                    else
                        content += '<div class="navbox"> <a id="' + response.Attribute1[i].ID + '"> <span class="h2">' + response.Attribute1[i].Value + '</span> </a> </div>';
                }
                $('#owl-demo').html(content);
                //BindRibbon();

                content = '<ul class="nav side-menu accord-menu">';

                var innerHtml = ""; var innerHtml3 = "";
                var innerList = []; var innerList3 = [];
                for (var i = 0; i < response.Attribute1.length; i++) {
                    // var attr2ParentID = response.Attribute2[i].ParentID

                    var parentID = response.Attribute1[i].ID;
                    var attrIds123 = "";
                    innerList = _.filter(response.Attribute2, function (obj) { return obj.ParentID == parentID });
                    innerHtml = "";
                    // Attribute 2
                    if (innerList.length > 0) {
                        for (var j = 0; j < innerList.length; j++) {
                            innerHtml3 = "";
                            //if (j == 0) {
                            //    innerHtml = '<li class="active"><a href="#c' + parentID + "-" + innerList[j].ID + '" data-pid="' + attr2ParentID + '" class="active">' + innerList[j].Value + '</a></li>';
                            //}
                            //else {
                            //    innerHtml += '<li><a href="#c' + parentID + "-" + innerList[j].ID + '" data-pid="' + attr2ParentID + '">' + innerList[j].Value + '</a></li>';
                            //}

                            // Attribute 3
                            innerList3 = _.filter(response.Attribute3, function (obj) { return obj.ParentID == innerList[j].ID });
                            //  console.log("innerList3", innerList3)
                            if (innerList3.length > 0) {
                                for (var k = 0; k < innerList3.length; k++) {

                                    attrIds123 = parentID + "-" + innerList3[k].ParentID + "-" + innerList3[k].ID;
                                    attributesChartIDs.push({attr3Name: innerList3[k].Value, attrIds123: attrIds123,attr3Id:innerList3[k].ID, attributeId: innerList3[k].AttributeID });
                                    if (k == 0) {
                                        innerHtml3 = '<li><a lineid="'+ innerList3[k].AttributeID+'" style="background-image:none" href="#c' + attrIds123 + '">' + innerList3[k].Value + '</a></li>';
                                    }
                                    else {
                                        innerHtml3 += '<li><a lineid="' + innerList3[k].AttributeID + '" style="background-image:none" href="#c' + attrIds123 + '">' + innerList3[k].Value + '</a></li>';
                                    }
                                }
                                // Attribute 3 ul element bind in Attribute 2 li
                                innerHtml += '<li> <a>' + innerList[j].Value + '</a><ul class="nav child_menu inner-sub-menu" style="display:none">' + innerHtml3 + '</ul></li>';
                                // /Attribute 2
                            }
                            // /Attribute3
                        }
                        // Attribute 2 ul element bind in Attribute 1 li
                        content += '<li> <a>' + response.Attribute1[i].Value + '</a><ul class="nav child_menu accord-sub-menu" style="display:none">' + innerHtml + '</ul></li>';
                    }
                    else {
                        content += '<li><a>' + response.Attribute1[i].Value + '</a></li>';
                    }
                }
                content += '</ul>';
                $('#verscroll1').html(content);
                BindAccordian();

                //-------------------------------------------------------------START Divs INITIALIZE for CHARTS-----------------------------------------------//

                var divChartsHtml = "";
             
                var hdValues = { commodityId: commodityID, locationId: locationID};
                for (var i = 0; i < attributesChartIDs.length; i++)
                {                    
                    divId = attributesChartIDs[i].attrIds123;
                    attrId = attributesChartIDs[i].attributeId;
                    attr3Id = attributesChartIDs[i].attr3Id;
                    title = attributesChartIDs[i].attr3Name;
                    hdValues.attrId = attrId;
                    divChartsHtml += '<div class="x_panel" id="c' + divId + '" data-chartid="'+divId+'" lineid="' + attrId + '" style="min-height:400px;" data-isload="false">' +
                                         '<input type="hidden" id="hd-' + divId + '" value=' + JSON.stringify(hdValues) + ' />' + 
                                        '<div class="x_title">' +
                                            '<h3 class="childH2">' + title + '</h3>'+
                                        '</div>'+
                                        '<div class="x_content">' +
                                            
                                         '</div>'+
                                     '</div>'; 
                  
              
                }
                $("#childChartDiv").html(divChartsHtml);
                //$("#childChartDiv").html("");
                

                //-------------------------------------------------------------END Divs INITIALIZE for CHARTS---------------------------------------------------------------------//

            }


        });
    }

    $scope.ChartData = [];
    var distIDs = [];
    var chartCounts = 1;
    //Lazyload function to get all other charts at bottom
    $scope.GetChildrenCharts = function (offset) {

        ////console.log(3)
        var chartTypeDropdown = "<option>Chart Type</option><option value='column'>Column</option><option value='area'>Line Area</option><option value='line'>Line</option><option selected value='stack'>Stacked</option>";
        var xAasisDropdown = "<option value='0'>X Asis</option><option value='1'>Category</option><option value='2'>Time</option>";
        chartTimeLevelDropdown = "<option value='0'>Time Level</option>";
        chartUnitsDropdown = "";
        chartSourcesDropdown = "";

        //Angular Ajax to Common API controller
        dashboardService.GetTopChartsData(locationID, commodityID, offset, size).then(function (response) {
            ////console.log("GetTopChartsData", response);
            //if (response.length != 0) {
            //    $scope.ChartData = response;
            //    //console.log($scope.ChartData)
            //}

            console.log(response)
            if (response.length != 0) {
                for (var i = 0; i < response.length; i++) {
                    if (response[i].ChartData.length > 0) {

                        //if ($.inArray(response[i].Attribute_ID, distIDs) === -1) {
                        //    distIDs.push(response[i].Attribute_ID);
                        //}
                        //else {
                        //    continue;
                        //}

                        minMaxyear = response[i].MinMaxYear;
                        chartTimeLevelDropdown = "";
                        ////console.log("parseInt(response[i].TimeLevelID)", parseInt(response[i].TimeLevelID));
                        chartTimeLevelDropdown = "<option value='0'>Time Level</option>"; chartLocationLevelDropdown = "<option value='0'>TIME</option>";
                        chartUnitsDropdown = "<option value='0'>Units</option>";
                        chartSourcesDropdown = "<option value='0'>Sources</option>";
                        //Time level
                        angular.forEach(response[i].TimeLevelFrequency, function (value, index) {
                            if (parseInt(response[i].TimeLevelID) == value.TimeLevel_id)
                                chartTimeLevelDropdown = chartTimeLevelDropdown + "<option selected value='" + value.TimeLevel_id + "'>" + value.Frequency + "</option>";
                            else
                                chartTimeLevelDropdown = chartTimeLevelDropdown + "<option value='" + value.TimeLevel_id + "'>" + value.Frequency + "</option>";
                        });

                        //Location level
                        angular.forEach(response[i].LocationLevel, function (value, index) {
                            //if (response[i].DefaultLocation == value)
                            //    chartLocationLevelDropdown = chartLocationLevelDropdown + "<option selected value='" + value + "'>" + value + "</option>";
                            //else
                            chartLocationLevelDropdown = chartLocationLevelDropdown + "<option value='" + value + "'>" + value + "</option>";
                        });

                        //Units
                        angular.forEach(response[i].Units, function (value, index) {
                            if (parseInt(response[i].UnitID) == value.UnitId)
                                chartUnitsDropdown = chartUnitsDropdown + "<option selected value='" + value.UnitId + "'>" + value.Unit + "</option>";
                            else
                                chartUnitsDropdown = chartUnitsDropdown + "<option value='" + value.UnitId + "'>" + value.Unit + "</option>";
                        });

                        //Sources
                        angular.forEach(response[i].Sources, function (value, index) {
                            if (parseInt(response[i].SourceID) == value.SourceId)
                                chartSourcesDropdown = chartSourcesDropdown + "<option selected value='" + value.SourceId + "'>" + value.Source + "</option>";
                            else
                                chartSourcesDropdown = chartSourcesDropdown + "<option value='" + value.SourceId + "'>" + value.Source + "</option>";
                        });
                        // <select lineid="' + id + '" class="x-asis-dp form-control">' + xAasisDropdown + '"</select>
                        var id = response[i].Attribute_ID;
                        var divId = id + '-' + chartCounts;
                        var unit = response[i].UnitID;
                        var attr2 = response[i].Attribute2;
                        var attr3 = response[i].Attribute3;
                        var chart_type_id = response[i].ChartTypeID;
                        var attrIds123 = response[i].Attribute1_ID + '-' + response[i].Attribute2_ID + '-' + response[i].Attribute3_ID;
                        var chartType = "column";
                        //console.log(response[i]);
                        var hdValue = { commodityId: commodityID, locationId: locationID, unit: unit, chatTypeId: chart_type_id, attrId: id, timelevelId: parseInt(response[i].TimeLevelID), sourceId: parseInt(response[i].SourceID), MaxYear: response[i].MaxYear, StartYear: response[i].MinYear, EndYear: response[i].MaxYear, State: response[i].State.split(' ').join("-"), MinMaxYear: minMaxyear, AttrIds123: attrIds123, StartDate: response[i].StartDate,EndDate:response[i].EndDate };
                        var navAttrId = response[i].Attribute_ID;// + '-' + response[i].Tier3_Attr_Id;// +'-'+ i;
                        // //console.log(response[i].ChartData[0].Tier2_Attr_Id + '' + response[i].ChartData[0].Tier3_Attr_Id);
                        var html = '<div class="x_panel"  id="c' + attrIds123 + '">                                                                                                                                                                        '
                        html += '        <div class="x_title">                                                                                                                                                                     '
                        html += '            <h3 class="childH2">' + attr3 + '</h3>                                                                                                                                                                       '
                        html += '            <div class="clearfix"></div>                                                                                                                                                          '
                        html += '        </div>                                                                                                                                                                                    '
                        html += '        <div class="x_content">                                                                                                                                                                   '
                        html += '        <div class="row"><div class="col-lg-2"><select  lineid="' + divId + '" class="ddd chart-type-dp form-control">' + chartTypeDropdown + '</select></div><div class="col-lg-2"> <select lineid="' + divId + '" class="timelevel-dp form-control">' + chartTimeLevelDropdown + '</select></div><div class="col-lg-2"> <select id="level-' + divId + '" lineid="' + divId + '" class="locationlevel-dp form-control">' + chartLocationLevelDropdown + '</select></div><div class="col-lg-2"> <select lineid="' + divId + '" class="units-dp form-control"> ' + chartUnitsDropdown + '</select></div><div class="col-lg-2"> <select lineid="' + divId + '" class="sources-dp form-control"> ' + chartSourcesDropdown + '</select></div></div>'
                        html += '            <div class="graph_bar"><input type="hidden" id="hd-' + divId + '" value=' + JSON.stringify(hdValue) + ' />'
                        html += '                <div class="customGraphClass" id="' + divId + '"></div>                                                                                                                                                        '
                        html += '            </div>'
                        html += '        <div style="margin-top:0px;margin-left:30px;margin-right:30px" class="row slider-date" lineid="' + divId + '" id="slider-' + divId + '"></div>'
                        html += '        </div>'
                        html += '    </div>'

                        var childChartDiv = angular.element(document.querySelector('#childChartDiv'));
                        childChartDiv.append(html);

                        /***************************START Slider DateTime**************************/

                        minYear = minMaxyear.split('-')[0];
                        maxYear = minMaxyear.split('-')[1];
                        $("#slider-" + divId).dateRangeSlider({
                            defaultValues: {
                                min: new Date(response[i].StartDate),
                                max: new Date(response[i].EndDate)
                            },
                            bounds: {
                                min: new Date(minYear, 0, 1),
                                max: new Date(maxYear - 1, 12, 31)
                            },
                            range: {
                                min: { months: 11 },
                                //max: { years: 10 }
                            }
                            

                            //   ,
                            //formatter: function (val) {
                            //    var days = val.getDate(),
                            //      month = val.getMonth() + 1,
                            //      year = val.getFullYear();
                            //    return days + "/" + month + "/" + year;
                            //}
                        });
                        if (parseInt(response[i].TimeLevelID) == 1) {
                            $("#slider-" + divId).dateRangeSlider({
                                step: { years: 1 },
                                range: {
                                    min: { months: 11 },
                                    //max: { years: 10 }
                                }
                            });
                        }
                        else if (parseInt(response[i].TimeLevelID) == 2 || parseInt(response[i].TimeLevelID) == 3) {
                            $("#slider-" + divId).dateRangeSlider({
                                step: { months: 1 },
                                range: {
                                min: { months: 1 },
                                    //max: { years: 10 }
                                }});
                        }
                        
                        else if (parseInt(response[i].TimeLevelID) == 5) {
                                $("#slider-" + divId).dateRangeSlider({ step: { weeks: 1 } ,range: {
                                    min: { weeks: 1 },
                                    //max: { years: 10 }
                                    } });
                        }
                        /***************************END Slider DateTime**************************/

                        //scope.$apply();
                        if (chart_type_id == 2) {
                            chartType = 'smoothedLine'
                        }
                        ////console.log(response[i].DetailIDList);
                        BindChart(response[i].ChartData, unit, divId, response[i].DetailIDList, response[i].DetailIDList);
                        chartCounts = chartCounts + 1;
                        //$timeout(callAtInterval, 5000 * (2 + i));
                    }
                }


            }
            else {

                //console.log("No More Charts to display");
                loadMoreData = false;
            }

        });
    }
    $scope.doSomething = function (v) {
        ////console.log(v);
    }
    //Lazy load init function
    $scope.loadMore = function () {

        //load only if we have not reached the last record
        if (loadMoreData) {

            //console.log("offset", offset)
           // $scope.GetChildrenCharts(offset);
            offset = offset + size;
        }
    };

    //Init call for Charts
   // $scope.GetDataForTopTwoCharts();
   // $scope.GetAttributesForRibbonAndSubMenu();

    $scope.$watch('SelectedCommodity', function () {
        //console.log($scope.SelectedCommodity);
        if ($scope.SelectedCommodity != '') {
            dashboardService.GetLocationAndCommodityID($scope.SelectedCommodity).then(function (response) {
                if (response != null) {
                    $scope.tempCommodityID = response.Commodity_Id;
                    $scope.tempLocationID = response.location_Id;
                    $scope.loadAgain();
                }
                else {
                    $scope.tempCommodityID = 0;
                    $scope.tempLocationID = 0;
                }
            });
        }
    });
}]);
function callAtInterval() {
    //console.log("Interval occurred");
}
app.factory('dashboardService', ['$http', '$q', function ($http, $q) {

    var self = this;
    // var baseURL = "http://localhost:50138/api/"; //ngAuthSettings.apiServiceBaseUri;
    // self.AppBaseUrl = baseURL;
    /******************************************************************************************************************************/

    self.GetSectors = function () {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSectors',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSuperRegion = function (sectorName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSuperRegion',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { 'sectorName': sectorName }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCommoditiesBySubSectorID = function (subSectorID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommoditiesBySubSectorID/' + subSectorID,
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSubCommodity = function (subSectorID, TierID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSubCommoditiesBySubSectorID',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "SubSectorID": subSectorID, "Tier1_ID": TierID }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSubSectors = function (sectorName, superRegion) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSubSectors',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "SectorName": sectorName, "RegionName": superRegion }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSectorDetails = function (sectorName) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetSectorDetails',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "SectorName": sectorName }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCountries = function (subSectorID, tier1ID, tier2ID, tier3ID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCountries',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "subSectorID": subSectorID, "tier1_ID": tier1ID, "tier2_ID": tier2ID, "tier3_ID": tier3ID },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCountries_v1 = function (subSectorID, tier1ID, tier2ID, tier3ID, locationLevel) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCountries_v1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "subSectorID": subSectorID, "tier1_ID": tier1ID, "tier2_ID": tier2ID, "tier3_ID": tier3ID, "locationLevel": locationLevel },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetStates = function (CountryID, subSectorID, Tier1ID, Tier2ID, Tier3ID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetStates',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "CountryID": CountryID, "SubSectorID": subSectorID, "Tier1_ID": Tier1ID, "Tier2_ID": Tier2ID, "Tier3_ID": Tier3ID },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCounties = function (CountryID, StateID, subSectorID, Tier1ID, Tier2ID, Tier3ID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCounties',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "StateID": StateID, "CountryID": CountryID, "SubSectorID": subSectorID, "Tier1_ID": Tier1ID, "Tier2_ID": Tier2ID, "Tier3_ID": Tier3ID },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCommodities = function (searchTerm, sectorName, superRegion) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommoditiesForSearch',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "searchTerm": searchTerm,
                "sectorName": sectorName,
                "superRegion": superRegion
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAttributes1 = function (data) {
        var defer = $q.defer();
        $http.post('/api/Common/GetAttributes1', data).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocation = function (searchTerm, sectorName, superRegion) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocation',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "searchTerm": searchTerm,
                "sectorName": sectorName,
                "superRegion": superRegion
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocation_v1 = function (searchTerm, sectorName, superRegion, subsector_id, tier1_id, tier2_id, tier3_id) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocation_v1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "searchTerm": searchTerm,
                "sectorName": sectorName,
                "superRegion": superRegion,
                "subsector_id": subsector_id,
                "tier1_id": tier1_id,
                "tier2_id": tier2_id,
                "tier3_id": tier3_id
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocationLevel = function () {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocationLevel',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocationLevel_v1 = function (sectorName, superRegion, subsector_id, tier1_id, tier2_id, tier3_id) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocationLevel_v1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "sectorName": sectorName,
                "superRegion": superRegion,
                "subsector_id": subsector_id,
                "tier1_id": tier1_id,
                "tier2_id": tier2_id,
                "tier3_id": tier3_id
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetCommoditiesByTier = function (tier, commodity) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetCommoditiesByTier',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "tier": tier,
                "commodity": commodity,
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetMaps = function (CommodityID) {
        var defer = $q.defer();
        $http({
            url: '/api/Map/GetMaps',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "CommodityID": CommodityID },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetChartByChartID = function (chartID, startYear, endYear) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetChartByChartID',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "chartID": chartID,
                "startYear": startYear,
                "endYear": endYear,
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetTopChartsData = function (LocationID, CommodityID, offSet, size) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetTopChartsForDashboard',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "commodityId": CommodityID,
                "locationId": LocationID,
                "offSet": offSet,
                "size": size
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAttributesByLocation = function (LocationID, CommodityID) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetAttributesByLocation',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "commodityId": CommodityID,
                "locationId": LocationID
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetLocationAndCommodityID = function (commodity) {
        var defer = $q.defer();
        $http({
            url: '/api/Common/GetLocationAndCommodityID',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: {
                "commodity": commodity
            }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    /*******************************************************************************************************************************/

    return self;
}]);