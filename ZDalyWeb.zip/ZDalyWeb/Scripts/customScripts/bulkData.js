﻿(function () {

    angular.module('underscore', []).factory('_', ['$window', function ($window) {
        return $window._; // assumes underscore has already been loaded on the page
    }]);

    var app = angular.module('bulkData', ['ngAnimate', 'ngRoute', 'ngSanitize', 'utilities', 'underscore', 'ui.autocomplete', 'ui.router']);
    app.constant("apiUrl", "http://54.71.24.240:9090/");
    app.config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/');

        $stateProvider.state('search', {
            url: '/search?q',
            templateUrl: '/Angular/partials/BulkData/search.html',
            controller: 'searchCtrl'
        }).state('/', {
            url: '/',
            templateUrl: '/Angular/partials/BulkData/index.html',
            controller: "bulkMainCtrl"
        }).state('searchresults', {
            url: '/searchresults?q',
            templateUrl: '/Angular/partials/BulkData/searchresults.html',
            controller: function ($scope, $rootScope, ajaxRFac, $state, $stateParams) {
                console.log("searchResults init");
                $rootScope.$watch("searchResults", function (newVal, oldVal) {
                    if (newVal) {
                        $scope.pageSearchResults = newVal;
                        console.log("rootscope", $scope.searchResults);
                    }


                });
                $rootScope.mainLoading = true;
                ////////////////
                ajaxRFac.GetSearchResultsFromAPI($stateParams.q).then(function (res) {

                    console.log(res);

                    var results = [];
                    angular.forEach(res.responseEntity.searchResponse, function (item) {

                        var suggestionObj = {
                            sector: item.sector,
                            subSector: item.subSector,
                            superRegion: item.superRegion,
                            search: $stateParams.q,
                            suggestionString: item.suggestionString,
                            stratumName: item.stratumName

                        }
                        results.push(suggestionObj);
                    });

                    $scope.pageSearchResults = results;
                    console.log("results are ", $scope.pageSearchResults);
                    $rootScope.mainLoading = false;
                });


                $scope.getFilterBySearchResult = function (searchItem) {
                    $rootScope.searchObj = searchItem;
                    $state.go("search", { q: searchItem.suggestionString.toLowerCase() })

                }



            }
        }).state('saved', {
            url: '/saved/:s',
            templateUrl: '/Angular/partials/BulkData/search.html',
            controller: 'searchCtrl'
        }).state('bulkList', {
            url: '/bulkSavedList',
            templateUrl: '/Angular/partials/BulkData/bulk-saved-list.html',
            controller: 'bulkSavedListCtrl'
        })







    });

    app.run(function ($rootScope, $timeout) {
        //Look for successful state change.
        //For your ref. on other events.
        //https://github.com/angular-ui/ui-router/wiki#state-change-events
        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams, options) {
            console.log("Url redirected ", toState.url);
            console.log("toState.url ", toState.url.indexOf("/searchresults"));
            if (toState.url.indexOf("/searchresults") > -1) {
                $(".ui-autocomplete").hide();
                $rootScope.autocompleteShow = false;

            }
            else if (toState.url.indexOf("/search") > -1) {

                $rootScope.autocompleteShow = false;

            }
            else {
                //  $(".ui-autocomplete").show();
                $rootScope.autocompleteShow = true;
            }




        });



        $rootScope.$on('$stateChangeStart', function (e, toState, toParams, fromState, fromParams) {

        });
    })


    
    app.controller('bulkSavedListCtrl', function ($scope, $compile, paginationservice, $location, $rootScope, ajaxRFac, $state, $stateParams, ajaxApiFac) {



    });


    app.controller('searchCtrl', function ($scope, $compile, paginationservice, $location, $rootScope, ajaxRFac, $state, $stateParams, ajaxApiFac) {
        $rootScope.mainLoading = true;

        /////Initialization
        var searchObj = $rootScope.searchObj;
        console.log("searchObj", searchObj);
        $scope.displaySearch = searchObj;
        $scope.searchFilters = [];
        //all filters last levels
        $scope.filterResults = [];
        $scope.downloadPath = "/new/DownloadCsv/";

        ///records selected
        $scope.totalDataCount = 0;
        //$scope.selectData = null;
        $scope.selectedFilter = null;
        $scope.TOPSELECTIONS = [];
        $scope.startDate = null;
        $scope.endDate = null;
        //api request Data
        $scope.searchObject = null;
        $scope.filters = null;
        $scope.searchTime = null;

        //about nresults initial 
        $scope.filtersLastAttrs = [];

        $scope.downloadLink = null;
        //search filters
        $scope.searchFilters = [];
        //tracking editing or not
        $scope.editId = 0;

        console.log("stateparams", $stateParams);
        if ($stateParams.s) {
            $scope.editId = $stateParams.s;
            $rootScope.mainLoading = false;
            alert($stateParams.s);
            ajaxApiFac.getSavedDataById($stateParams.s).then(function (data) {
                console.log("saved Data", data);

                searchObj = data.searchObj;

                $scope.displaySearch = data.displaySearch;
                $scope.searchFilters = data.searchFilters;
                //all filters last levels
                $scope.filterResults = data.filterResults;
                $scope.downloadPath = "/new/DownloadCsv/";

                ///records selected
                $scope.totalDataCount = data.totalDataCount;
                //$scope.selectData = null;
                $scope.selectedFilter = data.selectedFilter;
                $scope.TOPSELECTIONS = data.TOPSELECTIONS;
                $scope.startDate = data.startDate;
                $scope.endDate = data.endDate;
                //api request Data
                $scope.searchObject = data.searchObject;
                $scope.filters = data.filters;
                $scope.searchTime = data.searchTime;

                //about nresults initial 
                $scope.filtersLastAttrs = data.filtersLastAttrs;

                $scope.downloadLink = data.downloadLink;
                //search filters
                $scope.searchFilters = data.searchFilters;


                var originalObj = JSON.parse(JSON.stringify($scope.searchObject));

            });
        }
        else {
            //////
            if (!searchObj) {
                $state.go("searchresults", { q: $stateParams.q.toLowerCase() })
            }

            $rootScope.$watch("filteredSearch", function (nVal, oVal) {
                if (nVal && nVal != oVal) {
                    $state.go("searchresults", { q: nVal.toLowerCase() });
                }
            });
            //////









            ////////

            var startDate = +new Date();

            var reqObj = {
                searchText: searchObj.suggestionString,
                filters: {
                    Sector: [searchObj.sector],
                    "Sub-Sector": [searchObj.subSector]

                },
                location: true,
                reqAttList:""
            }

            //if (searchObj.superRegion) {
            //    reqObj["locations"] = {
            //        Country: [searchObj.superRegion + ":" + searchObj.superRegion]

            //    }
            //}
            //else {
            //    reqObj["locations"] = {
            //        Country: ["null:" + searchObj.superRegion]

            //    }
            //}
            //   reqObj.filters[searchObj.stratumName] = [searchObj.suggestionString];

            console.log("reqObj", JSON.stringify(reqObj));


            $scope.searchObject = reqObj;
            var originalObj = JSON.parse(JSON.stringify(reqObj));
            ajaxApiFac.getFilters(reqObj).success(function (data) {
                $rootScope.mainLoading = false;
                var endDate = +new Date();
                var diff = (endDate - startDate) / 1000;
                $scope.searchTime = diff;
                console.log("data ", data);

                console.log("stratum LIst ", data.responseEntity.stratumList);

                $scope.originalStatumList = data.responseEntity.stratumList;
                $scope.originalStatum = data.responseEntity.stratum;
                ///  Locations

                console.log("State is ", data.responseEntity.locations.State);
                var locationLevels = [
                    {
                        name: "Country",
                        data: [{
                            "locationParent": null,
                            "locations": [searchObj.superRegion]

                        }]


                    },
                    {
                        name: "State",
                        data: [],


                    }, {
                        name: "County",
                        data: []

                    }];
                $scope.location = {
                    levels: locationLevels

                }


                //var state= data.responseEntity.locations.State.filter(function (state) {
                //    state.locationParent

                // });



                /////////
                var filterList = [];

                var mainItems = data.responseEntity.stratumList.filter(function (item) {
                    return item.level <= 100;
                });

                console.log("Main Items ", mainItems);

                mainItems.forEach(function (item) {
                    console.log("item is ", item);

                    if (item.parent == "NULL" || item.parent == "SubSector") {

                        if (item.stratumName != "Sector") {

                            var list = $scope.checkForFilter(data.responseEntity.stratum, item.stratumName, data.responseEntity.stratumList);
                            console.log("list ", list);
                            if (list) {
                                filterList.push(list);
                            }
                        }

                    }




                });
                $scope.TOPSELECTIONS = $scope.TOPSELECTIONS.filter(function (selection) {
                    return selection.stratum.toLowerCase() != "sector" && selection.stratum.toLowerCase() != "subsector"

                });
                console.log("$scope.TOPSELECTIONS", $scope.TOPSELECTIONS);
                $scope.TOPSELECTIONS.forEach(function (selection) {
                    console.log("selection ", selection);
                    $scope.searchObject.filters[selection.stratum] = [selection.value];
                   
                });
                console.warn("Search Obj  ", $scope.searchObject);
                console.log("Top Selections ", $scope.TOPSELECTIONS);


                console.log("filter List ", filterList);

                filterList.forEach(function (item) {

                    var breadCum = makebreadCumSingle(item, data.responseEntity.stratumList);
                    console.info("breadCum ", breadCum);
                    var breadCumLevels = breadCum.levels;

                    var filterLastAttr = data.responseEntity.stratum[breadCumLevels[breadCumLevels.length - 1].stratumName];
                    $scope.filtersLastAttrs = $scope.filtersLastAttrs.concat(filterLastAttr);


                    var levels = [];
                    breadCum.levels.forEach(function (bread) {
                        levels.push({
                            name: bread.stratumName,
                            data: [],
                            selected: false
                        });
                    });


                    item.selected = false;
                    item.popup = {
                        levels: levels
                    }

                });

                $scope.filters = filterList;
                console.log("Filters are ", $scope.filters);

            });

            ///filterbox

        }

        $scope.closeLocationFilter = function () {
            //reset Levels

            $scope.location.levels.forEach(function (level) {
                if (level.name.toLowerCase() != "country") {
                    level.data = [];
                    level.selected = false;
                    level.selectedObj = false;

                    delete $scope.searchObject.locations[level.name];
                }
                level.selected = [];
                level.selectedObj = [];
                level.goNext = false;
            });
            $scope.location.selected = false;


        }

        $scope.selectLocationFilter = function () {
            console.log("search result ", $scope.searchObject);
            $scope.location.selected = false;
            $scope.execBulkDataOperation();
            $scope.location.hide = true;
        }
        ////////
        //if (!searchObj) {
        //    $state.go("searchresults", { q: $stateParams.q.toLowerCase() })
        //}

        //$rootScope.$watch("filteredSearch", function (nVal, oVal) {
        //    if (nVal && nVal != oVal) {
        //        $state.go("searchresults", { q: nVal.toLowerCase() });
        //    }
        //});
        ////////









        //////////

        // var startDate = +new Date();

        // var reqObj = {
        //     searchText: searchObj.suggestionString,
        //     filters: {
        //         Sector: [searchObj.sector],
        //         SubSector: [searchObj.subSector],

        //     }
        // }
        // reqObj.filters[searchObj.stratumName] = [searchObj.suggestionString];

        // console.log("reqObj", JSON.stringify(reqObj));


        // $scope.searchObject = reqObj;
        // var originalObj = JSON.parse(JSON.stringify(reqObj));
        // ajaxApiFac.getFilters(reqObj).success(function (data) {
        //     $rootScope.mainLoading = false;
        //     var endDate = +new Date();
        //     var diff = (endDate - startDate) / 1000;
        //     $scope.searchTime = diff;
        //     console.log("data ", data);

        //     console.log("stratum LIst ", data.responseEntity.stratumList);

        //     var filterList = [];

        //     var mainItems = data.responseEntity.stratumList.filter(function (item) {
        //         return item.level < 100;
        //     });

        //     console.log("Main Items ", mainItems);

        //     mainItems.forEach(function (item) {
        //         console.log("item is ", item);

        //         if (item.parent == "NULL" || item.parent == "SubSector") {

        //             if (item.stratumName != "Sector") {

        //                 var list = $scope.checkForFilter(data.responseEntity.stratum, item.stratumName, data.responseEntity.stratumList);
        //                 console.log("list ", list);
        //                 if (list) {
        //                     filterList.push(list);
        //                 }
        //             }

        //         }




        //     });
        //     $scope.TOPSELECTIONS = $scope.TOPSELECTIONS.filter(function (selection) {
        //         return selection.stratum.toLowerCase() != "sector" && selection.stratum.toLowerCase() != "subsector"

        //     });
        //     console.log("Top Selections ", $scope.TOPSELECTIONS);


        //     console.log("filter List ", filterList);

        //     filterList.forEach(function (item) {

        //         var breadCum = makebreadCumSingle(item, data.responseEntity.stratumList);
        //         console.info("breadCum ", breadCum);
        //         var breadCumLevels = breadCum.levels;

        //         var filterLastAttr = data.responseEntity.stratum[breadCumLevels[breadCumLevels.length - 1].stratumName];
        //         $scope.filtersLastAttrs = $scope.filtersLastAttrs.concat(filterLastAttr);


        //         var levels = [];
        //         breadCum.levels.forEach(function (bread) {
        //             levels.push({
        //                 name: bread.stratumName,
        //                 data: [],
        //                 selected: false
        //             });
        //         });


        //         item.selected = false;
        //         item.popup = {
        //             levels: levels
        //         }

        //     });

        //     $scope.filters = filterList;
        //     console.log("Filters are ", $scope.filters);

        // });

        // ///filterbox


        /////Locations\
        $scope.prevLocSelected = [];
        $scope.locationLevels = [];
        $scope.locationSelected = null;
        $scope.activateLocationFilter = function () {
            $scope.location.selected = true;
            var copySearchObj = JSON.parse(JSON.stringify($scope.searchObject));
            delete copySearchObj["locations"];
            ajaxApiFac.getLocData(copySearchObj).success(function (data) {
                $scope.locLoader = false;
                var locations = data.responseEntity.locations;
                if (Object.keys(locations).length == 1) {
                    var key = Object.keys(locations)[0];
                    var locationData = [];
                    locations[key].forEach(function (location) {
                        var locItemArray = [];
                        location.locations.forEach(function (loc) {
                            locItemArray.push({ locationParent: location.locationParent, locationName: loc })
                        });

                        locationData = locationData.concat(locItemArray);
                    });


                    //var locationData = locations[key].map(function (location) {
                    //    return location.locations.join(",");

                    //});
                    console.log("locationData", locationData);
                    $scope.locationLevels.push({
                        headerText: key,
                        data: locationData,
                        selectedItems:[]
                    });
                }
                else {
                    $scope.locationLevels.push({
                        headerText: "SelectLevel",
                        data: Object.keys(locations),
                        selectedItems: []
                    });
                }

                console.log("Location Data ", data);
            });

        }

        $scope.getNextLevel = function (header, selectedItem, level, levelIndex) {
            if (header == "SelectLevel") {
                level.selectedItems = [];
                level.selectedItems.push(selectedItem);
            }
            else{
                if (level.selectedItems.indexOf(selectedItem) > -1) {
                    level.selectedItems.splice(level.selectedItems.indexOf(selectedItem),1);
                
                }
                else {
                    level.selectedItems.push(selectedItem);
                }
            }

           
          
            console.log("levelIndex", levelIndex);
          

            var newSelection = { header: header, selectedItems: level.selectedItems };

            console.log("new Selection", newSelection);


            console.log("$scope.locationLevels.length-1", $scope.locationCounter);
            console.log("levelIndex", levelIndex);
            console.log("$scope.locationCounter", $scope.locationCounter);
            if (levelIndex < $scope.locationLevels.length-1) {
                console.log("level index less");
                var splicedLevels = $scope.locationLevels.splice(levelIndex + 1, $scope.locationLevels.length);

                $scope.prevLocSelected.splice(levelIndex, $scope.prevLocSelected.length);
                $scope.locationCounter = levelIndex;
            }
            if (level.selectedItems.length == 0) {
                return false;
            }

            $scope.prevLocSelected=  $scope.prevLocSelected.filter(function (prevItem) {
                return prevItem.header != level.headerText;
            });
            $scope.prevLocSelected.push(newSelection);


            console.log("$scope.prevLocSelected", $scope.prevLocSelected);
            $scope.currentLevelIndex = levelIndex;

            level.selectedItem = selectedItem;
            var copySearchObj = JSON.parse(JSON.stringify($scope.searchObject));
            delete copySearchObj["locations"];


            var jsonObj = copySearchObj;

            var prevSelectedLocs = $scope.prevLocSelected.filter(function (prevLoc) {
                return (prevLoc.header != "SelectLevel");

            });
            var locationObj = {};

            var locTemp = {};

            prevSelectedLocs.forEach(function (locItem, index) {
                if (index == 0) {
                    //iterating on loc Object LocationParent LocationName
                    locItem.selectedItems.forEach(function (item) {
                        locationObj[locItem.header] = [item.locationParent + ":" + item.locationName];
                        locTemp[locItem.header] = [item.locationParent + ":" + item.locationName];
                    });

                   

                }
                else {
                    locItem.selectedItems.forEach(function (item) {
                        console.log("in loc Object ", item);
                        if (!locationObj[locItem.header]) {
                            if (item.locationName.toLowerCase() != "overall") {
                                locationObj[locItem.header] = [item.locationParent + ":" + item.locationName];
                             
                            }
                            locTemp[locItem.header] = [item.locationParent + ":" + item.locationName];
                        }
                        else {
                            if (item.locationName.toLowerCase() != "overall") {
                                locationObj[locItem.header].push(item.locationParent + ":" + item.locationName);
                               
                            }
                            locTemp[locItem.header].push(item.locationParent + ":" + item.locationName);
                        }
                        if (item.locationName.toLowerCase() == "overall") {
                            var prevUnselected = $scope.locationLevels.filter(function (locLevel) {
                                return (locLevel.headerText == "SelectLevel")

                            });
                            var lastPrevSelected = prevUnselected[prevUnselected.length - 1];
                            lastPrevSelected.data.forEach(function (prevLevelItem) {

                                if (!locationObj[prevLevelItem.locationName]) {
                                    locationObj[prevLevelItem.locationName] = [item.locationParent + ":" + item.locationName];
                                }
                                else {
                                    locationObj[prevLevelItem.locationName].push(item.locationParent + ":" + item.locationName);
                                }
                                
                            });

                            console.log("lastPrevSelected", lastPrevSelected);

                        }
                    });

                    //if (selectedItem.toLowerCase() == "overall") {
                    //    var prevUnselected = $scope.locationLevels.filter(function (locLevel) {
                    //        return (locLevel.headerText == "SelectLevel")

                    //    });
                    //    var lastPrevSelected = prevUnselected[prevUnselected.length - 1];
                    //    lastPrevSelected.data.forEach(function (levelText) {
                    //        locationObj[levelText] = [prevSelectedLocs[index - 1].selectedItem + ":" + locItem.selectedItem];
                    //    });

                    //    console.log("lastPrevSelected", lastPrevSelected);

                    //}

                }
            });
            console.log("locationObj", locationObj);
            $scope.finalLocationObj = locationObj;
            jsonObj["locations"] = locationObj;
            var locationLevel = {};
            Object.keys(locTemp).forEach(function (key, index) {
                locationLevel[key] = index + 1;
            });
            var wildcardSelected = Object.keys(locationObj).filter(function (key) {
                var locTempKeys = Object.keys(locationLevel);
                return (locTempKeys.indexOf(key) == -1)
            });
            console.log("wildcardSelected", wildcardSelected);
            wildcardSelected.forEach(function (key) {
                console.log("wildcardSelected key", key);
                locationLevel[key] = Object.keys(locTemp).length;
                console.log("locationLevel", locationLevel);
            });


            jsonObj["locationLevels"] = locationLevel;
            $scope.reqlocationLevels = locationLevel;
            console.log("jsonObj", jsonObj);

            if (header == "SelectLevel") {
                $scope.locLoader = true;
                ajaxApiFac.getLocData(jsonObj).success(function (data) {
                    var locations = data.responseEntity.locations;



                    var locationData = [];
                    locations[selectedItem.locationName].forEach(function (location) {
                        var locItemArray = [];
                        location.locations.forEach(function (loc) {
                            locItemArray.push({ locationParent: location.locationParent, locationName: loc })
                        });

                        locationData = locationData.concat(locItemArray);
                    });



                    //var locationData = [];
                    //locations[selectedItem.locationName].forEach(function (location) {
                    //    locationData = locationData.concat(location.locations);
                    //});

                    //console.log("locationDataIn loop", locationData);
                    $scope.locationLevels.push({
                        headerText: selectedItem.locationName,
                        data: locationData,
                        selectedItems:[]
                    });
                    $scope.locLoader = false;
                    //if (Object.keys(locations).length == 1) {
                    //    var key = Object.keys(locations)[0];
                    //    var locationData = locations[key].map(function (location) {
                    //        return location.locations.join(",");

                    //    });
                    //    console.log("locationData", locationData);
                    //    $scope.locationLevels.push({
                    //        headerText: key,
                    //        data: locationData
                    //    });
                    //}
                    //else {
                    //    $scope.locationLevels.push({
                    //        headerText: "SelectLevel",
                    //        data: Object.keys(locations)
                    //    });
                    //}

                    //console.log("Location Data ", data);
                    console.log("scroll width");
                    console.log($(".row-horizon")[0].scrollWidth);
                    setTimeout(function () {
                        $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 900);
                    }, 200);


                });
            }

            else {
                $scope.locLoader = true;

                ajaxApiFac.getLocData(jsonObj).success(function (data) {
                    console.log("Data Get is ", data);
                    $scope.locLoader = false;
                    var locations = data.responseEntity.locations;
                    if (Object.keys(locations).length == 1) {
                        var key = Object.keys(locations)[0];
                        if (locations[key].length > 0) {
                            var locationData = locations[key].map(function (location) {
                                return location.locations.join(",");

                            });
                            console.log("locationData", locationData);
                            $scope.locationLevels.push({
                                headerText: key,
                                data: locationData
                            });
                        }

                    }
                    else {
                        console.log("$scope.prevLocSelected", $scope.prevLocSelected);
                        var nonEmpty = Object.keys(locations).filter(function (key) {
                            return locations[key].length > 0;
                        });

                        var showSlections = nonEmpty.filter(function (key) {
                            var found = true;
                            $scope.prevLocSelected.forEach(function (prevSelected) {
                                console.log("prevSelected", prevSelected);
                                console.log("key", key);
                                if (prevSelected.header.toLowerCase() == key.toLowerCase()) {
                                    found = false;
                                }
                            });

                            return found;
                        });
                        console.log("showSlections", showSlections);
                        console.log("key", key);
                        if (showSlections.length == 1) {


                            var locationData = [];
                            locations[showSlections[0]].forEach(function (location) {
                                var locItemArray = [];
                                location.locations.forEach(function (loc) {
                                    locItemArray.push({ locationParent: location.locationParent, locationName: loc })
                                });

                                locationData = locationData.concat(locItemArray);
                            });

                           

                            //var showData = locations[showSlections[0]];
                            console.log("showData", locationData);
                            $scope.locationLevels.push({
                                headerText: showSlections[0],
                                data: locationData,
                                selectedItems:[]
                            });
                        }


                        else if (showSlections.length > 1) {
                            var showSlectionsArray = [];
                            showSlections.forEach(function (selection) {
                                showSlectionsArray.push({ locationParent: null, locationName: selection });
                            });
                            $scope.locationLevels.push({
                                headerText: "SelectLevel",
                                data: showSlectionsArray
                            });
                        }
                        else {
                            //$scope.prevLocSelected.pop(newSelection);
                        }

                    }
                    console.log("scroll width");
                    console.log($(".row-horizon")[0].scrollWidth);
                    setTimeout(function () {
                        $(".row-horizon").animate({ scrollLeft: $(".row-horizon")[0].scrollWidth }, 800);

                    }, 200);

                    console.log("Location Data ", data);
                });
            }

            $scope.locationCounter++;

        }


        $scope.closeNewLocationFilter = function () {
           
            $scope.prevLocSelected = [];
            $scope.locationLevels = [];
            $scope.locationSelected = null;
            $scope.location.selected = false;
            $scope.finalLocationObj = null;
            $scope.reqlocationLevels = null;
        }



        $scope.selectNewLocationFilter = function () {
            if($scope.finalLocationObj)
                $scope.searchObject["locations"] = $scope.finalLocationObj;
            if ($scope.reqlocationLevels)
                $scope.searchObject["locationLevels"] = $scope.reqlocationLevels;
            $scope.location.selected = false;
            console.log(" $scope.searchObject", $scope.searchObject);
            $scope.location.hide = true;
            $scope.execBulkDataOperation();
        }


        ////



        $scope.activateFilter = function (filterItem) {

            filterItem.selected = true;
            $scope.selectedFilter = filterItem;

            var level1 = filterItem.popup.levels[0];
            // $scope.searchObject.filters[level1.name]

            ajaxApiFac.getLevelsData($scope.searchObject, level1.name).then(function (data) {

                filterItem.popup.levels[0].data = data;

            });

        }

        $scope.isFilterSelected = function () {
            if ($scope.selectedFilter)
                return true
            else
                return false;
        }

        $scope.closeAllFilters = function () {
            console.log("original ", originalObj);
            //  $scope.searchObject = originalObj;
            
            // $scope.selectedFilter.popup.levels = [
            //{
            //    name: $scope.selectedFilter.stratumName,
            //    data: [],
            //    selected: false
            //},
            // {
            //     name: $scope.selectedFilter.stratumName,
            //     data: [],
            //     selected: false
            // },
            //  {
            //      name: $scope.selectedFilter.stratumName,
            //      data: [],
            //      selected: false
            //  }

            // ];
            console.log("close all filters ");
            $scope.selectedFilter.popup.levels.forEach(function (level) {

                level.data = [];
                level.selected = false;
                level.goNext = false;
                console.log("level popup ", level);
               
            });

            $scope.selectedFilter.popup.levels.forEach(function (level) {
                delete $scope.searchObject.filters[level.name];
            });


            $scope.selectedFilter.selected = false;
            console.log("selected Filter", $scope.searchObject);
            $scope.selectedFilter = null;
        }



        $scope.selectFilter = function () {
            console.log($scope.selectedFilter);

            // $scope.selectedFilter
            //adding search filter when select not clicked


            $scope.selectedFilter.popup.levels.forEach(function (level, index) {
                console.log("level; is ", level);
                console.log("index is ", index);
                console.log("$scope.searchObject", $scope.searchObject.filters[level.name]);
                var searchFilterAttr = $scope.searchObject.filters[level.name];

                if (level.selected.length > 0 && !searchFilterAttr) {
                    $scope.searchObject.filters[level.name] = level.selected;

                }

            });
            ///////////////

            //console.log("search Obj ", JSON.stringify($scope.searchObject));
            ////////Last Hit To Get last Level Data
            var filterLevels = $scope.selectedFilter.popup.levels;
            //var levelIndex =  (lastLevel);
            //console.log("level Index ", levelIndex);
            //var searchlevelIndex = levelIndex >= filterLevels.length-1 ? levelIndex : (levelIndex + 1);
            //console.info("searchlevelIndex index ", searchlevelIndex);
            //console.log("filter leve  name ", filterLevels[searchlevelIndex].name);
            ajaxApiFac.getFilters($scope.searchObject).success(function (data) {
                console.warn("data ", data);
                var lastLevelData = data.responseEntity.stratum[filterLevels[filterLevels.length - 1].name];
                console.log("las Level Data ", lastLevelData);
                $scope.filterResults = $scope.filterResults.concat(lastLevelData);
                console.warn("filtered Results ", $scope.filterResults);
            });

            ///////////////

            var selectedFilter = angular.copy($scope.selectedFilter);
            console.log("selected Index ", selectedFilter);
            console.log("chenged search Obj ", $scope.searchObject);
            $scope.searchFilters.push(selectedFilter);
            $scope.selectedFilter.hide = true;
            //close popup
            $scope.selectedFilter.selected = false;
            $scope.selectedFilter = null;
            $scope.execBulkDataOperation();




            ///////


        }

        $scope.deleteFilter = function (filter) {
            var originalFilter = null;
            for (var i = 0; i < $scope.filters.length; i++) {
                if ($scope.filters[i].name == filter.name) {
                    originalFilter = $scope.filters[i];
                    $scope.filters[i].hide = false;
                }
            }
            $scope.searchFilters.splice($scope.searchFilters.indexOf(filter), 1);

            originalFilter.popup.levels.forEach(function (level) {
                level.data = [];
                level.selected = false;
                level.goNext = false;
                delete $scope.searchObject.filters[level.name];
            });

        }

        $scope.downloadData = function () {
            $scope.showDownload = true;
            var stratumName = getStratumName($scope.originalStatumList, $scope.originalStatum);

            var reqCloneObj = angular.copy($scope.searchObject);
            reqCloneObj["stratumName"] = "*";
            console.log("reqCloneObj", JSON.stringify(reqCloneObj));

            ajaxApiFac.getSeriesIds(reqCloneObj).then(function (res) {
                console.log("series Data ", res);
                var savedObject = {
                    searchObj: searchObj,
                    displaySearch: $scope.displaySearch,
                    filterResults: $scope.filterResults,
                    downloadPath: $scope.downloadPath,
                    totalDataCount: $scope.totalDataCount,
                    selectedFilter: $scope.selectedFilter,
                    topSelections: $scope.TOPSELECTIONS,
                    startDate: $scope.startDate,
                    endDate: $scope.endDate,
                    searchObject: $scope.searchObject,
                    filters: $scope.filters,
                    searchTime: $scope.searchTime,
                    filtersLastAttrs: $scope.filtersLastAttrs,
                    downloadLink: "[DOWNLOAD_LINK]",
                    searchFilters: $scope.searchFilters,
                    stratumName: stratumName
                }

                if ($scope.recordLoading) {

                    ajaxApiFac.getBulkDataCount(res.responseEntity.results, $scope.startDate, $scope.endDate).then(function (data) {
                        // $scope.totalDataCount = data;
                        if (data != "terminated") {
                            savedObject.totalDataCount = data;
                            console.log("backup data ", savedObject.totalDataCount);
                        }
                        $scope.recordLoading = false;
                      
                    }, function (err) {
                        $scope.totalDataCount = "";

                    });
                }

                console.log("$scope.totalDataCount", $scope.totalDataCount);
                ajaxApiFac.makeCsv(res.responseEntity.results, $scope.startDate, $scope.endDate, savedObject, $scope.editId).then(function (data) {
                    console.log("fileName", data);
                    $scope.downloadLink = $scope.downloadPath + data;
                    //  $scope.downloadFileName = data;
                    //console.log("url ", $scope.downloadPath + data);
                    //window.open($scope.downloadPath + data, '_blank');
                });

            });
        }

        $scope.previewData = function () {
            // $rootScope.mainLoading = true;
            $scope.bulkPreviewData = null;
            $scope.modalOptions = {
                title: "Preview Data",
                show: true
            }
            var stratumName = getStratumName($scope.originalStatumList, $scope.originalStatum);

            var reqCloneObj = angular.copy($scope.searchObject);
            reqCloneObj["stratumName"] = "*5";
            console.log("reqCloneObj", JSON.stringify(reqCloneObj));
            ajaxApiFac.getSeriesIds(reqCloneObj).then(function (res) {
                console.log("series Data ", res);




                ajaxApiFac.getPreviewData(res.responseEntity.results, $scope.startDate, $scope.endDate).then(function (data) {
                    console.log("preview Data ", data);

                    //Create Table and open pop up
                    //modalTable
                    var tableHtml = '<table   class="table table-striped">';
                    // tableHtml += '<thead><tr><th>Detail</th><th>Value</th><th>ValueDateString</th><th>Year</th></tr></thead>';
                    tableHtml += '<tbody>';

                    for (var i = 0; i < data.length; i++) {
                        tableHtml += '<tr>';
                        var row = data[i].split("[SPLIT]");
                       
                        for (var j = 0; j < row.length; j++) {
                            tableHtml += '<td>' + row[j] + '</td>';
                        }
                      

 
                        tableHtml += '</tr>';
                    }
                    tableHtml += '</tbody>';
                    tableHtml += '</table>';
                    $scope.bulkPreviewData = tableHtml;
                    //$('#modalTable').html(tableHtml);




                });
                //  $rootScope.mainLoading = false;
            });

        }

        //getBulk Data count

        $scope.execBulkDataOperation = function () {
            ///getingData series
          
           // console.warn("execBulkDataOperation");
           //// if ($scope.searchFilters.length > 0 || $scope.searchObject["locations"]) {
           //     $scope.recordLoading = true;
           //     //$scope.originalStatumList = data.responseEntity.stratumList;
           //     //$scope.originalStatum = data.responseEntity.stratum;
           //     console.log("$scope.originalStatumList", $scope.originalStatumList);
           //     console.log(" $scope.originalStatum", $scope.originalStatum);
           //     var stratumName = getStratumName($scope.originalStatumList, $scope.originalStatum);

           //     var reqCloneObj = angular.copy($scope.searchObject);
           //     reqCloneObj["stratumName"] = "*";
           //     console.log("reqCloneObj",JSON.stringify(reqCloneObj));
           //     ajaxApiFac.getSeriesIds(reqCloneObj).then(function (res) {
           //         if (res != "terminated") {
           //             console.log("series Data ", res);
           //             ajaxApiFac.getBulkDataCount(res.responseEntity.results, $scope.startDate, $scope.endDate).then(function (data) {


           //                 $scope.totalDataCount = data;


           //                 $scope.recordLoading = false;
           //             }, function (err) {
           //                 $scope.totalDataCount = "error";

           //             });
           //         }
           //         else {
           //             $scope.recordLoading = false;
           //         }
           //     });
           //// }



        }


        ///get StratumName
        function getStratumName(stratumList, stratumData) {

            //var filteredStratums = stratumList.filter(function (stratum) {
            //    return stratum.level <= 100;
            //});
            
            var filteredStratums = _.filter(stratumList, function (o) { return o.level < 100; });

            var levelsArray = filteredStratums.map(function (stratum) {
                return stratum.level;
            });
            var maxLevelNumber = Math.max.apply(null, levelsArray);

            var stratumsWithHighLevel = filteredStratums.filter(function (stratum) {
                return stratum.level == maxLevelNumber;
            });

            if (stratumsWithHighLevel.length > 1) {

                //checking length of stratums stratumName
                var lengthsArray = stratumsWithHighLevel.map(function (stratum) {
                    return stratumData[stratum.stratumName].length;
                });

                var maxLength = Math.max.apply(null, lengthsArray);

                var stratumWithHighLength = stratumsWithHighLevel.map(function (stratum) {
                    return stratumData[stratum.stratumName].length == maxLength;
                });
                return stratumWithHighLength[0].stratumName || null;
            }
            else {
                return stratumsWithHighLevel[0].stratumName || null;
            }
        }

        //show filtered results or total results

        $scope.searchResultsCount = function () {
            if ($scope.filterResults.length > 0)
                return $scope.filterResults.length;
            else
                if ($scope.filtersLastAttrs) {
                    return $scope.filtersLastAttrs.length || 0;
                }
                else
                    return 0;
        }


        ////Jitender recursion loop

        $scope.checkForFilter = function (data, stratum, listOfStratums) {

            var cStratum = stratum;
            console.log("cStratum", stratum);
            var count = data[cStratum].length;
            if (count == 1) {
                var stratumObj = listOfStratums.filter(function (stratum) {

                    return stratum.stratumName == cStratum;

                });
                console.log("stratum Obj", stratumObj);
                $scope.TOPSELECTIONS.push({ stratum: stratum, value: data[cStratum][0], parent: stratumObj[0].parent });
                //$scope.pushToAry(stratum, data[cStratum][0]);
                cStratum = _.filter(listOfStratums, function (o) { return o.parent == stratum });
                if (cStratum.length) {
                    return $scope.checkForFilter(data, cStratum[0].stratumName, listOfStratums);
                }
                else {
                    return "";
                }

            }
            else {
                return { stratumName: cStratum };
            }
        }


        //making breadcum for single Element
        function makebreadCumSingle(mainObj, list) {



            var newList = JSON.parse(JSON.stringify(list));

            var rootItem = mainObj;
            var breadItem = {
                levels: []
            }

            rootItem.children = [];
            var process = true;
            var processItem = rootItem;
            while (process) {
                breadItem.levels.push(processItem);
                var child = getChild(processItem.stratumName, newList);
                newList.splice(newList.indexOf(child), 1);

                if (child) {
                    processItem.children.push(child);
                    processItem = child;
                    processItem.children = [];
                }
                else {
                    process = false;
                }

            }



            return breadItem;

        }

        function getChild(parentElemName, list) {
            console.log("parentElemName", parentElemName);
            console.log("list", list);
            var child = list.filter(function (item) {
                //console.log("item parent", item.parent);
                //console.log("Elem Name ", parentElemName);
                //console.log("result ", item.parent == parentElemName);
                return item.parent == parentElemName;


            });
            console.log("child ", child);
            if (child.length > 0)
                return child[0];
            else
                return null;
        }

        $scope.clearFilters = function () {
            //clear loction Filter
            $scope.closeNewLocationFilter();
            delete $scope.searchObject["locations"];
            delete $scope.searchObject["locationLevels"];
            $scope.location.hide = false;

            $scope.searchFilters.forEach(function (filter) {
                for (var i = 0; i < $scope.filters.length; i++) {
                    if ($scope.filters[i].name == filter.name) {
                        console.log("filter is ", $scope.filters[i]);
                        $scope.filters[i].hide = false;
                        $scope.filters[i].popup.levels.forEach(function (level) {

                            level.data = [];
                            level.selected = false;
                            level.goNext = false;
                            console.log("level popup ", level);
                            delete $scope.searchObject.filters[level.name];
                        });

                    }
                }

                //filter.popup.levels.forEach(function (level) {

                //    level.data = [];
                //    level.selected = false;
                //    level.goNext = false;
                //    console.log("level popup ", level);
                //    delete $scope.searchObject.filters[level.name];
                //});
            });

            $scope.searchFilters = [];
            console.log("final Search Obj ", $scope.searchObject);
            $scope.filterResults = [];
            $scope.totalDataCount = 0;
            //originalFilter.popup.levels.forEach(function (level) {
            //    level.data = [];
            //    level.selected = false;
            //    level.goNext = false;
            //    delete $scope.searchObject.filters[level.name];
            //});
            $scope.closeLocationFilter();
            $scope.location.hide = false;

            $scope.clearDateFilter();
        }

        $scope.closePopUp = function () {
            $scope.closeAllFilters();
        }



        $scope.clearDateFilter = function () {

            $scope.startDate = null;
            $scope.endDate = null;
            $scope.execBulkDataOperation();
        }

        $scope.clearSingleFilter = function (filter) {
            console.log("filter passed",filter);
            //for (var i = 0; i < $scope.filters.length; i++) {
            //    if ($scope.filters[i].name == filter.name) {
            //        console.log("filter is ", $scope.filters[i]);
            //        $scope.filters[i].hide = false;
            //        $scope.filters[i].popup.levels.forEach(function (level) {

            //            level.data = [];
            //            level.selected = false;
            //            level.goNext = false;
            //            console.log("level popup ", level);
            //            delete $scope.searchObject.filters[level.name];
            //        });

            //    }
            //}
         var filterToBeClear=   $scope.filters.filter(function (singleFilter) {
                return singleFilter.name == filter.name;
            });
         console.log("filterToBeClear", filterToBeClear);
        }


        $scope.mystartDate = function () {
            console.log("start Date ", $scope.startDate);
            console.log("end Date ", $scope.endDate)
            alert($scope.startDate);
        }
    });
    app.controller('rootCtrl', function ($scope, $compile, paginationservice, $location, $rootScope, ajaxRFac, $state) {
        console.log("root ctrl init");

        $rootScope.$watch("autocompleteShow", function (nVal, oVal) {
            console.log("auto complete Show ", nVal);
            $scope.showAutoComplete = nVal;


        });

        $scope.autoCompleteOptions = {
            options: {
                //appendTo: "#inner-c-tags",
                html: true,
                focusOpen: false,
                onlySelectValid: true,
                minLength: 4,
                delay: 1000,
                search: function (event, ui) {
                    window.pageIndex = 0;
                },
                source: function (request, response) {
                    console.log("request ", request);
                    var filteredText = searchTextFilter(request.term);
                    $rootScope.filteredSearch = filteredText;
                    console.log("filteredText", filteredText);
                    ajaxRFac.GetSearchResultsFromAPI(filteredText).then(function (res) {
                        console.log("res is ", res);
                        var result = [];
                        var searchResults = [];
                        angular.forEach(res.responseEntity.searchResponse, function (item) {
                            console.log(item);
                            var suggestionObj = {
                                sector: item.sector,
                                subSector: item.subSector,
                                superRegion: item.superRegion,
                                search: request.term,
                                suggestionString: item.suggestionString,
                                stratumName: item.stratumName

                            }
                            searchResults.push(suggestionObj);
                            //var jsonObj = {
                            //    sector: item.Sector,
                            //    subSector: item.SubSector,
                            //    superRegion: item.SuperRegion,
                            //    sectorId: item.SectorId,
                            //    subSectorId: item.SubSectorId,
                            //    superRegionId: item.SuperRegionId,
                            //    AttrBucket: item.AttrBucket
                            //}

                            if ($scope.showAutoComplete) {
                                result.push({
                                    data: suggestionObj,
                                    label: $compile("<a class='agriculture' style='background-image: url(../images/Icons-11.png);background-repeat: no-repeat;background-position: 7px 7px;padding: 9px 20px 9px 45px;background-size:23px 23px;'>" + suggestionObj.suggestionString + " in <span class='label'> <span style='font-weight:500'>" + suggestionObj.subSector + "</span>,  " + suggestionObj.sector + " in " + suggestionObj.superRegion + "</span></a>")($scope),
                                    //  label: $compile("<a>" + suggestionObj.subSector + "  <span class='label'>, " + suggestionObj.suggestionString + " in " + suggestionObj.subSector + "," + suggestionObj.sector + " in " + suggestionObj.superRegion + "</span></a>")($scope),
                                    value: suggestionObj.suggestionString
                                });
                            }

                        });
                        $rootScope.searchResults = searchResults;
                        if (!result.length && $scope.showAutoComplete) {
                            result.push({
                                label: 'not found',
                                value: ''
                            });
                        }
                        response(result);
                    }, function (err) {
                        console.log("error is ", err);

                    });
                },
                select: function (event, ui) {
                    var data = ui.item.data;
                    filterData = data;
                    console.log(ui.item)
                    //$scope.sector = data.sectorId;
                    //$scope.superRegion = data.superRegionId;
                    //$scope.attributeIds = data.AttrBucket;
                    //$scope.subSectorId = data.subSectorId;
                    //$scope.subSectorTxt = data.subSector;
                    //$scope.sectorTxt = data.sector;
                    //$scope.superRegionTxt = data.superRegion;
                    $rootScope.searchObj = ui.item.data;
                    $state.go("search", { q: ui.item.data.suggestionString });
                    event.stopPropagation();
                },
            },
            methods: {},
        }

        $scope.searchResults = function () {
            if ($scope.resultn.length > 3) {
                $state.go("searchresults", { q: $scope.resultn });
            }

        }

    });
    app.controller('bulkMainCtrl', function ($scope, $compile, paginationservice, $location, $rootScope, ajaxRFac, $state) {


    });



    app.factory("ajaxApiFac", function ($http, $q, apiUrl) {
        var canceller = null;
        var seriesCanceller = null;
        return {
            getFilters: function (dataObj) {

                var req = {
                    method: 'POST',
                    url: apiUrl + 'rest/zdaly/query-with-filters',
                    data: dataObj
                }
                return $http(req);
            },
            getLocData:function(reqObj){
                var req = {
                    method: 'POST',
                    url: apiUrl + 'rest/zdaly/query-with-filters',
                    data: reqObj
                }
                return $http(req);
            },
            getLevelsData: function (reqObj, attributeName) {
                console.log("reqObj", reqObj);
                console.log("attributeName", attributeName);
                var defer = $q.defer();
                this.getFilters(reqObj).success(function (data) {

                    data = data.responseEntity.stratum[attributeName];

                    return defer.resolve(data);

                }).error(function () {
                    return defer.reject(failedResponse);
                });
                return defer.promise;



            },
            getPreviewData: function (reqObj, startDate, endDate) {
                var defer = $q.defer();
                var req = {
                    url: '/new/GetChartDataPreview',
                    method: 'POST',
                    data: { JsonObject: JSON.stringify(reqObj) }
                }

                $http(req).success(function (data) {
                    defer.resolve(data);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;
            },
            getSeriesIds: function (searchObj) {
                console.log("seriesCanceller", seriesCanceller);

                if (seriesCanceller)
                    seriesCanceller.resolve("terminated");
                var defer = $q.defer();
                seriesCanceller = defer;
                var req = {
                    url: apiUrl + 'rest/zdaly/query-results',
                    method: 'POST',
                    data: searchObj
                }

                $http(req).success(function (data) {
                    defer.resolve(data);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;
            },
            getBulkDataCount: function (reqObj, startDate, endDate) {
                if (canceller)
                    canceller.resolve();
                var defer = $q.defer();
                canceller = defer;
                var req = {
                    url: '/new/GetBulkDataCount',
                    method: 'POST',
                    data: {
                        JsonObject:JSON.stringify(reqObj),
                        startDate: startDate,
                        endDate: endDate
                    }
                }

                $http(req).success(function (data) {
                    defer.resolve(data);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;

            },
            makeCsv: function (reqObj, startDate, endDate, savedObject, editId) {
                var defer = $q.defer();
                var req = {
                    url: '/new/GetChartDataCsv',
                    method: 'POST',
                    data: {
                        JsonObject:JSON.stringify(reqObj),
                        startDate: startDate,
                        endDate: endDate,
                       
                        editId: editId
                    }
                }
                $http(req).success(function (data) {
                    defer.resolve(data);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;
            },
            getSavedDataById: function (id) {
                var defer = $q.defer();
                var req = {
                    url: '/new/GetSavedData/' + id,
                    method: 'Get',

                }
                $http(req).success(function (data) {
                    defer.resolve(data);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;

            },
            //attrName:State,county
            getLocationData: function (attrName, selectedItems, reqObj) {
                var defer = $q.defer();
                var req = {
                    method: 'POST',
                    url: apiUrl + 'rest/zdaly/query-with-filters',
                    data: reqObj
                }
                $http(req).success(function (data) {
                    console.log("attrName", attrName);
                    console.log("parentName", selectedItems);
                    console.log("req Obj ", JSON.stringify(reqObj));
                    console.log("data.responseEntity.locations", data.responseEntity);
                    var attrData = data.responseEntity.locations[attrName];
                    if (!attrData) {
                        defer.reject("err");
                    }
                    var filteredData = attrData.filter(function (attrItem) {

                        return selectedItems.indexOf(attrItem.locationParent) > -1;
                    });
                    console.log("filtered Dtaa ", filteredData);
                    defer.resolve(filteredData);
                }).error(function (err) {
                    defer.resolve(err);
                });
                return defer.promise;
            }







        }


    });
    app.directive('breadCum', function ($http, $templateCache, $compile, ajaxApiFac) {

        return {
            restrict: 'AE',
            scope: {
                list: '=',

            },
            templateUrl: '/Angular/directives/templates/breadcum.html',
            controller: function ($scope) {
                console.log("list in breadcum", $scope.list);

                $scope.$watch("list", function (nVal, oVal) {
                    if (nVal) {
                        reInit();
                    }

                }, true);


                function reInit() {
                    var breadcums = makeBreadCum($scope.list);

                    $scope.breadcums = breadcums;
                }

                //making breadcum
                function makeBreadCum(list) {
                    //Main LIst
                    var mainBreadList = [];

                    var newList = JSON.parse(JSON.stringify(list));
                    //return rootElems;
                    var mainObj = [];

                    for (var i = 0; i < newList.length; i++) {
                        var find = false;
                        for (var j = 0; j < newList.length; j++) {
                            if (newList[i].parent == newList[j].stratum) {
                                find = true;
                            }


                        }
                        if (!find) {
                            mainObj.push(newList[i]);
                        }
                    }

                    // return mainObj;
                    mainObj.forEach(function (rootItem) {
                        var breadItem = {
                            levels: []
                        }

                        rootItem.children = [];
                        var process = true;
                        var processItem = rootItem;
                        while (process) {
                            breadItem.levels.push(processItem);
                            var child = getChild(processItem.stratum, newList);
                            newList.splice(newList.indexOf(child), 1);

                            if (child) {
                                processItem.children.push(child);
                                processItem = child;
                                processItem.children = [];
                            }
                            else {
                                process = false;
                            }

                        }
                        mainBreadList.push(breadItem)
                    });

                    return mainBreadList;

                }

                function getChild(parentElemName, list) {
                    console.log("parentElemName", parentElemName);
                    console.log("list", list);
                    var child = list.filter(function (item) {
                        //console.log("item parent", item.parent);
                        //console.log("Elem Name ", parentElemName);
                        //console.log("result ", item.parent == parentElemName);
                        return item.parent == parentElemName;


                    });
                    console.log("child ", child);
                    if (child.length > 0)
                        return child[0];
                    else
                        return null;
                }

            }

        }


    });

    app.directive('locationPopup', function ($http, $templateCache, $compile, ajaxApiFac) {
        return {
            restrict: 'AE',
            scope: {
                locData: '=',
                searchParams: '=',
                closeFilter: '&',
                selectFilter: '&'

            },
            controller: function ($scope) {
                $scope.computeShow = function (levels, index) {
                    if (index == 0)
                        return true;
                    else {
                        if (levels[index - 1].goNext)
                            return true
                        else
                            return false;
                    }
                }

                $scope.selectMultiple = function (event, datai, popupItem, levelIndex, level, levels) {

                    if (level.selected.indexOf(popupItem) > -1) {
                        level.selected.splice(level.selected.indexOf(popupItem), 1);
                        var filtered = level.selectedObj.filter(function (obj) {
                            return obj.item != popupItem;
                        });
                        level.selectedObj = filtered;
                    }
                    else {
                        level.selected.push(popupItem);
                        level.selectedObj.push({ item: popupItem, locationParent: datai.locationParent });
                    }

                    console.log("Data I ", datai);
                    console.log("item   ", popupItem);
                    if (levelIndex > 0) {
                        //making text like country:state or state:county
                        if (level.selectedObj.length > 0) {
                            $scope.searchParams.locations[level.name] = [];
                            var searchFilter = level.selectedObj.map(function (item) {

                                var prevLevelsSelected = levels[levelIndex - 1].selected;
                                console.log("prevLevelsSelected", prevLevelsSelected);
                                var parentName = null;
                                for (var i = 0; i < prevLevelsSelected.length; i++) {
                                    console.log("prevLevelsSelected[i]", prevLevelsSelected[i]);
                                    console.log("item.locationParent", item.locationParent);
                                    if (prevLevelsSelected[i] == item.locationParent) {
                                        parentName = prevLevelsSelected[i];
                                        break;
                                    }
                                }
                                return parentName + ":" + item.item;
                            });
                            $scope.searchParams.locations[level.name] = searchFilter;
                            console.log("$scope.searchParams", $scope.searchParams);
                        }

                    }

                    //reset Levels
                    //if (level.selected.length == 0)
                    //    return false;
                    ///reset next drills
                    var levelIndex = levels.indexOf(level);
                    for (var i = levelIndex + 1; i < levels.length; i++) {
                        delete $scope.searchParams.locations[levels[i].name];
                        levels[i].goNext = false;
                        //if (i >= levelIndex) {
                        //    levels[i].goNext = false;
                        //}
                        //if (i > levelIndex) {

                        levels[i].data = [];
                        levels[i].selected = [];
                        //}
                    }
                    levels[levelIndex].goNext = false;
                    ///////

                    if (levels[levelIndex + 1]) {
                        console.log("next level ");
                        ajaxApiFac.getLocationData(levels[levelIndex + 1].name, level.selected, $scope.searchParams).then(function (data) {
                            console.log("level Dtaa ", levels[levelIndex + 1]);
                            console.log("data is ", data);
                            levels[levelIndex + 1].data = data;
                        }, function (err) {
                            levels[levelIndex + 1].data = null;

                            console.log("err", err);
                        });
                        console.log("levels[levelIndex].selected", levels[levelIndex].selected);
                        if (levels[levelIndex].selected.length > 0) {
                            levels[levelIndex].goNext = true;
                        }

                    }


                }
            },
            templateUrl: '/Angular/directives/templates/locations.html'
        }


    });

    app.directive('megaPopup', function ($http, $templateCache, $compile, ajaxApiFac) {

        return {
            restrict: 'AE',
            scope: {
                popup: '=',
                searchParams: '=',
                selectFn: '&',
                closePopup: '&'
            },
            controller: function ($scope) {
                $scope.computeShow = function (levels, index) {
                    if (index == 0)
                        return true;
                    else {
                        if (levels[index - 1].goNext)
                            return true
                        else
                            return false;
                    }
                }

                $scope.selectMultiple = function (event, selectedLevelItem, index, level, levels) {
                    console.log("event is ", event);
                    console.log("levels are ", levels);
                    //  alert();


                    // if (event.ctrlKey || event.shiftKey) {

                    console.log("selectedLevelItem", selectedLevelItem);
                    console.log("index", index);
                    console.log("level", level);
                    console.log("levels", levels);

                    if (level.selected.indexOf(selectedLevelItem) > -1) {
                        level.selected.splice(level.selected.indexOf(selectedLevelItem), 1);
                    }
                    else {
                        level.selected.push(selectedLevelItem);
                    }
                    $scope.selected(level, levels);
                    // }
                }
                $scope.selected = function (level, levels) {
                    if (level.selected.length == 0)
                        return false;
                    ///reset next drills
                    var levelIndex = levels.indexOf(level);
                    for (var i = 0; i < levels.length; i++) {
                        delete $scope.searchParams.filters[levels[i].name];
                        if (i >= levelIndex) {
                            levels[i].goNext = false;
                        }
                        if (i > levelIndex) {

                            levels[i].data = [];
                            levels[i].selected = [];
                        }
                    }

                    level.goNext = true;
                    ///


                    var currentLevelIndex = levels.indexOf(level);

                    $scope.searchParams.filters[level.name] = level.selected;
                    ajaxApiFac.getLevelsData($scope.searchParams, levels[currentLevelIndex + 1].name).then(function (data) {
                        console.log("attribute dir data", data);
                        levels[currentLevelIndex + 1].data = data;

                    });
                }
                $scope.deselect = function (level) {
                    //level.goNext = false;
                }


                $scope.getNextLevel = function (selectedLevelItem, index, level, levels) {
                    level.selected = selectedLevelItem;
                    if (levels[(index + 1)]) {
                        var newIndex = (index + 1);
                        var attributeName = "Attribute" + newIndex;
                        for (var i = newIndex + 1; i < newIndex + 3; i++) {
                            if ($scope.searchParams.filters["Attribute" + i]) {
                                delete $scope.searchParams.filters["Attribute" + i];
                            }


                        }
                        var j = index + 1;
                        while (j <= levels.length) {
                            console.log(levels);
                            console.log(j);
                            if (levels[j]) {
                                levels[j].data = [];
                                levels[j].selected = null;
                            }

                            j++;
                        }
                        $scope.searchParams.filters[attributeName] = [selectedLevelItem];
                        console.log("search Params ", $scope.searchParams)


                        ajaxApiFac.getLevelsData($scope.searchParams, "Attribute" + (index + 2)).then(function (data) {
                            console.log("attribute dir data", data);
                            levels[(index + 1)].data = data;

                        });
                    }

                }


            },
            templateUrl: '/Angular/directives/templates/megapopupbulk.html',
            link: function (scope, element, attrs) {

            }

        }

    });




    app.directive('mscrollbar', function ($http, $templateCache, $compile) {

        return {
            restrict: 'AE',


            link: function (scope, element, attrs) {
                $(element).mCustomScrollbar({
                    theme: "light-3",
                    autoExpandScrollbar: true,
                    advanced: { autoExpandHorizontalScroll: true }
                });
            }

        }

    });


    app.directive('rightPanel', function ($http, $templateCache, $compile) {

        return {
            restrict: 'AE',
            templateUrl: '/Angular/directives/templates/bulkrightbar.html',
            scope: {
                selectedData: '=',
                clearAll: '&',
                previewData: '&',
                downloadData: '&',
                downloadFile: '=',
                startDate: '=',
                endDate: '=',
                clearDate: '&',
                locationFilter: '=',
                searchObject: '=',
                bulkdataFn: '&',
                clearSingleFilter:'&'
            },
            controller: function ($scope) {
                $scope.removeTag = function (tag, level, mainLevel, filter,topLevelFilter) {
                    console.log("mainLevel ", mainLevel);
                    console.log("level", level);
                    console.log("tag", tag);
                    console.log("filter", filter);
                    console.log("topLevelFilter", topLevelFilter);
                    console.log("$scope.searchObject", $scope.searchObject);
                var selectedMainFilter=mainLevel.filter(function (level) {
                        var selected=false;
                        level.selected.forEach(function (minlevel) {

                            console.info("minlevel", minlevel);
                            console.log("tag", tag);
                            if (minlevel==tag)
                                selected = true;
                        });
                        return selected;
                });
                console.log("selectedMainFilter", selectedMainFilter);
                console.log("$scope.searchObjectMain", $scope.searchObject);
                console.log("$scope.searchObject.filters[selectedMainFilter[0].name]", $scope.searchObject.filters[selectedMainFilter[0].name]);
                console.log("tag Index", $scope.searchObject.filters[selectedMainFilter[0].name].indexOf(tag));
                $scope.searchObject.filters[selectedMainFilter[0].name].splice($scope.searchObject.filters[selectedMainFilter[0].name].indexOf(tag), 1);
                console.log("$scope.searchObject", $scope.searchObject);
                level.splice(level.indexOf(tag), 1);

                if (filter.name == topLevelFilter.stratumName) {
                    console.log("Equal", filter.selected);
                    if (filter.selected.length == 0) {
                      //  $scope.clearSingleFilter({ filter: topLevelFilter });
                    }
                }
                console.log("topLevelFilter", topLevelFilter);
                console.log("selectedData", $scope.selectedData);

                $scope.bulkdataFn();

                }
                $scope.removeLocationTag = function (key, locationsObj, selectedItem) {
                    
                    locationsObj[key].splice(locationsObj[key].indexOf(selectedItem),1);
                    if (locationsObj[key].length == 0) {
                        delete locationsObj[key];
                    }
                    $scope.bulkdataFn();
                    // console.log(" $scope.searchObject", $scope.searchObject);
                }

            },
            link: function (scope, element, attrs) {
                $(element).find("#bulkscroll").mCustomScrollbar({
                    theme: "light-3",
                    autoExpandScrollbar: true,
                    advanced: { autoExpandHorizontalScroll: true }
                });
            }

        }

    });


    app.directive('loader', function () {
        return {
            restrict: 'AE',
            templateUrl: '/Angular/directives/templates/smallloader.html',
            scope: {
                size: '=',

            },
            link: function (scope, elem, attr) {


            }

        }
    });

    app.directive('mainLoader', function () {
        return {
            restrict: 'AE',
            templateUrl: '/Angular/directives/templates/mainloader.html',

            link: function (scope, elem, attr) {


            }

        }
    });


    app.directive('ngEnter', function () {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which === 13) {
                    scope.$apply(function () {
                        scope.$eval(attrs.ngEnter, { 'event': event });
                    });

                    event.preventDefault();
                }
            });
        };
    });
    app.directive('detailsModal', function () {
        return {
            restrict: 'AE',
            templateUrl: '/Angular/directives/templates/modal.html',
            scope: {
                bodyData: '=',
                modalOptions: '='
            },
            link: function (scope, elem, attr) {

                scope.$watch("bodyData", function (nVal, oVal) {

                    if (nVal) {

                        setTimeout(function () {
                            $(elem).find("#modalTable").mCustomScrollbar('destroy');

                            setTimeout(function () {
                                $(elem).find("#modalTable").mCustomScrollbar({
                                    theme: "light-3",
                                    autoExpandScrollbar: true,
                                    advanced: { autoExpandHorizontalScroll: true }
                                });
                            }, 30);


                        }, 300);

                        scope.bodyData = nVal;
                    }
                });
                scope.$watch("modalOptions", function (nVal, oVal) {
                    if (nVal) {

                        $("#cTitle").html(nVal.title);

                        if (nVal.show) {
                            $('#statsModal').modal('show');
                        }
                        else {
                            $('#statsModal').modal('hide');
                        }
                    }

                });
            }

        }
    });

    app.directive('datePicker', function () {
        return {

            restrict: 'AE',
            scope: {
                dateModel: '=',
                refreshFilter: '&',
                defaultText: '@'
            },
            link: function (scope, elem, attrs, ctrl) {
                console.log("element is ", elem);
                $(elem).daterangepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    startDate: moment(),

                });
                $(elem).change(function (e) {
                    console.log("element is  ", $(elem));
                    console.log("chened ", e.target.value);

                    //ctrl.$setViewValue(dt);
                    //ctrl.$render();
                    //scope.$apply();
                    if (e.target.value) {
                        scope.dateModel = e.target.value;
                    }
                    else {
                        scope.dateModel = null;
                    }
                    scope.refreshFilter();
                    scope.$apply();
                });
                scope.$watch("dateModel", function (nVal, oVal) {
                    if (!nVal) {
                        $(elem).val(scope.defaultText);
                    }
                    else {
                        $(elem).val(nVal);
                    }
                });
                console.log("default text ", scope.defaultText);


            }


        }
    });

    app.directive('bulkLoader', function ($http, $templateCache, $compile) {

        return {
            restrict: 'AE',
            scope: {
                show: '=',
                downloadLink: '='
            },
            templateUrl: '/Angular/directives/templates/bulkloader.html',
            controller: function ($scope) {
                $scope.closePopup = function () {
                    $scope.show = false;
                    $scope.downloadLink = null;
                }
            },
            link: function (scope, element, attrs) {

            }

        }

    });

    app.directive('tabsMenu', function ($http, $templateCache, $compile) {

        return {
            restrict: 'AE',
           
           
             
            link: function (scope, element, attrs) {
                $(".nav-tabs li a").click(function (event) {
                    event.preventDefault();
                    //alert();
                    //$(this).parent().addClass("current");
                    //$(this).parent().siblings().removeClass("current");
                    //var tab = $(this).attr("href");
                    //$(".tab-content").not(tab).css("display", "none");
                    //$(tab).fadeIn();
                });
            }

        }

    });

    //filters

    app.filter("empty", function () {
        return function (originalVal, replacement) {
            if (originalVal == "")
                return replacement;
            else
                return originalVal;
        }
    });
    app.filter('replacePipe', function () {

        return function (original) {
            var newOrig = original.split("|");
            newOrig = newOrig.filter(function (item) {
                return (item) ? true : false;

            }).map(function (item) {
                return capitalizeFirstLetter(item.toLowerCase());
            });
            return newOrig.join(", ");
        }

    });

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    function searchTextFilter(searchString) {
        var searchParts = searchString.split(" ");
        var filteredParts = searchParts.filter(function (part) {
            return part.length > 3;

        });
        return filteredParts.join(" ");
    }


})();

