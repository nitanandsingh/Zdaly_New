﻿angular.module('elmahCore', []);
angular.module('elmahCore').factory('coreFactory', function ($http, httpService) {


    return {
        getAllErrors: function (dataObj) {
           return httpService.post('/ElmahTrigbit/GetAllErrors', dataObj);
            //var req={
            //    method: 'POST',
            //    url: '/ElmahTrigbit/GetAllErrors',
            //    data:dataObj
            //}
           // return $http(req);
        },
        getGroupErrors: function (dataObj) {
            return httpService.post('/ElmahTrigbit/GetErrorsGroupBy', dataObj);
            //var req = {
            //    method: 'POST',
            //    url: '/ElmahTrigbit/GetErrorsGroupBy',
            //    data: dataObj
            //}
            //return $http(req);
        },
        getErrorsFrequent: function () {
            return httpService.get("/ElmahTrigbit/GetErrorsForChart");
           // return $http.get("/ElmahTrigbit/GetErrorsForChart");
        },
        getFrequentErrors: function () {
            return httpService.get("/ElmahTrigbit/GetFrequentErrors");
          //  return $http.get("/ElmahTrigbit/GetFrequentErrors");
        },
        getFrequentURL: function () {
            return httpService.get("/ElmahTrigbit/GetFrequentURL");
          //  return $http.get("/ElmahTrigbit/GetFrequentURL");
        },
        getRecentErrors: function () {
            return httpService.get("/ElmahTrigbit/getRecentErrors");
            //return $http.get("/ElmahTrigbit/getRecentErrors");
        },
        getErrorCount: function () {
            return httpService.get("/ElmahTrigbit/GetErrorsCount");
            //return $http.get("/ElmahTrigbit/GetErrorsCount")
        },
        getErrorDetail: function (id) {
            return httpService.get("/ElmahTrigbit/GetErrorDetail/" + id);
        }
    }
});



angular.module('elmahCore').service('pendingRequests', function () {
    var pending = [];
    this.get = function () {
        return pending;
    };
    this.add = function (request) {
        pending.push(request);
    };
    this.remove = function (request) {
        pending = _.filter(pending, function (p) {
            return p.url !== request;
        });
    };
    this.cancelAll = function () {
        angular.forEach(pending, function (p) {
            p.canceller.resolve();
        });
        pending.length = 0;
    };
})

angular.module('elmahCore').service('httpService', ['$http', '$q', 'pendingRequests', function ($http, $q, pendingRequests) {
    this.get = function (url) {
        var canceller = $q.defer();
        pendingRequests.add({
            url: url,
            canceller: canceller
        });
        //Request gets cancelled if the timeout-promise is resolved
        var requestPromise = $http.get(url, { timeout: canceller.promise });
        //Once a request has failed or succeeded, remove it from the pending list
        requestPromise.finally(function () {
            pendingRequests.remove(url);
        });
        return requestPromise;
    };
    this.post = function (url,dataObj) {
        var canceller = $q.defer();
        pendingRequests.add({
            url: url,
            canceller: canceller
        });
        //Request gets cancelled if the timeout-promise is resolved
        var req = {
            method: 'POST',
            url: url,
            timeout: canceller.promise,
            data: dataObj
        }
        var requestPromise = $http(req);
        //Once a request has failed or succeeded, remove it from the pending list
        requestPromise.finally(function () {
            pendingRequests.remove(url);
        });
        return requestPromise;
    }

}]);



angular.module('elmahCore').factory('globalVariables', function () {
    var searchVariable = "";
    var searchWatchers = {};
    return {
        watchsearchVariable: function (callback) {
           
            searchWatchers=callback;
            console.log("callback watch registered", searchWatchers);
           
        },
        getSearchWatchers:function(){
            return searchWatchers;
        },
        notifysearchVariable: function (newVal) {
            console.log("calling search watchers", searchWatchers);
         
          
        }
    }
});