﻿angular.module('zdlay').factory('rootFactory',function(){
    return {
        changeLayout: function(){
            $('.container-fluid').css('display', 'none');
        }
    };
});