﻿angular.module("zdlay").factory("ajaxRFac", function ($http, $q) {
    return {
        addDestinationSet: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/addDestinationset',
                data: data
            }
            return $http(req);
        },
        listDestinationSet: function (id) {


            var req = {
                method: 'Get',
                url: '/Routes/listDestinationset/' + ((id) ? id : ""),

            }
            return $http(req);
        },
        addOperators: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/AddOperators',
                data: data
            }
            return $http(req);
        },
        listOperators: function (id) {
            console.log("LIst Operators Called");
            if (!id)
                console.error("List Destination set Id missing");
            var req = {
                method: 'Get',
                url: '/Routes/ListOperators/' + id,

            }
            return $http(req);
        },

        listRoutes: function (obj) {

            var req = {
                method: 'Post',
                url: '/Routes/ListRoutes/',
                data: obj

            }
            return $http(req);

        },
        deleteDestinationSet: function (id) {
            var req = {
                method: 'Post',
                url: '/Routes/deleteDestinationSet/',
                data: { id: id }

            }
            return $http(req);
        },
        deleteOperator: function (id) {
            var req = {
                method: 'Post',
                url: '/Routes/deleteOperator/',
                data: { id: id }

            }
            return $http(req);
        },
        addRoute: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/addRoute',
                data: data
            }
            return $http(req);
        },
        addServiceRoute: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/addServiceRoute',
                data: data
            }
            return $http(req);
        },
        updateRoute: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/updateRoute',
                data: data
            }
            return $http(req);
        },
        updateServiceRoute: function (data) {
            var req = {
                method: 'POST',
                url: '/Routes/updateServiceRoute',
                data: data
            }
            return $http(req);
        },
        listServiceRoutes: function (obj) {

            var req = {
                method: 'Post',
                url: '/Routes/ListServiceRoutes/',
                data: obj

            }
            return $http(req);

        },
        getDsetGroups: function () {
            var req = {
                method: 'Get',
                url: '/Routes/GetDsetTypes/'


            }
            return $http(req);

        },
        getDsetByType: function (id) {
            var req = {
                method: 'Get',
                url: '/Routes/GetDsetByType/' + id


            }
            return $http(req);

        },
        listRoutesByType: function (obj) {

            var req = {
                method: 'Post',
                url: '/Routes/ListRoutesByType/',
                data: obj

            }
            return $http(req);

        },
        listIRRoutePrices: function (obj) {

            var req = {
                method: 'Post',
                url: '/Routes/ListIRRoutePrices/',
                data: obj

            }
            return $http(req);

        },


        //edit and type Data
        getTypeAndEditData: function (dsetId) {
            var deferred = $q.defer();
            var editData = {

            }
            $q.all([
                this.getDsetGroups().success(function (data) {
                    editData.type = data;

                }).error(function (data) {
                    editData.type = null;
                }),
               $http({
                   method: 'Get',
                   url: '/Routes/DestinationSetById/' + dsetId


               }).success(function (data) {
                   editData.edit = data;
               }).error(function (data) {
                   editData.edit = null;
               })


            ]).then(function () {
                deferred.resolve(editData);
            });
            return deferred.promise;
        },
        //Get all Operators List
        getOperatorsListById: function (id) {
            var req = {
                method: 'Get',
                url: '/Routes/GetOperatorsList/' + id


            }
            return $http(req);

        },
        //deleteOperatorByNameAndDset
        deleteOperatorDset: function (obj) {
            var req = {
                method: 'Post',
                url: '/Routes/DeleteOperator/',
                data: obj

            }
            return $http(req);


        },
        //LIst All Operators
        getOperatorsList: function (obj) {
            var req = {
                method: 'Post',
                url: '/Routes/OperatorsList/',
                data: obj

            }
            return $http(req);


        },
        listIRLowPrices: function (obj) {

            var req = {
                method: 'Post',
                url: '/Routes/ListIRLowPrices/',
                data: obj

            }
            return $http(req);

        },
        //destinations for filter without international rates
        listDestinationSetFilter: function () {
            var req = {
                method: 'Get',
                url: '/Routes/ListDestinationSetFilter/'


            }
            return $http(req);
        },
        //Get Combined routes by type
        getCombinedRoutesByType: function (obj) {
            var req = {
                method: 'Post',
                url: '/Routes/GetCombinedRoutesByType/',
                data: obj

            }
            return $http(req);
        },
        getDonorInformation: function (number) {
            var req = {

                url: '/Porting/getDonorInformation/' + number,


            }
            return $http(req);
        },
        saveNewPortRequest: function (obj) {
            var req = {
                method: 'Post',
                url: '/Porting/SaveNewPortRequest/',
                data: obj

            }
            return $http(req);
        },
        getAllRequests: function () {
            var req = {

                url: '/Porting/getAllRequests/',


            }
            return $http(req);
        },
        updateStatus: function (obj) {
            var req = {
                method: 'Post',
                url: '/Porting/UpdatePortingStatus/',
                data: obj

            }
            return $http(req);
        },
        //Api Geolocation
        getAddressAPI: function (postCode, number) {
            console.log(postCode, number)
            console.log("url", 'https://postcode-api.apiwise.nl/v2/addresses/?postcode=' + postCode + '&number=' + number);
            var req = {
                method: 'Get',
                url: 'https://postcode-api.apiwise.nl/v2/addresses/?postcode=' + postCode + '&number=' + number,

                headers: {
                    "X-Api-Key": "u0UV1Xgwio6NXc27GhIOXaLA5AmWgRCJ9rn3husB"
                }

            }
            return $http(req);
        },
        getCombinedTotalCount: function (id) {
            var req = {

                url: '/Routes/GetCombinedTotalCount/' + id,


            }
            return $http(req);

        },

        getContactList: function () {
            var req = {

                url: '/telegram/GetAllContacts',


            }
            return $http(req);
        },
        sendMessage: function (data) {
            var req = {

                url: '/telegram/sendMessage',
                method: 'POST',
                data: data

            }
            return $http(req);
        },
        getTelegramOtp: function (data) {
            var req = {

                url: '/telegram/GetOtp',
                method: 'POST',
                data: data

            }
            return $http(req);
        },
        registerNumber: function (data) {
            var req = {

                url: '/telegram/AuthenticateUser',
                method: 'POST',
                data: data

            }
            return $http(req);
        },
        sendMessagePhoneNumber: function (data) {
            var req = {

                url: '/telegram/SendMessagePhoneNumber',
                method: 'POST',
                data: data

            }
            return $http(req);

        },
        isAuthenticated: function () {
            var req = {

                url: '/telegram/IsAuthenticated',


            }
            return $http(req);
        },
        getTelegramContacts: function () {
            var req = {

                url: '/telegram/GetTelegramContacts',


            }
            return $http(req);

        },
        getChatHistory: function (data) {
            var req = {

                url: '/telegram/GetChatHistory',
                method: 'POST',
                data: data

            }
            return $http(req);

        },
        sendMessage: function (data) {
            var req = {

                url: '/telegram/SendMessage',
                method: 'POST',
                data: data

            }
            return $http(req);

        },


        //Dashboard Methods
        getTop5DurationCalls: function (data) {
            var req = {

                url: '/dashboard/GetTop5DurationCalls',
                method: 'POST',
                data: data

            }
            return $http(req);
        },
        getPrefixesCalled: function (data) {
            var req = {

                url: '/dashboard/GetTopPrefixesCalled',
                method: 'POST',
                data: data

            }
            return $http(req);
        },

        getCallStatusPieChart: function (data) {
            var req = {

                url: '/dashboard/GetCallStatusPieChart',
                method: 'POST',
                data: data

            }
            return $http(req);
        },

        getTopCountriesCalled: function (data) {
            var req = {

                url: '/dashboard/getTopCountriesCalled',
                method: 'POST',
                data: data

            }
            return $http(req);
        },

        getSummaryReportData: function (data) {
            var req = {

                url: '/dashboard/getSummaryReportData',
                method: 'POST',
                data: data

            }
            return $http(req);
        }







    }


});