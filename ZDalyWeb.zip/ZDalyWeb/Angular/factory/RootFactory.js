﻿angular.module('zdlay').factory('sectorFactory', function () {
    var sectorsData = [];
    return {

        getSectors: function () {
            sectorsData = [
        {
            name: "Agriculture",
            liClass: "agriculture",
            sectorClass: "agriculture",
            sectorTarget: "#agrimodal",
            subs: [
                "livestock",
                "Meat",
                "Fish Poulty"
            ],
            nav: {
                id: "agrinav",
                navClass: "agrinav"
            }
        },
            {
                name: "ENERGY, oil,gas",
                liClass: "livestocksec",
                sectorClass: "livestock",
                sectorTarget: "#livestocksmodal",
                subs: [
                    "livestock",
                    "Meat",
                    "Fish Poulty"
                ],
                nav: {
                    id: "oilgasnav",
                    navClass: "oilgasnav"
                }

            }, {
                name: "INDUSTRY SERVICES",
                liClass: "environmentsec",
                sectorClass: "environment_mgnmnt",
                sectorTarget: "#environmentmodal",
                subs: [
                    "livestock",
                    "Meat",
                    "Fish Poulty"
                ],
                nav: {
                    id: "environmentnav",
                    navClass: "environmentnav"
                }
            },
            {
                name: "LABOR STATISTICS",
                liClass: "laborsec",
                sectorClass: "labor_stats",
                sectorTarget: "#labormodal",
                subs: [
                    "livestock",
                    "Meat",
                    "Fish Poulty"
                ],
                nav: {
                    id: "agrinav",
                    navClass: "agrinav"
                }
            },
            {
                name: "INTERNATIONAL TRADE",
                liClass: "tradesec",
                sectorClass: "trade",
                sectorTarget: "#trademodal",
                subs: [
                    "livestock",
                    "Meat",
                    "Fish Poulty"
                ],
                nav: {
                    id: "agrinav",
                    navClass: "agrinav"
                }
            }
            ];
            return sectorsData;
        }
    };
});

app.factory('zdlay', ['$http', '$q', function ($http, $q) {
    var self = this;

    self.GetCountries = function (sector, superRegion, attributeIds) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCountries',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetStates = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetStates',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetCounties = function (sector, superRegion, attributeIds, regionId) {
        var defer = $q.defer();
        $http({
            url: '/api/Search/GetCounties',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAttributeLevel1 = function (params) {
        var defer = $q.defer();
        console.log(params);
        $http({
            url: 'http://54.71.24.240:8080/rest/zdaly/query-with-filters',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: params,
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetFilterTypes = function (sector, superRegion, attributeIds, regionId, entryId, string) {
        var defer = $q.defer();
        //$.ajax({
        //    url: "/api/Search/GetFilterTypes",
        //    type: "post",
        //    beforeSend: function (xhr) {

        //        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
        //    },
        //    complete: function () {

        //    },
        //    dataType: 'json',
        //    contentType: 'application/json; charset=utf-8',
        //    data: JSON.stringify({ "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId, "entryId": entryId }),
        //    success: function (response) {
        //        console.log(response)
        //    },
        //    error: function (xhr, ajaxOptions, thrownError) { alert(xhr.responseText); }
        //});
        //$http({
        //    url: '/api/Search/GetFilterTypes',
        //    method: "POST",
        //    headers: { 'Content-Type': 'application/json', },
        //    data: { "sector": sector, "superRegion": superRegion, "attributeIds": attributeIds, "regionId": regionId, "entryId": entryId },
        //}).success(function (data, status, headers, config) {
        //    return defer.resolve(data);
        //}).error(function (failedResponse, status, headers, config) {
        //    return defer.reject(failedResponse);
        //});

        $http({
            url: 'http://54.71.24.240:8080/rest/zdaly/match-query/' + string,
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetFilterLevel1 = function (stratumId, attributeIds, regionId) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAttributeLevel1',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "stratumId": stratumId, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }
    self.GetFilterNLevel = function (levelId, regionId, attributeIds) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAttributeNLevel',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "levelId": levelId, "attributeIds": attributeIds, "regionId": regionId },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetAllSectors = function () {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetAllSectors',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSearchResult = function (query) {

        var defer = $q.defer();
        $http({
            url: '/api/Search/GetSearchResult',
            method: "GET",
            headers: { 'Content-Type': 'application/json', },
            params: { "query": query }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.RedirectToDashboard = function (sector, superRegion, selectedFilters, defautAttrs, searchResult, selectedFilterLevels, selectedLocation, sText, filterJsonString) {
        var defer = $q.defer();
        $http({
            url: '/New/dashboardFilter',
            method: "POST",
            headers: { 'Content-Type': 'application/json', },
            data: { "sector": sector, "superRegion": superRegion, "selectionsAttrs": selectedFilters, "attributeIds": defautAttrs, "searchResult": searchResult, "selectedFilterLevels": selectedFilterLevels, "Location": selectedLocation, "sText": sText, "FilteredJsonString": filterJsonString },
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    self.GetSearchResultsFromAPI = function (searchString) {
        var defer = $q.defer();
        delete $http.defaults.headers.common['X-Requested-With'];
        $http({
            url: 'http://54.71.24.240:8080/rest/zdaly/wilcard-search/' + searchString,
            method: "GET",
            headers: { 'Content-Type': 'application/json;charset=UTF-8', }
        }).success(function (data, status, headers, config) {
            return defer.resolve(data);
        }).error(function (failedResponse, status, headers, config) {
            console.log(status);
            return defer.reject(failedResponse);
        });

        return defer.promise;
    }

    return self;

}]);