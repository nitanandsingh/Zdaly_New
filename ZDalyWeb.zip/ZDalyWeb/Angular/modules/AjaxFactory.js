﻿angular.module("bulkData").factory("ajaxRFac", function ($http, $q) {
    return {
        GetSearchResult: function (query) {
            var defer = $q.defer();
            $http({
                url: '/api/Search/GetSearchResult',
                method: "GET",
                headers: { 'Content-Type': 'application/json', },
                params: { "query": query }
            }).success(function (data, status, headers, config) {
                return defer.resolve(data);
            }).error(function (failedResponse, status, headers, config) {
                return defer.reject(failedResponse);
            });

            return defer.promise;
        },
        getTopCountriesCalled: function (data) {
            var req = {

                url: '/dashboard/getTopCountriesCalled',
                method: 'POST',
                data: data

            }
            return $http(req);
        }, GetSearchResultsFromAPI: function (searchString) {
            var defer = $q.defer();
            console.log("search string ", searchString);
            $http({
                url: 'http://54.71.24.240:8080/rest/zdaly/wilcard-search/' + searchString,
                method: "GET",
                headers: { 'Content-Type': 'application/json;charset=UTF-8', }
            }).success(function (data, status, headers, config) {
                return defer.resolve(data);
            }).error(function (failedResponse, status, headers, config) {
                console.log(failedResponse);
                console.log(headers);
                console.log(config);
                return defer.reject(failedResponse);
            });

            return defer.promise;
        },
        GetSampleFromAPI: function (searchString) {
            var defer = $q.defer();
            console.log("search string ", searchString);
            $http({
                url: '/api/' + searchString,
                method: "GET",
                headers: { 'Content-Type': 'application/json;charset=UTF-8', }
            }).success(function (data, status, headers, config) {
                return defer.resolve(data);
            }).error(function (failedResponse, status, headers, config) {
                console.log(failedResponse);
                console.log(headers);
                console.log(config);
                return defer.reject(failedResponse);
            });

            return defer.promise;
        }
    }
});