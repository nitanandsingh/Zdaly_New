// JavaScript source code

var app = angular.module('utilities', []);
app.controller("mainCtrl", function ($scope) {
    $scope.$on('imageUploaded', function (event, data) {
        $scope.data = "file Uploaded";
        console.log(event);
        console.log("data is ");
        console.log(data);
    });
});
app.directive("uploader", function () {
    return {
        restrict: 'AE',
        scope: {
            action: '@',
            mainMessage: '@',
            secondaryMessage: '@'
        },
        controller: function ($scope, $element, $rootScope) {

            console.log("Elem", $scope.action);

            this.sendFile = function () {



                $scope.uploading = true;
                $scope.mainHeading = $scope.mainMessage.length > 0 ? $scope.mainMessage : "Uploading Data";
                $scope.subHeading = $scope.secondaryMessage.length > 0 ? $scope.secondaryMessage : "Uploading Data.Please Wait";
                var $form = $($element).parents("form");
                console.log("form is ", $form);
                $form.attr("action", $scope.action);

                $scope.$apply(function () {
                    $scope.progressStyle = { 'width': 0 + "%" };
                    $scope.progress = 0;
                });

                $form.unbind("submit").ajaxSubmit({
                    type: "POST",
                    uploadProgress: function (evt, pos, tot, percComplete) {
                        $scope.$apply(function () {
                            $scope.progressStyle = { 'width': percComplete + "%" };
                            $scope.progress = percComplete;
                        });
                    },
                    error: function (evt, statusText, response, form) {
                        $form.removeAttr("action");
                        $scope.$apply(function () {
                            $scope.uploading = false;
                        });
                        $rootScope.$apply(function () {
                            alert("error block");
                            $rootScope.success = false;
                            $rootScope.msg = "Some Error occurred";
                            $rootScope.showMsgBar();
                        });
                    },
                    success: function (response, status, xhr, form) {
                        $form.removeAttr('action');
                        $scope.$emit('imageUploaded', response);
                        //$scope.$apply(function () {
                        //    $scope.avatar = filename;
                        //});
                        $scope.$apply(function () {
                            $scope.uploading = false;
                        });


                    }
                });
            }
        },
        templateUrl: '/Angular/partials/utility/Uploader.html',
        transclude: true

    }
});

app.directive("submitForm", function () {
    return {
        require: '^uploader',
        restrict: 'AE',
        link: function (scope, elem, attrs, ctrl) {
            console.log(elem);
            $(elem).on('click', function () {

                ctrl.sendFile();

            });
        }
    }
});

app.service('loadingService', function () {
    this.loadingText = "Loading";
    this.isShowing = false;
});

app.service('toastFactory', function ($timeout) {
    this.isOpen = false;
    this.type = 'success';
    this.msg = "Successfully Added";
    this.timeoutPromise = null;
    this.closeToast = function () {

        this.isOpen = false;
    }
    this.showToast = function () {
        this.isOpen = true;
        var $this = this;
        if (this.timeoutPromise)
            $timeout.cancel(this.timeoutPromise);

        //this.timeoutPromise = $timeout(function () {
        //    $this.isOpen = false;

        //}, 1500);
    }

});

app.directive('toast', function () {
    return {
        restrict: 'AE',
        templateUrl: '/Angular/partials/utility/Toast.html',

        controller: function ($scope, toastFactory) {

            $scope.toast = toastFactory;


        }
    }
});

app.directive("fileRequired", function () {
    return {
        restrict: 'AE',
        require:'ngModel',
        link:function(scope,elem,attrs,ctrl)
        {
            elem.bind('change',function(){
                scope.$apply(function(){
                    ctrl.$setViewValue(elem.val());
                    ctrl.$render();
                });
            });
        }


        }

});

app.filter('datefilter', function ($filter) {
    return function (input) {
        if (input == null) { return ""; }

        var _date = $filter('date')(new Date(input), 'dd MMM yyyy');

        return _date.toUpperCase();

    };
});

app.directive("loadingScreen", function (loadingService) {
    return {
        restrict: 'AE',
        templateUrl: '/angular/partials/utility/Loading.html',
        controller:function($scope)
        {
            $scope.loader = loadingService;
        }
    }
});

app.service("confirmDialog", function () {
    this.isOpen = false; this.status = null;
    this.showDialog=function()
    {
        this.isOpen = true;
        
    }
    //this.listenAction=function($scope)
    //{
    //    $scope.$watch('confirmDialog.status', function (val) {
    //        if(val)
    //        {
    //            return true;
    //        }
           
    //    }, true);
    //}
    //this.getStatus=function()
    //{
    //    return this.status;
    //}
});

app.directive("confirmBox", function (confirmDialog) {
    return {
        restrict: 'AE',
        templateUrl: '/Angular/partials/utility/ConfirmBox.html',
        //controller:function($scope)
        //{
        //    $scope.myDialog = confirmDialog;
        //},
        //link:function(scope,elem,attrs)
        //{
        //    scope.$watch('myDialog.isOpen', function (newVal) {
        //        console.log("service", newVal);
        //        if(newVal)
        //        {
        //            console.log($("#confirmmodel"));
        //            $("#confirmmodel").modal('show');

        //        }

        //    });
        //    $("#confirm").on('click', function () {
               
        //        scope.$apply(function () {
        //            scope.myDialog.status = true;
        //            console.log(scope.myDialog);
        //        });
        //    });
        //}
    }
});


//app.factory("confirmService", function ($http) {
//    return {
//   showConfirmDialog: function customAlertBox(callback) {
          
//       $("#confirmmodel").modal('show');

//            var isCalled=false;
//            $("#confirm").off().on('click', function (e) {
               
              
//                //e.preventDefault();
              
//                $("#confirmmodel").modal('hide');
//                callback(true);
               
               
               
//            });
//            $("body").on('click', "#modalclose-btn", function () {
//                $("#confirmmodel").modal('hide');
//        callback(false);

//    });

//}

//    }
   





//});

app.factory("dateUtility", function () {
    return {
        convertDate: function (jsonDate) {

            var re = /-?\d+/;
            var m = re.exec(jsonDate);
            var dateConverted = new Date(parseInt(m[0]));
            return dateConverted;
        }
    }

});


app.factory("confirmService", function ($http) {
    return {
        showConfirmDialog: function customAlertBox(data, label, btnClass, callback,noBtnText) {
            $("#confirm").html(label);
            $("#text-confirm").html(data);
            $("#confirm").removeAttr("class");
            $("#confirm").addClass("btn").addClass(btnClass);
            if (noBtnText)
            {
                $("#modalclose-btn").html(noBtnText);
            }
            //if (btnClass == "btn-success") {
            //    $("#confirm").removeClass("btn-danger");
            //    $("#confirm").addClass(btnClass);
            //}
            //else {
            //    $("#confirm").removeClass("btn-success");
            //    $("#confirm").addClass(btnClass);
            //}
            $("#confirmmodel").modal('show');

            var isCalled = false;
            $("#confirm").off().on('click', function (e) {



                //e.preventDefault();

                $("#confirmmodel").modal('hide');
                callback(true);


            });
            $("body").on('click', "#modalclose-btn", function () {
                callback(false);

            });

        }

    }






});






app.service('paginationservice', function () {
    this.page = 0;
    this.totalCount = 0;
    this.itemsshow = 0;
    this.colorSwatch = "cyan-swatch";
    this.changeSwtch = function (newSwatch) {
        this.colorSwatch = newSwatch;
    }
    this.setTotal = function (i) {
        this.totalCount = i;
    }
    this.getTotal = function () {
        return this.totalCount;
    }
    this.getPage = function () {
        return this.page;
    }
    
    // this.itemsshow = this.getTotal() > 5 ? 5 : this.getTotal();
    this.setItemsShow = function (i) {
        this.itemsshow = i;

    }
    this.getItemsShow = function () {
        return this.itemsshow;

    }

    this.showItems = function () {
        return this.itemsshow > 0 ? this.itemsshow : this.getTotal();
    }
    this.pages = function () { return Math.ceil(this.getTotal() / this.showItems()) };
    this.pageBtnShow = 3;
    this.changePage = function (page) {
        if (this.page == page)
            return false;
        this.page = page;
        this.notifyPageChange();
        console.log(this.page);
    }
    this.minCount = function () {
        var pageOffset = Math.ceil(Math.abs(this.pages() - this.pageBtnShow));
        console.log("PAGGGG", pageOffset);
        if (this.page > pageOffset + 1) {
            return pageOffset;
        }
        else if (this.page == 0) {
            return 0;

        }
        else {
            var minVal = this.page - (Math.ceil(this.pageBtnShow / 2) - 1);
            return minVal > 0 ? minVal : 0;
        }
    }
    //Navigation Controls
    this.prevpage = function () {
        if (this.page == 0)
            return;
        this.page--;
        this.notifyPageChange();
    }
    this.nextPage = function () {
        if (this.page == this.pages)
            return;
        this.page++;
        this.notifyPageChange();
    }
    this.isPrevButton = function () {
        return this.page > 0;
    }
    this.isNextButton = function () {
        return this.page < this.pages() - 1;
    }
    this.isFastPrev = function () {
        return this.page > 1;
    }
    this.fastPrev = function () {
        this.page = 0;
        this.notifyPageChange();
    }
    this.fastNext = function () {

        this.page = this.pages() - 1;
        this.notifyPageChange();
    }
    this.isFastNext = function () {
        return this.page < this.pages() - 1;
    }
    //callback schema
    //this.callbacks = [];
    //this.onPageChange = function (callback) {
    //    this.callbacks.push(callback);
    //    this.notifyPageChange();
    //}
    //this.notifyPageChange = function () {
    //    for (var i = 0; i < this.callbacks.length; i++) {
    //        this.callbacks[i](this.page, this.getItemsShow());
    //    }
    //}
    this.callback = {};
    this.onPageChange = function (callback) {
        this.callback=callback;
        this.notifyPageChange();
    }
    this.notifyPageChange = function () {
      
            this.callback(this.page, this.getItemsShow());
      
        }

});
app.filter('paginFilter', function (paginationservice) {
    return function (input, page) {
        console.log("filtering"); console.log(paginationservice.showItems());
        console.log(paginationservice.pages());
        console.log(paginationservice.pageBtnShow);
        console.log("minCount", paginationservice.minCount());
        if (!isFinite(paginationservice.pages())) {
            return [];
        }
        else if (paginationservice.page >= 0 && paginationservice.pages() >= paginationservice.pageBtnShow) {

            input = [];
            for (var i = paginationservice.minCount() ; i < paginationservice.minCount() + paginationservice.pageBtnShow ; i++) {
                input.push(i);
            }
            return input;
        }
        else {
            console.log("else block working");
            input = [];
            for (var i = paginationservice.minCount() ; i < paginationservice.pages() ; i++) {
                input.push(i);
            }
            return input;
        }

    }
});
app.directive('pagination', function (paginationservice) {
    return {
        restrict: 'AE',
        templateUrl: '/Angular/partials/Utility/Pagination.html',
        scope: {},
        controller: function ($scope) {
            $scope.paginate = paginationservice;
        },
        link: function (scope, elem, attrs, ctrl) {

        }
    }
});
app.directive("disableInput", function () {
    return {
        link: function (scope, elem, attrs, ctrl) {
            $(elem).on('keydown', function (e) {
                console.log("key");
                e.preventDefault();

            });
        }
    }
});

app.filter("timeago", function (dateUtility) {
    return  function(originalTime){
        var originalDate = dateUtility.convertDate(originalTime);
        return timeSince(originalDate);
    }
});
function timeSince(date) {
    console.log(date);
    var seconds = Math.floor((new Date() - date) / 1000);

    var interval = Math.floor(seconds / 31536000);

    if (interval > 1) {
        return interval + " years";
    }
    interval = Math.floor(seconds / 2592000);
    if (interval > 1) {
        return interval + " months";
    }
    interval = Math.floor(seconds / 86400);
    if (interval > 1) {
        return interval + " days";
    }
    interval = Math.floor(seconds / 3600);
    if (interval > 1) {
        return interval + " hours";
    }
    interval = Math.floor(seconds / 60);
    if (interval > 1) {
        return interval + " minutes";
    }
    return Math.floor(seconds) + " seconds";
}