﻿angular.module("zdlay").directive('zdlaySector', function ($http, $templateCache, $compile) {

    return {
        restrict: 'AE',
        templateUrl: '/Angular/directives/templates/sector.html',
        scope: {
            item: '='
        },

        link: function (scope, element, attrs) {
          
        }

    }

});