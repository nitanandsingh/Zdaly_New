﻿/// <reference path="assets/lib/angular.min.js" />
console.log("Zdlay Module Loaded");
angular.module("zdlay", ['ngAnimate', 'utilities', 'ui.router', 'ngSanitize', 'ui.select', 'ui.autocomplete']);
 
