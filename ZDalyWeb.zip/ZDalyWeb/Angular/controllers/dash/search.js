﻿angular.module("zdlay").controller("searchCtrl", function ($scope,$rootScope) {
 

});