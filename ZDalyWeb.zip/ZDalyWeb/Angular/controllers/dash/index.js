﻿angular.module("zdlay").controller("indexCtrl", function ($scope) {

  


});



//<li class="educationsec">
//    <a href="javascript:void(0);" class="sector_col education_box" data-toggle="modal" data-target="#educationmodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>EDUCATION</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>
//</li>
//<li class="healthsec">
//    <a href="javascript:void(0);" class="sector_col health_box" data-toggle="modal" data-target="#healthmodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>HEALTH</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>
//</li>
//<li class="macrosec">
//    <a href="javascript:void(0);" class="sector_col macro_socio" data-toggle="modal" data-target="#macromodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>MACRO &amp; SOCIO ECONOMIC ASPECTS</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>
//</li>
//<li class="sciencesec">
//    <a href="javascript:void(0);" class="sector_col science_tech" data-toggle="modal" data-target="#sciencemodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>SCIENCE &amp; TECHNOLOGY</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>
//</li>
//<li class="populationsec">
//    <a href="javascript:void(0);" class="sector_col population_migration" data-toggle="modal" data-target="#populationmodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>POPULATION &amp; MIGRATION</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>

//</li>
//<li class="transportationsec">
//    <a href="javascript:void(0);" class="sector_col transportation" data-toggle="modal" data-target="#transportmodal">
//        <span class="thumbnail">
//            <div class="img"></div>
//            <span class="caption">
//                <h3>TRANSPORTATION</h3>
//                <p>livestock</p>
//                <p>Meat</p>
//                <p>Fish Poulty</p>
//            </span>
//        </span>
//    </a>

//</li>-->